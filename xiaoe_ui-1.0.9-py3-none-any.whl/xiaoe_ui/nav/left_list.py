from __future__ import annotations
"""侧栏导航：LeftList，支持一级页面和二级分组。

用法:
    left = LeftList()

    # 一级页面
    page_layout = left.add_page("home", "首页", icon="🏠")
    page_layout.addWidget(QLabel("欢迎"))

    # 二级分组
    group = left.add_group("settings", "设置", icon="📦")
    page_layout = group.add_page("general", "通用设置")
    page_layout.addWidget(CheckItem("enable", "启用"))

    # 组装
    main_layout.addLayout(left.left_layout)
    main_layout.addWidget(left.stack)
"""

from PySide6.QtCore import Qt, QTimer, QPointF, QSize
from PySide6.QtGui import QPainter, QPolygonF, QColor, QPen
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QStackedWidget, QSizePolicy,
)

from xiaoe_ui.widgets.click_frame import ClickFrame
from xiaoe_ui.widgets.basic import flash_style

_ARROW_SIZE = 16
_ICON_W = 28


class _StackedWidget(QStackedWidget):
    """返回当前页面的 size hint，避免短页面出现大片空白滚动区。"""

    def sizeHint(self):
        w = self.currentWidget()
        return w.sizeHint() if w else QSize(0, 0)

    def minimumSizeHint(self):
        w = self.currentWidget()
        return w.minimumSizeHint() if w else QSize(0, 0)


class _ArrowWidget(QWidget):
    """自定义三角箭头，paintEvent 中用 QPainter 旋转绘制。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._expanded = False
        self.setFixedSize(_ARROW_SIZE, _ARROW_SIZE)
        self.setProperty("class", "section_title")
        self.setAttribute(Qt.WA_TranslucentBackground)

    def set_expanded(self, expanded: bool):
        self._expanded = expanded
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        c = self.palette().color(self.foregroundRole())
        painter.setPen(Qt.NoPen)
        painter.setBrush(c)

        painter.translate(_ARROW_SIZE / 2, _ARROW_SIZE / 2)
        if self._expanded:
            painter.rotate(90)

        tri = QPolygonF([
            QPointF(-4, -5),
            QPointF(-4, 5),
            QPointF(5, 0),
        ])
        painter.drawPolygon(tri)
        painter.end()


class _PageItem:
    def __init__(self, key, label, page_widget, left_btn):
        self.key = key
        self.label = label
        self.page_widget = page_widget
        self.left_btn = left_btn


class LeftGroup:
    """侧栏二级分组。"""

    def __init__(self, key, label, left_list: 'LeftList', icon=None):
        self.key = key
        self.label = label
        self._left = left_list
        self._expanded = False

        # 分组按钮: [icon固定左] [text左]  [arrow右]
        self._btn, btn_layout = left_list._make_btn(label, icon)
        self._arrow = _ArrowWidget()
        btn_layout.addWidget(self._arrow)

        self._btn.on_left_click(self._toggle)

        # 子项容器
        self._child_container = QFrame()
        self._child_container.setContentsMargins(0, 0, 0, 0)
        self._child_layout = QVBoxLayout(self._child_container)
        self._child_layout.setSpacing(2)
        self._child_layout.setContentsMargins(14, 2, 3, 2)

        self._pages: list[_PageItem] = []

        left_list._left_layout.addWidget(self._btn)
        left_list._left_layout.addWidget(self._child_container)
        self._child_container.hide()

    def add_page(self, key, label, icon="") -> QVBoxLayout:
        """注册一个二级页面，返回页面的 content_layout。"""
        layout = self._left._make_page(key, label, icon, self._child_layout,
                                       page_class="no-border")
        self._pages.append(self._left._all_pages[key])
        return layout

    def _toggle(self):
        self._expanded = not self._expanded
        self._child_container.setVisible(self._expanded)
        self._arrow.set_expanded(self._expanded)

    def set_expanded(self, expanded: bool):
        self._expanded = expanded
        self._child_container.setVisible(expanded)
        self._arrow.set_expanded(expanded)


class LeftList:
    """侧栏导航管理器。管理左侧按钮列表 + 右侧 QStackedWidget。"""

    def __init__(self, callback_after_select_page = None):
        self.callback_after_select_page = callback_after_select_page
        self._left_layout = QVBoxLayout()
        self._left_layout.setContentsMargins(3, 3, 3, 3)

        self._stack = _StackedWidget()
        self._current_key = None
        self._all_pages: dict[str, _PageItem] = {}
        self._groups: list[LeftGroup] = []

    @property
    def left_layout(self) -> QVBoxLayout:
        return self._left_layout

    @property
    def stack(self) -> QStackedWidget:
        return self._stack

    # ── 共享: 创建侧栏按钮框架 ──

    def _make_btn(self, label, icon=""):
        """创建统一风格的侧栏按钮，返回 (ClickFrame, QHBoxLayout)。"""
        btn = ClickFrame(default_line=True)
        btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        lyt = QHBoxLayout(btn)
        lyt.setContentsMargins(5, 3, 5, 3)

        if icon is not None:
            ico = QLabel(icon)
            ico.setProperty("class", "section_title")
            ico.setFixedWidth(_ICON_W)
            ico.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lyt.addWidget(ico)

        lbl = QLabel(label)
        lbl.setProperty("class", "section_title")
        lbl.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        lyt.addWidget(lbl)
        lyt.addStretch(1)
        return btn, lyt

    # ── 一级页面 ──

    def _make_page(self, key, label, icon, parent_layout,
                   page_class="no-border") -> QVBoxLayout:
        """统一创建页面+按钮，注册到 _all_pages + _stack。"""
        page_widget = QWidget()
        page_widget.setProperty("class", page_class)
        content_layout = QVBoxLayout(page_widget)
        content_layout.setSpacing(10)
        content_layout.setContentsMargins(6, 10, 6, 10)

        btn, _btn_layout = self._make_btn(label, icon)
        btn.on_left_click(lambda *_: self._select_page(key))
        parent_layout.addWidget(btn)

        item = _PageItem(key, label, page_widget, btn)
        self._all_pages[key] = item
        self._stack.addWidget(page_widget)

        return content_layout

    def add_page(self, key, label, icon="") -> QVBoxLayout:
        """注册一个一级页面，返回页面的 content_layout。"""
        return self._make_page(key, label, icon, self._left_layout,
                               page_class="root-no-background no-border")

    # ── 二级分组 ──

    def add_group(self, key, label, icon="") -> LeftGroup:
        """注册一个可折叠的侧栏分组，返回 LeftGroup 对象。"""
        group = LeftGroup(key, label, self, icon)
        self._groups.append(group)
        return group

    # ── 页面切换 ──

    def _select_page(self, key):
        if key not in self._all_pages:
            return

        if self._current_key and self._current_key in self._all_pages:
            old = self._all_pages[self._current_key]
            old.left_btn.set_selected(False)

        item = self._all_pages[key]
        item.left_btn.set_selected(True)
        self._stack.setCurrentWidget(item.page_widget)
        self._stack.updateGeometry()
        self._current_key = key
        for grp in self._groups:
            for p in grp._pages:
                if p.key == key:
                    grp.set_expanded(True)
                    break
        if self.callback_after_select_page:
            self.callback_after_select_page()



    def switch_to(self, key):
        self._select_page(key)

    # ── 补stretch、高亮闪烁 ──

    def add_stretch_before_left(self):
        self._left_layout.addStretch(1)

    def flash_item(self, key):
        if key not in self._all_pages:
            return
        item = self._all_pages[key]

        def _flash(count=0):
            if count >= 10:
                return
            item.left_btn.set_light(count % 2 == 0)
            QTimer.singleShot(int(200 * (count + 1)),
                              lambda: _flash(count + 1))

        _flash()
