from __future__ import annotations
from xiaoe_ui.config.bridge import ConfigBridge
