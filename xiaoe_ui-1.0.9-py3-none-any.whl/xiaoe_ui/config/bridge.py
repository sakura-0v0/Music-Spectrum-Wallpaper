"""ConfigBridge — 纯粹的方法名适配器，把配置管理器的方法名桥接到 get/set/reset。"""

from __future__ import annotations

from typing import Callable, Union

from PySide6.QtCore import QObject, Signal

ResponseType = dict | list | str | int | float | bool | None


class ConfigBridge(QObject):
    """将任意配置管理器适配为框架所需的 get/set/reset 接口。

    value_changed 信号: 每次 set / reset 后发出 (key: str, new_value: object)

    用法:
        bridge = ConfigBridge(instance=my_config,                  # 配置管理器实例
                              get_method='configget',             # 读方法名
                              set_method='configset',             # 写方法名
                              reset_method='configreset',         # 重置方法名
                              )
    """

    value_changed = Signal(str, object)

    def __init__(self,
                 instance: object,
                 get_method: str = 'configget',
                 set_method: str = 'configset',
                 reset_method: str = 'configreset',
                 ):
        """Args:
            instance: 配置管理器实例
            get_method: 读方法名，签名为 (key) -> value
            set_method: 写方法名，签名为 (key, value) -> None
            reset_method: 重置方法名，签名为 (key) -> None
        """
        super().__init__()
        self._get = lambda *args, **kwargs: getattr(instance, get_method)(*args, **kwargs)
        self._set = lambda *args, **kwargs: getattr(instance, set_method)(*args, **kwargs)
        self._reset = lambda *args, **kwargs: getattr(instance, reset_method)(*args, **kwargs)
        self._listeners: dict[str, list[Callable]] = {}

    def get(self,
            key: str,
            ) -> ResponseType:
        """读取配置。

        Args:
            key: 配置键名

        Returns:
            配置值

        Raises:
            KeyError: key 不存在时
        """
        return self._get(key)

    def on(self, key: str, callback: Callable):
        """注册某个 key 的变更回调，set/reset 时自动触发。

        Args:
            key: 配置键名
            callback: 回调函数，签名为 (new_value) -> None

        .. code-block:: python

            def on_speed(v): print(f"speed → {v}")
            config.on("speed", on_speed)
            config.off("speed", on_speed)  # 必须是同一个函数引用
        """
        self._listeners.setdefault(key, []).append(callback)

    def off(self, key: str, callback: Callable):
        """取消某个 key 的变更回调。

        Args:
            key: 配置键名
            callback: 之前注册的回调函数引用
        """
        if key in self._listeners:
            self._listeners[key].remove(callback)

    def _fire_listeners(self, key: str, value: ResponseType):
        for cb in self._listeners.get(key, []):
            cb(value)

    def set(self,
            key: str,
            value: ResponseType,
            ):
        """写入配置并发出 value_changed 信号。

        Args:
            key: 配置键名
            value: 新值
        """
        self._set(key, value)
        self.value_changed.emit(key, value)
        self._fire_listeners(key, value)

    def reset(self,
              key: str,
              ):
        """重置配置并发出 value_changed 信号。

        Args:
            key: 配置键名（由实例的 reset_method 处理重置逻辑）
        """
        self._reset(key)
        new_val = self._get(key)
        self.value_changed.emit(key, new_val)
        self._fire_listeners(key, new_val)

    @classmethod
    def memory(cls,
               defaults: dict[str, ResponseType] | None = None,
               ) -> ConfigBridge:
        """创建纯内存配置管理器，不持久化。

        Args:
            defaults: 默认值 dict，也作为重置目标

        Returns:
            已绑定内存 dict 的 ConfigBridge

        用法:
            cfg = ConfigBridge.memory({"bg": (255,255,255,0)})
            cfg.get("bg")   # → (255, 255, 255, 0)
            cfg.set("bg", (0, 0, 0, 128))
            cfg.value_changed.connect(...)
        """
        d = dict(defaults or {})
        _defaults = dict(d)

        class _MemConfig:
            def configget(self, key):
                return d.get(key)

            def configset(self, key, value):
                d[key] = value

            def configreset(self, key):
                if key in _defaults:
                    d[key] = _defaults[key]

        return cls(instance=_MemConfig(), get_method='configget',
                   set_method='configset', reset_method='configreset')
