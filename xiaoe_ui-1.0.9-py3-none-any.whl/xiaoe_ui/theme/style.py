from __future__ import annotations
"""主题样式入口: StyleEngine 便捷函数。"""

from xiaoe_ui.theme.engine import StyleEngine


if __import__("typing").TYPE_CHECKING:
    from xiaoe_ui.config.bridge import ConfigBridge


def make_style(config: ConfigBridge) -> str:
    """便捷函数: 使用默认引擎 + 传入 config 生成 QSS。

    Args:
        config: ConfigBridge 实例

    Returns:
        替换完成的 QSS 字符串
    """
    return StyleEngine().make_style(config)


def apply_theme(theme_name: str,
                config: ConfigBridge,
                ):
    """便捷函数: 将预设主题值写入 config。

    等价于 engine.get_theme(name) + config.set()。

    Args:
        theme_name: 主题名
        config: ConfigBridge 实例
    """
    engine = StyleEngine()
    values = engine.get_theme(theme_name)
    if values is None:
        return
    for k, v in values.items():
        config.set(k, v)
    config.set("theme_name", theme_name)
