from __future__ import annotations
"""内置主题设置页，从 StyleEngine 自动生成控件。

读取 engine 的变量注册表和预设主题，按分组自动创建对应的
SliderItem / ColorItem / BottomItem，无需手动罗列。
"""

import os
from typing import Callable

from PySide6.QtWidgets import QHBoxLayout, QLabel, QFileDialog
from PySide6.QtCore import Qt

from xiaoe_ui.core.win_manager import WinManager
from xiaoe_ui.theme.engine import StyleEngine
from xiaoe_ui.utils.font_picker import font_picker_dialog
from xiaoe_ui.utils.get_short_path import get_short_path
from xiaoe_ui.widgets.item import (
    SliderItem, ColorItem, BottomItem, make_line, make_tip,
)
from xiaoe_ui.widgets.click_frame import ClickFrame
from xiaoe_ui.widgets.theme_btn import ThemeChoiceButton


class ThemePage:
    """主题颜色设置页，从 StyleEngine 自动生成所有控件。

    预设主题下拉 + 透明度/图片/字体/颜色分组，组间用分隔线隔开。
    控件变更 → config.value_changed → 外部回调刷新样式。

    Args:
        parent_layout: 父布局 (QVBoxLayout)
        engine: StyleEngine 实例（提供变量/主题数据）
        config: ConfigBridge 实例（读写配置值）
        on_style_changed: 任意变量变更回调 () -> None
        on_theme_selected: 预设主题选中回调 (name: str, values: dict) -> None
            默认: 遍历 values → config.set() → WinManager.apply_style_all()
        show_description: 是否在顶部显示说明文字
    """

    def __init__(self,
                 parent_layout,
                 engine: StyleEngine,
                 config,
                 on_style_changed: Callable[[], None] = None,
                 on_theme_selected: Callable[[str, dict], None] = None,
                 show_description: bool = False,
                 ):
        self._engine = engine
        self._config = config
        self._on_style_changed = on_style_changed
        self._on_theme_selected = on_theme_selected

        config = self._config

        # 监听变量变更 → 刷新样式
        config.value_changed.connect(self._on_var_changed)

        # ── 说明文字 ──
        if show_description:
            parent_layout.addWidget(make_tip(
                "本页为框架内置主题设置页，所有控件均由 ThemePage 自动创建。\n"
                "这一块文本默认不会显示。"))

        # ── 预设主题下拉 ──
        self._build_theme_preset(parent_layout)
        make_line(parent_layout)
        # ── 按分组生成控件 ──
        first_group = True
        for group_name, items in engine._vars.items():
            if not first_group:
                make_line(parent_layout, False)
            first_group = False
            self._build_group_title(
                parent_layout,
                group_name
            )
            for name, var in items.items():
                self._build_var(parent_layout, name, var)

        parent_layout.addStretch(1)

    # ── 预设主题选择器 ──

    def _build_theme_preset(self,
                            parent_layout,
                            ):
        """创建预设主题下拉行。"""
        theme_list = self._engine.get_theme_list()
        all_names: list[str] = []
        for names in theme_list.values():
            all_names.extend(names)

        row = ClickFrame(hand_cursor=False, custom_class="light-line disable")
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(5, 3, 5, 3)

        name_label = QLabel(f"{'主题预设':　<6}")
        name_label.setProperty("class", "line_title")
        row_layout.addWidget(name_label)
        row_layout.addStretch(1)

        desc = QLabel("直接应用预设主题(立即覆盖)")
        desc.setProperty("class", "tip-text")
        desc.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        row_layout.addWidget(desc)

        self._theme_btn = ThemeChoiceButton()
        self._theme_btn.set_themes(theme_list)
        self._theme_btn.setFixedWidth(120)

        try:
            cur = self._config.get("theme_name")
        except KeyError:
            cur = all_names[0] if all_names else ""
        if cur in all_names:
            self._theme_btn.setCurrentText(cur)
        self._theme_btn.currentIndexChanged.connect(self._on_theme_picked)

        row_layout.addWidget(self._theme_btn)
        parent_layout.addWidget(row)


    def _on_theme_picked(self,
                         idx: int,
                         ):
        """下拉选中预设主题 → 获取值 → 回调或直接 config.set。"""
        text = self._theme_btn.currentText()
        if not text:
            return
        if self._on_theme_selected is not None:
            values = self._engine.get_theme(text)
            if values is None:
                return
            self._on_theme_selected(text, values)
        else:
            values = self._engine.get_theme_raw(text)
            if values is None:
                return
            self._config.value_changed.disconnect(self._on_var_changed)
            for k, v in values.items():
                self._config.set(k, v)
            self._config.set("theme_name", text)
            self._config.value_changed.connect(self._on_var_changed)
            WinManager.apply_style_all()

    # ── 变量变 → 刷新 ──

    def _on_var_changed(self,
                        key: str,
                        _,
                        ):
        """config 变更 → 若为注册变量则触发样式刷新。"""
        if self._engine.is_registered(key) and self._on_style_changed:
            self._on_style_changed()

    # ── 根据 ThemeVar 自动创建控件 ──

    def _build_group_title(self,
                           parent_layout,
                           title,
                           desc = ""
                           ):
        layout = QHBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        label = QLabel(title)
        label.setProperty("class", "section_title")
        layout.addWidget(label)

        desc_label = QLabel(desc)
        desc_label.setProperty("class", "tip-text")
        layout.addWidget(desc_label)


        parent_layout.addLayout(layout)

    def _build_var(self,
                   parent_layout,
                   name: str,
                   var,
                   ):
        """根据 ThemeVar.widget 类型创建对应的控件。"""
        widget = var.widget
        params = var.widget_params

        if widget == "slider":
            SliderItem(
                var.label,
                text=var.desc,
                config=self._config,
                config_name=name,
                config_range=params.get("range", (0, 100)),
                step=params.get("step", 1),
                num_type_text=params.get("unit", ""),
                live=False,
                parent_layout=parent_layout,
                callback=lambda *e:WinManager.apply_style_all()
            )

        elif widget == "color":
            ColorItem(
                var.label,
                config=self._config,
                config_name=name,
                text=var.desc,
                parent_layout=parent_layout,
                callback=lambda *e:WinManager.apply_style_all()
            )

        elif widget == "font":
            def _font_text():
                return f"当前: {self._config.get(name)}"

            def _pick_font():
                family = font_picker_dialog(
                    default_family=self._config.get(name),
                )
                if family is not None:
                    self._config.set(name, family)
                WinManager.apply_style_all()

            def _reset_font():
                self._config.reset(name)
                WinManager.apply_style_all()

            item = BottomItem(
                var.label,
                text=_font_text(),
                btn_text="设置",
                callback=_pick_font,
                reset_callback=_reset_font,
                parent_layout=parent_layout,
            )

            def _on_font_changed(k, _):
                if k == name:
                    item.setText(_font_text())

            self._config.value_changed.connect(_on_font_changed)

        elif widget == "image":
            def _img_text():
                p = self._config.get(name)
                if not p:
                    return "默认", "使用默认图标"
                path = str(p)
                return get_short_path(path), path

            def _pick_bg():
                cur = self._config.get(name)
                start = os.path.dirname(cur) if cur else ""
                path, _ = QFileDialog.getOpenFileName(
                    None, "选择背景图片", start,
                    "Images (*.png *.jpg *.jpeg *.bmp)",
                )
                if path:
                    self._config.set(name, path)

            def _reset_bg():
                self._config.reset(name)

            display, tooltip = _img_text()
            item = BottomItem(
                var.label,
                text=display,
                text_tooltip=tooltip,
                btn_text="设置",
                callback=_pick_bg,
                reset_callback=_reset_bg,
                parent_layout=parent_layout,
            )

            def _on_img_changed(k, _):
                if k == name:
                    d, t = _img_text()
                    item.setText(d)
                    if item._desc_label is not None:
                        item._desc_label.setToolTip(t)

            self._config.value_changed.connect(_on_img_changed)
