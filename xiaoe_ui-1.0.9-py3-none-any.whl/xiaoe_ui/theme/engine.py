from __future__ import annotations
"""StyleEngine: QSS 管理 + 变量注册 + 主题预设 + 样式生成。"""

import os
from collections import OrderedDict
from functools import lru_cache
from typing import Callable

from xiaoe_ui.theme.defaults import (
    DEFAULT_VARS, DEFAULT_THEMES, ThemeVar, _image_fallbacks,
)
from xiaoe_ui.utils.static_path import resolve_static

if __import__("typing").TYPE_CHECKING:
    from xiaoe_ui.config.bridge import ConfigBridge

_HERE = os.path.dirname(os.path.abspath(__file__))
_QSS_PATH = os.path.join(_HERE, "global_style.qss")


@lru_cache(maxsize=4)
def _read_qss_cached(path: str) -> str:
    """缓存读取 QSS 文件，避免主题切换时反复读盘。"""
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

class StyleEngine:
    """主题样式引擎: QSS 拼接 + 变量替换 + 主题预设管理 + 界面自动生成数据源。

    引擎自身不持有也不修改 config。只管理主题数据，make_style() 时从 config 读取。

    默认使用框架内置的 global_style.qss、DEFAULT_VARS、DEFAULT_THEMES。

    Args:
        qss_path: 默认 QSS 文件路径，None=框架内置
        vars: 变量注册表 {group: {name: ThemeVar}}，None=框架内置
        themes: 预设主题 {group: {name: {key: val}}}，None=框架内置
        defaults: 默认值 dict，None=框架内置

    用法:
        engine = StyleEngine()
        engine.add_qss("...")                # 可选: 自定义 QSS
        engine.add_var("颜色", "my", ...)     # 可选: 追加变量
        engine.add_theme("自定义", "我的", {}) # 可选: 追加主题
        engine.set_defaults(my=(255,0,0))    # 可选: 覆盖默认值

        defaults = engine.get_defaults()
        # 将 defaults 拼入配置管理器的默认值中

        qss = engine.make_style(config)
    """

    def __init__(self,
                 qss_path: str | None = None,
                 vars: dict[str, dict[str, ThemeVar]] | None = None,
                 themes: dict[str, dict[str, dict[str, object]]] | None = None,
                 defaults: dict[str, object] | None = None,
                 ):
        # ── QSS ──
        self._qss_path: str | None = qss_path if qss_path is not None else _QSS_PATH
        self._qss_strings: list[str] = []

        # ── 变量 ──
        self._var_names: set[str] = set()
        self._vars: OrderedDict[str, OrderedDict[str, ThemeVar]] = OrderedDict()
        self._load_vars(vars if vars is not None else DEFAULT_VARS)

        # ── 主题 ──
        self._themes: OrderedDict[str, OrderedDict[str, dict[str, object]]] = OrderedDict()
        self._load_themes(themes if themes is not None else DEFAULT_THEMES)

        # ── 默认值 — 引用第一套主题的值 dict，保持同步 ──
        first_group = next(iter(self._themes.values()))
        self._defaults = next(iter(first_group.values()))
        if defaults is not None:
            self._defaults.update(defaults)

    # ── 内部 helpers ──

    def _rebuild_var_names(self):
        """重建已注册变量名集合。"""
        self._var_names.clear()
        for items in self._vars.values():
            self._var_names.update(items.keys())

    def _load_vars(self,
                   vars_dict: dict[str, dict[str, ThemeVar]],
                   ):
        """加载变量注册表，追加到现有。"""
        for group, items in vars_dict.items():
            if group not in self._vars:
                self._vars[group] = OrderedDict()
            self._vars[group].update(items)
        self._rebuild_var_names()

    def _load_themes(self,
                     themes_dict: dict[str, dict[str, dict[str, object]]],
                     ):
        """加载主题预设，追加到现有。"""
        for group, items in themes_dict.items():
            if group not in self._themes:
                self._themes[group] = OrderedDict()
            self._themes[group].update(items)

    # ── QSS 管理 ──

    def add_qss(self,
                qss: str,
                ):
        """追加 QSS 字符串，拼接在默认 QSS 之后。

        Args:
            qss: QSS 字符串，可包含 {{占位符}}
        """
        self._qss_strings.append(qss)

    def set_qss(self,
                qss: str,
                ):
        """替换全部 QSS 为指定字符串（清空默认 QSS 文件及所有追加）。

        Args:
            qss: QSS 字符串
        """
        self._qss_path = None
        self._qss_strings = [qss]

    # ── 变量管理 ──

    def add_var(self,
                group: str,
                name: str,
                var: ThemeVar,
                ):
        """追加一个主题变量。

        Args:
            group: 分组名，如 "颜色"
            name: 变量名，即 QSS 占位符名
            var: ThemeVar 定义
        """
        if group not in self._vars:
            self._vars[group] = OrderedDict()
        self._vars[group][name] = var
        self._var_names.add(name)

    def set_vars(self,
                 vars_dict: dict[str, dict[str, ThemeVar]],
                 ):
        """替换全部变量注册表（清空内置变量 + 写入新的）。

        Args:
            vars_dict: 新的变量注册表 {group: {name: ThemeVar}}
        """
        self._vars.clear()
        self._load_vars(vars_dict)

    def is_registered(self,
                      name: str,
                      ) -> bool:
        """检查变量名是否已注册。

        Args:
            name: 变量名

        Returns:
            True=已注册
        """
        return name in self._var_names

    # ── 默认值 ──

    def set_default_theme(self, name: str):
        """指定哪套主题的值作为引擎默认值。

        _defaults 始终引用该主题的 values dict，set_defaults 修改也会同步到该主题。

        Args:
            name: 主题名
        """
        for group in self._themes.values():
            if name in group:
                self._defaults = group[name]
                return
        raise KeyError(f"主题 '{name}' 不存在")

    def set_defaults(self,
                     **kwargs: object,
                     ):
        """覆盖指定变量的默认值。

        Args:
            **kwargs: key=value 对
        """
        self._defaults.update(kwargs)

    def set_internal_default(self, key: str, rel_path: str):
        """设置图片类变量的内部默认路径。

        当配置中该变量值为 None 时，引擎使用此路径解析实际文件。

        Args:
            key: 变量名，如 ``"bg_image"``
            rel_path: 相对项目根目录的路径，如 ``"xiaoe_ui/demo_static/background.png"``
        """
        _image_fallbacks[key] = rel_path

    def resolve_value(self,
                      config: ConfigBridge,
                      key: str,
                      ) -> object:
        """从配置获取变量值，含完整默认值回退链。

        config → self._defaults → _image_fallbacks → None

        Args:
            config: ConfigBridge 实例
            key: 变量名

        Returns:
            解析后的值（图片类型返回实际路径），未找到返回 None
        """
        val = config.get(key)
        if val is None:
            val = self._defaults.get(key)
        if val is None:
            fallback = _image_fallbacks.get(key)
            if fallback:
                val = resolve_static(fallback)
        return val

    def get_defaults(self) -> dict[str, object]:
        """获取所有已注册变量的默认值 dict。

        Returns:
            {name: default_value, ...}

        调用方应拿到此 dict 后自行设置配置管理器的默认值。
        """
        result: dict[str, object] = {}
        for items in self._vars.values():
            for name in items:
                result[name] = self._defaults.get(name)
        return result

    # ── 主题管理 ──

    def add_theme(self,
                  group: str,
                  name: str,
                  values: dict[str, object],
                  ):
        """追加一个预设主题。

        Args:
            group: 主题分组名，如 "自定义"
            name: 主题名
            values: 主题值 dict，只存非默认值
        """
        if group not in self._themes:
            self._themes[group] = OrderedDict()
        self._themes[group][name] = values

    def set_themes(self,
                   themes: dict[str, dict[str, dict[str, object]]],
                   ):
        """替换全部预设主题（清空内置主题 + 写入新的）。

        Args:
            themes: 新的主题注册表 {group: {name: {key: val}}}
        """
        self._themes.clear()
        self._load_themes(themes)
        first_group = next(iter(self._themes.values()))
        self._defaults = next(iter(first_group.values()))

    def get_theme(self,
                  name: str,
                  ) -> dict[str, object] | None:
        """获取指定主题的完整值 dict（已 merge 默认值）。

        Args:
            name: 主题名

        Returns:
            {key: value, ...} 完整值；不存在返回 None
        """
        for themes in self._themes.values():
            if name in themes:
                values = dict(themes[name])
                if not values:
                    return dict(self.get_defaults())
                merged = dict(self.get_defaults())
                merged.update(values)
                return merged
        return None

    def get_theme_raw(self,
                      name: str,
                      ) -> dict[str, object] | None:
        """获取主题的自有值 dict（不 merge 默认值）。

        Args:
            name: 主题名

        Returns:
            {key: value, ...} 只含主题定义的键；不存在返回 None
        """
        for themes in self._themes.values():
            if name in themes:
                vals = themes[name]
                if vals:
                    return dict(vals)
                return {}
        return None

    def get_theme_list(self) -> OrderedDict[str, list[str]]:
        """获取主题列表，用于 ThemePage 下拉。

        Returns:
            {group_name: [theme_name, ...], ...}
        """
        result: OrderedDict[str, list[str]] = OrderedDict()
        for group, themes in self._themes.items():
            result[group] = list(themes.keys())
        return result

    # ── 变量遍历 ──

    def iter_vars(self):
        """展平遍历所有已注册变量。

        Yields:
            (group_name: str, name: str, var: ThemeVar)
        """
        for group, items in self._vars.items():
            for name, var in items.items():
                yield group, name, var

    @property
    def var_names(self) -> set[str]:
        """所有已注册变量名的集合。"""
        return self._var_names

    # ── 样式生成 ──

    def make_style(self,
                   config: ConfigBridge,
                   ) -> str:
        """拼接 QSS 并替换所有 {{占位符}}，返回最终样式字符串。

        遍历所有注册变量，从 config 读取值 → transform → 替换。
        config 中缺少的 key 使用引擎默认值，都没有则抛出 KeyError。

        Args:
            config: ConfigBridge 实例

        Returns:
            替换完成的 QSS 字符串

        Raises:
            KeyError: config 中缺少某 key 且无默认值
        """
        # 拼接 QSS（缓存文件读取）
        parts: list[str] = []
        if self._qss_path:
            parts.append(_read_qss_cached(self._qss_path))
        parts.extend(self._qss_strings)
        qss = "\n".join(parts)

        # 遍历替换
        for _group, items in self._vars.items():
            for name, var in items.items():
                val = config.get(name)
                if val is None:
                    val = self._defaults.get(name)
                # 图片类变量为空时用内部默认路径动态解析
                if val is None and var.widget == "image":
                    fallback = _image_fallbacks.get(name)
                    if fallback:
                        val = resolve_static(fallback)
                if val is None:
                    raise KeyError(
                        f"配置缺少 '{name}' ({var.label})，"
                        f"请调用 engine.get_defaults() 获取默认值并 config.set()"
                    )
                qss = qss.replace("{{" + name + "}}", var.transform(val))

        return qss
