"""xiaoe_ui 主题默认数据 — 变量注册表 + 预设主题。

所有主题数据集中于此，调用方可直接修改或运行时通过引擎覆盖。
默认值从第一个预设主题 (小娥樱花) 动态获取。
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Callable, Literal

_HERE = os.path.dirname(os.path.abspath(__file__))

# 图片变量名 → 默认相对路径（由 StyleEngine.set_internal_default 注册）
_image_fallbacks: dict[str, str] = {
    "check_img": "xiaoe_ui/static/yes.png",  # 框架内置默认
}


def _img_transform(path) -> str:
    """图片 transform: 生成 QSS url()。path 为 None 时留空。"""
    p = str(path) if path else ""
    if not p:
        return ""
    return f"image: url('{p.replace(chr(92), '/')}');"

def _size_px_transform(value) -> str:
    """生成px单位的字符串"""
    return f"{value}px"

def _size_pt_transform(value) -> str:
    """生成pt单位的字符串"""
    return f"{value}pt"

# ═══════════════════════════════════════════════════════════════
# ThemeVar
# ═══════════════════════════════════════════════════════════════

def _rgb_str(val: tuple[int, int, int]) -> str:
    """RGB 元组 → QSS 逗号分隔字符串。"""
    return ",".join(str(v) for v in val)

WidgetType = Literal["slider", "color", "font", "image"]

@dataclass
class ThemeVar:
    """描述一个 QSS {{占位符}} 变量的元信息，供引擎替换和界面自动生成。

    Args:
        label: 中文名，如 "选项背景"
        desc: 说明文字，悬浮提示
        widget: 控件类型 — "slider" | "color" | "font" | "image"
        widget_params: 控件参数，如 slider 的 range/step/unit
        transform: 值 → QSS 字符串的转换函数
    """

    label: str
    widget: WidgetType
    desc: str
    widget_params: dict = field(default_factory=dict)
    transform: Callable = str


# ═══════════════════════════════════════════════════════════════
# 变量注册表 (嵌套字典，插入顺序即 UI 顺序)
# ═══════════════════════════════════════════════════════════════

DEFAULT_VARS: dict[str, dict[str, ThemeVar]] = {
    "透明度": dict(
        widget_alpha=ThemeVar(
            label="背景模糊度",
            widget="slider",
            desc="设置背景前的元素的不透明度",
            widget_params={"range": (0.0, 1.0), "step": 0.01, "unit": "比例"},
            transform=str,
        ),
        block_alpha=ThemeVar(
            label="配置块模糊度",
            widget="slider",
            desc="设置配置块的不透明度",
            widget_params={"range": (0.0, 1.0), "step": 0.01, "unit": "比例"},
            transform=str,
        ),
    ),
    "图片": dict(
        bg_image=ThemeVar(
            label="背景图片",
            widget="image",
            desc="选择一张图片作为应用背景",
            transform=_img_transform,
        ),
        check_img=ThemeVar(
            label="复选框图标",
            widget="image",
            desc="复选框勾选状态的图标",
            transform=lambda p: _img_transform(p),
        ),
    ),
    "主题颜色": dict(
        config_background=ThemeVar(
            label="选项背景",
            widget="color",
            desc="设置选项界面的背景色",
            transform=_rgb_str
        ),
        config_title_color=ThemeVar(
            label="主标题颜色",
            widget="color",
            desc="设置选项块顶部标题颜色",
            transform=_rgb_str
        ),
        config_item_title_color=ThemeVar(
            label="副标题颜色",
            widget="color",
            desc="设置其他字的颜色",
            transform=_rgb_str
        ),
        config_elem_color_1=ThemeVar(
            label="组件默认颜色",
            widget="color",
            desc="大部分组件的默认颜色",
            transform=_rgb_str
        ),
        config_elem_color_2=ThemeVar(
            label="组件鼠标悬停",
            widget="color",
            desc="大部分组件鼠标悬停的颜色",
            transform=_rgb_str
        ),
        config_elem_color_3=ThemeVar(
            label="组件鼠标按下",
            widget="color",
            desc="大部分组件鼠标按下的颜色",
            transform=_rgb_str
        ),
        top_win_default_main_color=ThemeVar(
            label="其他主题色",
            widget="color",
            desc="悬浮窗线、框、字",
            transform=_rgb_str
        ),
    ),
    "表单颜色": dict(
        status_edited=ThemeVar(
            label="编辑中状态色",
            widget="color",
            desc="编辑框编辑中时的边框颜色",
            transform=_rgb_str
        ),
        status_success=ThemeVar(
            label="成功状态色",
            widget = "color",
            desc="编辑框提交成功时的边框颜色",
            transform = _rgb_str
        ),
        status_error=ThemeVar(
            label="错误状态色",
            widget = "color",
            desc="编辑框校验失败时的边框颜色",
            transform = _rgb_str
        ),
    ),
    "字体": dict(
        app_font=ThemeVar(
            label="字体",
            widget="font",
            desc="应用全局字体",
            transform=str,
        ),
        default_text_size=ThemeVar(
            label="默认字体大小",
            widget="slider",
            desc="默认的字体大小",
            widget_params={"range": (8, 22), "step": 1, "unit": "pt"},
            transform=_size_pt_transform,
        ),
        section_title_size=ThemeVar(
            label="大标题字体",
            widget="slider",
            desc="大标题的字体大小",
            widget_params={"range": (8, 22), "step": 1, "unit": "px"},
            transform=_size_px_transform,
        ),
        tip_text_size=ThemeVar(
            label="小提示字体",
            widget="slider",
            desc="tips的字体大小",
            widget_params={"range": (4, 18), "step": 1, "unit": "px"},
            transform=_size_px_transform,
        ),
    ),
    "容器边框":dict(
        block_border_radius=ThemeVar(
            label="圆角",
            widget="slider",
            desc="容器的圆角",
            widget_params={"range": (0, 15), "step": 1, "unit": "px"},
            transform=_size_px_transform,
        ),
        block_border_width=ThemeVar(
            label="边框",
            widget="slider",
            desc="容器的边框宽度",
            widget_params={"range": (0, 8), "step": 1, "unit": "px"},
            transform=_size_px_transform,
        ),
    ),
    "按钮边框": dict(
        reaction_border_radius=ThemeVar(
            label="圆角",
            widget="slider",
            desc="按钮组件的圆角",
            widget_params={"range": (0, 15), "step": 1, "unit": "px"},
            transform=_size_px_transform,
        ),
        reaction_small_border_radius=ThemeVar(
            label="小按钮圆角",
            widget="slider",
            desc="按钮组件的圆角",
            widget_params={"range": (0, 12), "step": 1, "unit": "px"},
            transform=_size_px_transform,
        ),
        reaction_default_border_width=ThemeVar(
            label="常规边框",
            widget="slider",
            desc="常规按钮的边框宽度",
            widget_params={"range": (0, 8), "step": 1, "unit": "px"},
            transform=_size_px_transform,
        ),
        reaction_2x_border_width=ThemeVar(
            label="稍粗边框",
            widget="slider",
            desc="稍微粗一些的按钮的边框宽度",
            widget_params={"range": (0, 8), "step": 1, "unit": "px"},
            transform=_size_px_transform,
        ),
        reaction_4x_border_width=ThemeVar(
            label="加粗边框",
            widget="slider",
            desc="很粗的按钮的边框宽度",
            widget_params={"range": (0, 8), "step": 1, "unit": "px"},
            transform=_size_px_transform,
        ),
    ),
    "文本组件边框": dict(
        edit_border_radius=ThemeVar(
            label="文本组件圆角",
            widget="slider",
            desc="带框文本组件的圆角",
            widget_params={"range": (0, 13), "step": 1, "unit": "px"},
            transform=_size_px_transform,
        ),
        edit_border_width=ThemeVar(
            label="文本组件边框",
            widget="slider",
            desc="文本组件的边框宽度",
            widget_params={"range": (0, 8), "step": 1, "unit": "px"},
            transform=_size_px_transform,
        ),

    ),
}

# ═══════════════════════════════════════════════════════════════
# 预设主题 (嵌套字典，首个主题的值即框架默认值)
# ═══════════════════════════════════════════════════════════════

DEFAULT_THEMES: dict[str, dict[str, dict[str, object]]] = {
    # ── 默认 (小娥樱花 = 框架默认值) ──
    "默认": {
        "小娥樱花": {
            "widget_alpha": 0.0,
            "block_alpha": 0.85,
            "bg_image": None,
            "check_img": None,

            "config_background": (255, 246, 246),
            "config_title_color": (255, 154, 162),
            "config_item_title_color": (122, 91, 96),
            "config_elem_color_1": (255, 154, 162),
            "config_elem_color_2": (255, 182, 193),
            "config_elem_color_3": (255, 125, 135),
            "top_win_default_main_color": (255, 120, 180),

            "status_edited": (255, 165, 0),
            "status_success": (0, 200, 83),
            "status_error": (213, 0, 0),

            "app_font": "Microsoft Yahei",
            "default_text_size": 12,
            "section_title_size": 18,
            "tip_text_size": 12,

            "block_border_radius": 3,
            "reaction_border_radius": 5,
            "reaction_small_border_radius": 5,
            "edit_border_radius": 4,

            "block_border_width": 1,
            "reaction_default_border_width":1,
            "reaction_2x_border_width": 2,
            "reaction_4x_border_width": 4,
            "edit_border_width": 2,

        },
    },

    # ── 亮色主题 ──
    "亮色主题": {
        "清晨薄雾": {
            "config_background": (248, 250, 252),
            "config_title_color": (60, 100, 140),
            "config_item_title_color": (100, 120, 140),
            "config_elem_color_1": (80, 130, 180),
            "config_elem_color_2": (100, 150, 200),
            "config_elem_color_3": (60, 100, 150),
            "top_win_default_main_color": (90, 140, 210),
        },
        "薄荷晨露": {
            "config_background": (240, 252, 248),
            "config_title_color": (60, 160, 140),
            "config_item_title_color": (90, 130, 120),
            "config_elem_color_1": (80, 180, 150),
            "config_elem_color_2": (100, 200, 170),
            "config_elem_color_3": (60, 140, 120),
            "top_win_default_main_color": (90, 190, 165),
        },
        "秋日暖阳": {
            "config_background": (255, 248, 240),
            "config_title_color": (190, 110, 50),
            "config_item_title_color": (150, 120, 90),
            "config_elem_color_1": (210, 140, 70),
            "config_elem_color_2": (230, 160, 100),
            "config_elem_color_3": (170, 100, 40),
            "top_win_default_main_color": (220, 150, 80),
        },
        "淡紫薰衣": {
            "config_background": (250, 245, 255),
            "config_title_color": (140, 100, 180),
            "config_item_title_color": (120, 110, 140),
            "config_elem_color_1": (160, 120, 200),
            "config_elem_color_2": (180, 140, 220),
            "config_elem_color_3": (130, 90, 160),
            "top_win_default_main_color": (170, 130, 210),
        },
        "宁静海洋": {
            "config_background": (242, 248, 255),
            "config_title_color": (50, 120, 170),
            "config_item_title_color": (80, 110, 140),
            "config_elem_color_1": (70, 140, 190),
            "config_elem_color_2": (90, 160, 210),
            "config_elem_color_3": (50, 100, 150),
            "top_win_default_main_color": (80, 150, 200),
        },
        "森林绿意": {
            "config_background": (245, 250, 245),
            "config_title_color": (60, 130, 70),
            "config_item_title_color": (100, 120, 110),
            "config_elem_color_1": (80, 150, 90),
            "config_elem_color_2": (100, 170, 110),
            "config_elem_color_3": (60, 110, 70),
            "top_win_default_main_color": (90, 160, 100),
        },
        "柔光灰蓝": {
            "config_background": (248, 250, 252),
            "config_title_color": (80, 110, 150),
            "config_item_title_color": (120, 130, 150),
            "config_elem_color_1": (100, 130, 170),
            "config_elem_color_2": (120, 150, 190),
            "config_elem_color_3": (80, 100, 140),
            "top_win_default_main_color": (110, 140, 180),
        },
        "樱花浅粉": {
            "config_background": (255, 248, 252),
            "config_title_color": (220, 120, 160),
            "config_item_title_color": (170, 130, 150),
            "config_elem_color_1": (230, 140, 180),
            "config_elem_color_2": (240, 160, 190),
            "config_elem_color_3": (200, 100, 140),
            "top_win_default_main_color": (235, 145, 175),
        },
        "极简银灰": {
            "config_background": (250, 250, 252),
            "config_title_color": (100, 100, 110),
            "config_item_title_color": (140, 140, 150),
            "config_elem_color_1": (170, 170, 180),
            "config_elem_color_2": (190, 190, 200),
            "config_elem_color_3": (120, 120, 130),
            "top_win_default_main_color": (180, 180, 190),
        },
        "琥珀时光": {
            "config_background": (252, 248, 242),
            "config_title_color": (180, 120, 60),
            "config_item_title_color": (150, 130, 110),
            "config_elem_color_1": (200, 150, 100),
            "config_elem_color_2": (220, 170, 120),
            "config_elem_color_3": (160, 110, 50),
            "top_win_default_main_color": (210, 160, 110),
        },
        "科技蓝光": {
            "config_background": (240, 245, 255),
            "config_title_color": (40, 110, 200),
            "config_item_title_color": (90, 120, 160),
            "config_elem_color_1": (60, 130, 220),
            "config_elem_color_2": (80, 150, 240),
            "config_elem_color_3": (40, 90, 180),
            "top_win_default_main_color": (70, 140, 230),
        },
    },

    # ── 暗色主题 ──
    "暗色主题": {
        "深空幽蓝": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (30, 40, 55),
            "config_title_color": (100, 160, 240),
            "config_item_title_color": (140, 160, 190),
            "config_elem_color_1": (80, 130, 200),
            "config_elem_color_2": (100, 150, 220),
            "config_elem_color_3": (60, 110, 180),
            "top_win_default_main_color": (110, 170, 250),
        },
        "暗夜星辰": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (30, 35, 45),
            "config_title_color": (200, 210, 220),
            "config_item_title_color": (160, 170, 180),
            "config_elem_color_1": (180, 190, 200),
            "config_elem_color_2": (200, 210, 220),
            "config_elem_color_3": (140, 150, 160),
            "top_win_default_main_color": (190, 200, 210),
        },
        "墨绿森林": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (25, 40, 35),
            "config_title_color": (100, 200, 180),
            "config_item_title_color": (120, 150, 140),
            "config_elem_color_1": (80, 160, 140),
            "config_elem_color_2": (100, 180, 160),
            "config_elem_color_3": (60, 140, 120),
            "top_win_default_main_color": (110, 190, 170),
        },
        "暗金奢华": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (40, 35, 30),
            "config_title_color": (220, 180, 100),
            "config_item_title_color": (170, 150, 120),
            "config_elem_color_1": (230, 190, 110),
            "config_elem_color_2": (240, 210, 130),
            "config_elem_color_3": (200, 160, 80),
            "top_win_default_main_color": (230, 200, 120),
        },
        "深紫星空": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (40, 30, 50),
            "config_title_color": (180, 140, 220),
            "config_item_title_color": (150, 140, 160),
            "config_elem_color_1": (160, 120, 200),
            "config_elem_color_2": (180, 140, 220),
            "config_elem_color_3": (140, 100, 180),
            "top_win_default_main_color": (190, 150, 230),
        },
        "暗红古典": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (45, 30, 35),
            "config_title_color": (220, 120, 120),
            "config_item_title_color": (170, 140, 140),
            "config_elem_color_1": (200, 100, 100),
            "config_elem_color_2": (220, 130, 130),
            "config_elem_color_3": (180, 80, 80),
            "top_win_default_main_color": (210, 110, 110),
        },
        "暗夜科技": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (25, 30, 40),
            "config_title_color": (100, 170, 240),
            "config_item_title_color": (130, 150, 170),
            "config_elem_color_1": (80, 140, 210),
            "config_elem_color_2": (100, 160, 230),
            "config_elem_color_3": (60, 120, 190),
            "top_win_default_main_color": (110, 180, 250),
        },
        "石墨灰": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (35, 40, 45),
            "config_title_color": (180, 190, 200),
            "config_item_title_color": (150, 160, 170),
            "config_elem_color_1": (160, 170, 180),
            "config_elem_color_2": (180, 190, 200),
            "config_elem_color_3": (130, 140, 150),
            "top_win_default_main_color": (170, 180, 190),
        },
    },

    # ── 明亮炫彩 ──
    "明亮炫彩": {
        "糖果乐园": {
            "config_background": (255, 245, 250),
            "config_title_color": (255, 100, 180),
            "config_item_title_color": (180, 150, 220),
            "config_elem_color_1": (255, 120, 100),
            "config_elem_color_2": (100, 200, 255),
            "config_elem_color_3": (150, 220, 100),
            "top_win_default_main_color": (255, 100, 100),
        },
        "彩虹幻想": {
            "config_background": (250, 255, 245),
            "config_title_color": (255, 50, 100),
            "config_item_title_color": (255, 150, 50),
            "config_elem_color_1": (100, 200, 255),
            "config_elem_color_2": (150, 100, 255),
            "config_elem_color_3": (50, 220, 100),
            "top_win_default_main_color": (255, 220, 50),
        },
        "夏日海洋": {
            "config_background": (240, 250, 255),
            "config_title_color": (0, 150, 255),
            "config_item_title_color": (50, 180, 220),
            "config_elem_color_1": (255, 120, 50),
            "config_elem_color_2": (255, 200, 50),
            "config_elem_color_3": (100, 220, 100),
            "top_win_default_main_color": (255, 100, 150),
        },
        "热带雨林": {
            "config_background": (245, 255, 245),
            "config_title_color": (50, 200, 100),
            "config_item_title_color": (255, 150, 50),
            "config_elem_color_1": (50, 180, 220),
            "config_elem_color_2": (255, 100, 180),
            "config_elem_color_3": (200, 100, 255),
            "top_win_default_main_color": (255, 200, 50),
        },
        "阳光沙滩": {
            "config_background": (255, 250, 240),
            "config_title_color": (255, 150, 50),
            "config_item_title_color": (50, 180, 220),
            "config_elem_color_1": (255, 100, 150),
            "config_elem_color_2": (100, 200, 255),
            "config_elem_color_3": (150, 220, 100),
            "top_win_default_main_color": (255, 200, 50),
        },
        "马卡龙甜点": {
            "config_background": (255, 250, 255),
            "config_title_color": (255, 100, 180),
            "config_item_title_color": (150, 220, 255),
            "config_elem_color_1": (180, 255, 150),
            "config_elem_color_2": (255, 220, 100),
            "config_elem_color_3": (220, 150, 255),
            "top_win_default_main_color": (255, 150, 100),
        },
        "霓虹未来": {
            "config_background": (255, 250, 255),
            "config_title_color": (0, 255, 255),
            "config_item_title_color": (255, 0, 255),
            "config_elem_color_1": (255, 255, 0),
            "config_elem_color_2": (0, 255, 100),
            "config_elem_color_3": (255, 100, 0),
            "top_win_default_main_color": (255, 0, 100),
        },
        "电光紫蓝": {
            "config_background": (240, 240, 255),
            "config_title_color": (150, 50, 255),
            "config_item_title_color": (255, 50, 150),
            "config_elem_color_1": (50, 150, 255),
            "config_elem_color_2": (255, 150, 50),
            "config_elem_color_3": (50, 255, 150),
            "top_win_default_main_color": (255, 255, 50),
        },
        "水果乐园": {
            "config_background": (255, 250, 245),
            "config_title_color": (255, 50, 50),
            "config_item_title_color": (255, 150, 50),
            "config_elem_color_1": (100, 200, 50),
            "config_elem_color_2": (50, 150, 255),
            "config_elem_color_3": (200, 50, 200),
            "top_win_default_main_color": (255, 200, 50),
        },
        "彩虹之梦": {
            "config_background": (250, 250, 255),
            "config_title_color": (255, 0, 100),
            "config_item_title_color": (100, 200, 50),
            "config_elem_color_1": (255, 150, 0),
            "config_elem_color_2": (0, 150, 255),
            "config_elem_color_3": (150, 50, 255),
            "top_win_default_main_color": (255, 200, 0),
        },
        "泡泡糖乐园": {
            "config_background": (255, 245, 255),
            "config_title_color": (255, 100, 200),
            "config_item_title_color": (200, 150, 255),
            "config_elem_color_1": (100, 220, 255),
            "config_elem_color_2": (255, 220, 100),
            "config_elem_color_3": (100, 255, 150),
            "top_win_default_main_color": (255, 150, 100),
        },
        "彩虹糖果": {
            "config_background": (255, 255, 250),
            "config_title_color": (255, 50, 100),
            "config_item_title_color": (50, 200, 100),
            "config_elem_color_1": (50, 100, 255),
            "config_elem_color_2": (255, 150, 50),
            "config_elem_color_3": (200, 50, 200),
            "top_win_default_main_color": (255, 200, 50),
        },
    },

    # ── 暗黑炫彩 ──
    "暗黑炫彩": {
        "霓虹炫彩": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (20, 20, 30),
            "config_title_color": (255, 100, 200),
            "config_item_title_color": (150, 220, 255),
            "config_elem_color_1": (255, 150, 50),
            "config_elem_color_2": (100, 255, 150),
            "config_elem_color_3": (255, 50, 100),
            "top_win_default_main_color": (0, 255, 255),
        },
        "梦幻渐变": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (30, 20, 40),
            "config_title_color": (255, 180, 100),
            "config_item_title_color": (180, 150, 255),
            "config_elem_color_1": (100, 220, 255),
            "config_elem_color_2": (255, 100, 180),
            "config_elem_color_3": (100, 255, 150),
            "top_win_default_main_color": (255, 255, 100),
        },
        "海洋之心": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (10, 20, 40),
            "config_title_color": (0, 200, 255),
            "config_item_title_color": (150, 200, 255),
            "config_elem_color_1": (0, 180, 240),
            "config_elem_color_2": (50, 220, 255),
            "config_elem_color_3": (0, 150, 200),
            "top_win_default_main_color": (0, 220, 255),
        },
        "日落黄昏": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (40, 25, 30),
            "config_title_color": (255, 150, 50),
            "config_item_title_color": (255, 200, 100),
            "config_elem_color_1": (255, 120, 80),
            "config_elem_color_2": (255, 180, 120),
            "config_elem_color_3": (220, 100, 60),
            "top_win_default_main_color": (255, 160, 90),
        },
        "赛博朋克": {
            "block_alpha": 0.65, "widget_alpha": 0.60,
            "config_background": (0, 0, 20),
            "config_title_color": (0, 255, 255),
            "config_item_title_color": (255, 0, 255),
            "config_elem_color_1": (255, 100, 0),
            "config_elem_color_2": (0, 255, 100),
            "config_elem_color_3": (255, 0, 100),
            "top_win_default_main_color": (255, 255, 0),
        },
    },
}


def get_defaults() -> dict[str, object]:
    """从首个预设主题获取框架默认值。

    Returns:
        第一个主题 (小娥樱花) 的全量值
    """
    first_group = next(iter(DEFAULT_THEMES.values()))
    first_theme = next(iter(first_group.values()))
    return dict(first_theme)
