from __future__ import annotations
from xiaoe_ui.widgets.click_frame import ClickFrame, BigButton
from xiaoe_ui.widgets.use_mixin_fast_widget import (
    InstantTipLabel, InstantTipButton,
    CustomComboBox, CustomSlider,
    QPushButtonHandCursor, QCheckBoxHandCursor,
)
from xiaoe_ui.widgets.basic import flash_style
from xiaoe_ui.widgets.a_box import ABox, HideItem
from xiaoe_ui.widgets.entry import (
    SpinEntry, TextEntry, MultiEntry, ImagePicker, DatePicker,
    ColorEntry, SliderEntry,
)
from xiaoe_ui.widgets.item import (
    CheckItem, ComboItem, SliderItem, ColorItem,
    KeyItem, BottomItem, GradientItem, make_line, make_tip,
)
