from __future__ import annotations

"""即时 Tooltip mixin + 自定义弹窗 — mouse enter 立即显示，无 Qt 默认延迟。

统一使用自定义 _TooltipPopup 替代 QToolTip，可 QSS 样式化。
"""

from PySide6.QtCore import Qt, QPoint, QTimer
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget


class _TooltipPopup(QWidget):
    """自定义 tooltip 弹窗，frameless + 总在最前，QSS class ``xiaoe-tooltip``。"""

    def __init__(self):
        super().__init__(None)
        self.setWindowFlags(
            Qt.ToolTip |
            Qt.FramelessWindowHint |
            Qt.WindowStaysOnTopHint
        )
        self.setWindowFlags(
            Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint |
            Qt.Tool | Qt.X11BypassWindowManagerHint |
            Qt.WindowTransparentForInput
        )
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        from xiaoe_ui.core.win_manager import WinManager
        self.setStyleSheet(WinManager._style_source())

        root_layout = QVBoxLayout(self)
        root_layout.setContentsMargins(0, 0, 0, 0)

        root_widget = QWidget()
        root_layout.addWidget(root_widget)
        root_widget.setProperty("class", "xiaoe-tooltip")

        layout = QVBoxLayout(root_widget)
        layout.setContentsMargins(6, 4, 6, 4)

        self.label = QLabel()
        self.label.setProperty("class", "tip-text")
        layout.addWidget(self.label)


        self.hide()

    def show_at(self, text: str, anchor: QPoint):
        """anchor = 控件上的锚点（全局坐标）。tooltip 底部对齐 anchor.y，显示在上方。"""
        self.label.setText(text)
        self.adjustSize()
        self.move(anchor - QPoint(0, self.height()))
        self.show()

    def update_text(self, text: str):
        self.label.setText(text)


class InstantTooltipMixin:
    """即时 Tooltip mixin — 可混入任意 Qt 控件。

    必须放在继承列表最左侧，确保 __init__ / enterEvent / leaveEvent 覆盖 Qt 基类::

        class MyWidget(InstantTooltipMixin, QLabel):
            pass

    Args (实例属性):
        _tip_locked: 子类可设为 True，阻止 leaveEvent 隐藏 tooltip（拖拽中）
        _bound_tips: 绑定的其他 mixin 实例列表，hover self 时也弹出它们的 tooltip
    """

    def __init__(self, *args, **kwargs):
        self._default_tip: str | None = None
        self._tip_popup: _TooltipPopup | None = None
        self._tip_locked: bool = False
        self._tip_suppressed: bool = False
        self._bound_tips: list[InstantTooltipMixin] = []
        self._tip_timer = QTimer()
        self._tip_timer.setInterval(0)
        self._tip_timer.setSingleShot(True)
        self._tip_timer.timeout.connect(self._show_tip)
        super().__init__(*args, **kwargs)

    # ── 拦截 Qt 原生 tooltip ──

    def setToolTip(self, text: str):
        """存储 tooltip 文本，不调用 Qt 原生 setToolTip，阻止系统 tooltip 弹出。"""
        self._tip_text = text

    def toolTip(self) -> str:
        return getattr(self, '_tip_text', '')

    # ── 子类可重载 ──

    def _get_tip_text(self) -> str:
        """返回 tooltip 文本。子类重载以提供动态内容。"""
        if self._tip_suppressed:
            return ""
        return self.toolTip()

    def _tip_offset(self) -> QPoint:
        """返回相对控件左上角的偏移量。子类重载以自定义定位。"""
        return QPoint(0, 0)

    @property
    def tip_suppressed(self) -> bool:
        return self._tip_suppressed

    @tip_suppressed.setter
    def tip_suppressed(self, v: bool):
        self._tip_suppressed = v

    # ── 核心方法 ──

    def _get_or_create_popup(self) -> _TooltipPopup:
        import shiboken6
        if self._tip_popup is None or not shiboken6.isValid(self._tip_popup):
            self._tip_popup = _TooltipPopup()
        return self._tip_popup

    def show_tip(self, text: str = None):
        """显示 tooltip。text 为 None 则使用 ``_get_tip_text()``。

        公开方法，可由外部手动触发。
        """
        if self._tip_suppressed:
            return
        if text is None:
            text = self._get_tip_text()
        if not text:
            return
        popup = self._get_or_create_popup()
        popup.show_at(text, self.mapToGlobal(self._tip_offset()))

    def hide_tip(self):
        """隐藏 tooltip。公开方法，可由外部手动触发。"""
        if self._tip_popup and self._tip_popup.isVisible():
            self._tip_popup.hide()
        self._tip_timer.stop()

    def update_tip(self, text: str):
        """更新已显示 tooltip 的文本，不重新定位/shown。"""
        if self._tip_suppressed or not text:
            return
        popup = self._get_or_create_popup()
        popup.update_text(text)
        if not popup.isVisible():
            popup.show_at(text, self.mapToGlobal(self._tip_offset()))

    def bind_tip(self, other: InstantTooltipMixin):
        """绑定另一个 mixin 实例：hover self 时也弹出 other 的 tooltip。

        单向绑定，需双向则双方各调一次。
        """
        if other not in self._bound_tips:
            self._bound_tips.append(other)

    # ── 内部 ──

    def _show_tip(self):
        if self._tip_suppressed:
            return
        text = self._get_tip_text()
        if not text:
            return
        popup = self._get_or_create_popup()
        popup.show_at(text, self.mapToGlobal(self._tip_offset()))
        for b in self._bound_tips:
            b.show_tip()

    def show_tip_text(self, text: str = None):
        """临时替换 tooltip 文本并立即显示。传 None 恢复默认。"""
        if text is not None:
            self._default_tip = self.toolTip()
            self.setToolTip(text)
        elif self._default_tip is not None:
            self.setToolTip(self._default_tip)
            self._default_tip = None
        self._tip_timer.start()

    # ── Qt 事件 ──

    def enterEvent(self, event):
        super().enterEvent(event)
        self._tip_timer.start()

    def leaveEvent(self, event):
        super().leaveEvent(event)
        if not self._tip_locked:
            self.hide_tip()
            for b in self._bound_tips:
                b.hide_tip()


