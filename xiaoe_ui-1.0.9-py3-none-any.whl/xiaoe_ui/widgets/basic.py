"""基础控件覆盖和工具函数。"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget


# ── 手型鼠标覆盖 Mixin ──
class HandCursorMixin:
    def __init__(self: QWidget, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setCursor(Qt.PointingHandCursor)


# ── 忽略滚轮 Mixin ──
class IgnoreWheelMixin:
    """忽略滚轮事件的组合框，防止误触滚动改变选项。"""
    def wheelEvent(self: QWidget, event):
        event.ignore()


# ── 样式刷新 ──

def flash_style(widget: QWidget):
    """强制 Qt 重新计算动态属性样式。"""
    cls = widget.property("class")
    widget.setProperty("class", "")
    widget.style().unpolish(widget)
    widget.setProperty("class", cls)
    widget.style().polish(widget)
