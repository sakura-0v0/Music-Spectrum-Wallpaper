"""配置控件，签名对齐 small_map。有 config 时双绑 + 互刷新，无 config 时走 callback + default。

每个控件: [title:　<6] [stretch] [text] [control...]
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Callable

from PySide6.QtCore import Qt, QDate, QDateTime, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QVBoxLayout,
    QWidget,
)

from xiaoe_ui.widgets.use_mixin_fast_widget import QPushButtonHandCursor
from xiaoe_ui.widgets.basic import flash_style
from xiaoe_ui.widgets.click_frame import ClickFrame
from xiaoe_ui.widgets.use_mixin_fast_widget import InstantTipButton, InstantTipLabel
from xiaoe_ui.widgets.form_layout import make_form_row
from xiaoe_ui.widgets.gradient import GradientBar
from xiaoe_ui.utils.dpi import title_min_width

from xiaoe_ui.config.bridge import ConfigBridge

# Layer 2 组件从 entry.py 重新导出 (保持兼容)
from xiaoe_ui.widgets.entry import (
    SpinEntry, TextEntry, MultiEntry, ImagePicker, DatePicker,
    ColorEntry, SliderEntry, CheckEntry, ComboEntry,
)


# ═══════════════════════════════════════════════════════════════
# FlashManager — tag 机制闪烁配置项
# ═══════════════════════════════════════════════════════════════

class _FlashRegistry:
    """配置项闪烁管理器（模块级单例），按 tag 批量闪烁已注册的 ClickFrame。

    L3 配置项传 tag 参数即自动注册，调用方只需 flash_config_widget(tag)。
    """

    def __init__(self):
        self._registry: dict[str, list] = {}

    def register(self, tag: str, frame):
        self._registry.setdefault(tag, []).append(frame)

    def flash(self, tag: str, times: int = 5, interval_ms: int = 150):
        """闪烁指定 tag 的所有已注册配置项。

        Args:
            tag: 注册时的标签
            times: 闪烁次数 (一亮一暗 = 1 次)
            interval_ms: 间隔毫秒
        """
        frames = self._registry.get(tag, [])
        for frame in frames:
            self._flash_frame(frame, times, interval_ms)

    def _flash_frame(self, frame, times: int, interval_ms: int):
        def _step(n):
            if n >= times * 2:
                frame.set_light(False)
                return
            frame.set_light(n % 2 == 0)
            QTimer.singleShot(interval_ms, lambda: _step(n + 1))
        _step(0)


_flash_registry = _FlashRegistry()


def register_tag(tag: str, frame):
    """手动注册任意 ClickFrame 到闪烁注册表。

    配置项传 tag 参数即自动注册，无需手动调用。
    仅在需要闪烁非 L3 配置项的 ClickFrame 时使用。

    Args:
        tag: 标签，同 flash_config_widget 共用
        frame: ClickFrame 实例
    """
    _flash_registry.register(tag, frame)


def flash_config_widget(tag: str, times: int = 5, interval_ms: int = 150):
    """闪烁指定 tag 的所有配置项。

    Args:
        tag: 配置项的 tag 参数或 register_tag 注册的标签
        times: 闪烁次数
        interval_ms: 间隔毫秒
    """
    _flash_registry.flash(tag, times, interval_ms)


# ── 重置确认 ──

def _confirm_reset(title: str) -> bool:
    """弹出确认对话框，询问是否重置某配置项。

    Args:
        title: 配置项标题

    Returns:
        True=确认重置
    """
    from xiaoe_ui.utils.msg_box import ask
    return ask("重置", f"确定要重置{title}吗？")


def _do_reset(config: ConfigBridge, key: str, title: str, callback: Callable = None):
    """确认后执行 config.reset，可选触发回调。

    Args:
        config: 配置桥接
        key: 配置键名
        title: 用于确认弹窗的标题
        callback: 重置后调用，签名为 (new_value) -> None
    """
    if _confirm_reset(title):
        config.reset(key)
        if callback:
            callback(config.get(key))


# ── 分隔线 ──

def make_line(parent_layout: QVBoxLayout | QHBoxLayout,
              bold: bool = True,
              ):
    """添加水平分隔线。

    Args:
        parent_layout: 父布局
        bold: True=粗线, False=细线
    """
    sep = QFrame()
    sep.setFrameStyle(QFrame.HLine)
    sep.setProperty("class", "bold-line" if bold else "ligh-line")
    parent_layout.addWidget(sep)


def make_tip(text: str,
             parent_layout: QVBoxLayout | QHBoxLayout = None,
             ) -> ClickFrame:
    """创建小字提示行，外观与配置项一致但不可交互。

    Args:
        text: 提示文字，支持 \\n 换行
        parent_layout: 父布局，非 None 则自动 addWidget

    Returns:
        ClickFrame(light-line disable) 包含 tip-text 标签
    """
    row = ClickFrame(hand_cursor=False, custom_class="light-line disable")
    layout = QHBoxLayout(row)
    layout.setContentsMargins(5, 3, 5, 3)
    label = QLabel(text)
    label.setProperty("class", "tip-text")
    layout.addWidget(label)
    layout.addStretch(1)
    if parent_layout is not None:
        parent_layout.addWidget(row)
    return row


# ═══════════════════════════════════════════════════════════════
# CheckItem
# ═══════════════════════════════════════════════════════════════

class CheckItem(QWidget):
    """布尔配置项: title + text + CheckEntry。

    Args:
        title: 左侧标签
        text: 描述文字
        config / config_name: 配置双绑
        callback: 值变化回调
        default_check: 无 config 时的默认值
        tag: 闪烁标签，调用 flash_config_widget(tag) 闪烁
        parent_layout: 父布局
    """

    def __init__(self,
                 title: str,
                 text: str = "",
                 config: ConfigBridge = None,
                 config_name: str = None,
                 callback: Callable[[bool], None] = None,
                 default_check: bool = False,
                 text_align_right: bool = True,
                 tag: str = None,
                 parent_layout: QVBoxLayout | QHBoxLayout = None,
                 ):
        super().__init__()
        self._use_config = bool(config and config_name)

        inner = ClickFrame(hand_cursor=False, custom_class="light-line disable")
        layout = QHBoxLayout(inner)
        layout.setContentsMargins(5, 3, 5, 3)

        name_label = QLabel(title)
        name_label.setProperty("class", "line_title")
        name_label.setMinimumWidth(title_min_width())
        layout.addWidget(name_label)
        layout.addStretch(1)

        if text:
            desc_label = QLabel(text)
            desc_label.setProperty("class", "tip-text")
            if text_align_right:
                desc_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            layout.addWidget(desc_label)

        _cfg = config if self._use_config else None
        _key = config_name if self._use_config else None
        layout.addWidget(CheckEntry(
            config=_cfg, config_name=_key,
            default=default_check, callback=callback,
        ))

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(inner)

        self._inner = inner
        if tag:
            _flash_registry.register(tag, inner)

        if parent_layout is not None:
            parent_layout.addWidget(self)


# ═══════════════════════════════════════════════════════════════
# ComboItem
# ═══════════════════════════════════════════════════════════════

class ComboItem(QWidget):
    """下拉配置项: title + text + ComboEntry。

    Args:
        title: 左侧标签
        text: 描述文字
        options: 选项列表
        config / config_name: 配置双绑
        store_index: True=存索引, False=存原始值
        callback: 值变更回调（参数类型取决于 store_index）
        default_index: 默认选中索引
        width: 下拉框宽度
        parent_layout: 父布局
    """

    def __init__(self,
                 title: str,
                 text: str = "",
                 options: list = None,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 callback: Callable = None,
                 default_index: int = 0,
                 width: int = 120,
                 store_index: bool = False,
                 tag: str = None,
                 parent_layout: QVBoxLayout | QHBoxLayout = None,
                 ):
        super().__init__()
        if options is None:
            options = []
        self._use_config = bool(config and config_name)

        inner = ClickFrame(hand_cursor=False, custom_class="light-line disable")
        layout = QHBoxLayout(inner)
        layout.setContentsMargins(5, 3, 5, 3)

        name_label = QLabel(title)
        name_label.setProperty("class", "line_title")
        name_label.setMinimumWidth(title_min_width())
        layout.addWidget(name_label)
        layout.addStretch(1)

        if text:
            desc_label = QLabel(text)
            desc_label.setProperty("class", "tip-text")
            layout.addWidget(desc_label)

        _cfg = config if self._use_config else None
        _key = config_name if self._use_config else None
        cur = config.get(config_name) if self._use_config else None
        if store_index:
            idx = cur if isinstance(cur, int) else default_index
        else:
            try:
                idx = options.index(cur)
            except (ValueError, TypeError):
                idx = default_index
        self._entry = ComboEntry(
            config=_cfg, config_name=_key,
            options=options, default_index=idx, width=width,
            store_index=store_index, callback=callback,
        )
        layout.addWidget(self._entry)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(inner)

        self._inner = inner
        if tag:
            _flash_registry.register(tag, inner)

        if parent_layout is not None:
            parent_layout.addWidget(self)


# ═══════════════════════════════════════════════════════════════
# SliderItem
# ═══════════════════════════════════════════════════════════════
def _set_spin_status(spin: QWidget, status: str):
    """同 _set_status: 设 status 属性 → flash_style，success 时 5 秒自动恢复。"""
    spin.setProperty("status", status)
    flash_style(spin)
    if status == "success":
        if hasattr(spin, '_st_timer') and spin._st_timer:
            spin._st_timer.stop()
        spin._st_timer = QTimer(spin)
        spin._st_timer.setSingleShot(True)
        spin._st_timer.timeout.connect(
            lambda: (
                spin.setProperty("status", "normal"),
                flash_style(spin),
            ) if spin.property("status") == "success" else None
        )
        spin._st_timer.start(5000)


class SliderItem(QWidget):
    """滑块配置项: title + SliderEntry + SpinEntry + 重置。
    SliderEntry 和 SpinEntry 共享 config_name，自动互相同步。
    decimals 自动从 step 推导。

    Args:
        title: 左侧标签
        text: 悬浮提示 (tooltip)
        config / config_name: 配置双绑
        config_range: (min, max)
        step: 步进，同时决定 int/float 和小数位数
        live: True=拖动时实时提交，False=松手时提交
        callback: 值变更回调
        parent_layout: 父布局
    """

    def __init__(self,
                 title: str,
                 text: str = "",
                 config: ConfigBridge = None,
                 config_name: str = None,
                 config_range: tuple = None,
                 step: float = 1,
                 num_type_text: str = "",
                 live: bool = True,
                 callback: Callable = None,
                 tag: str = None,
                 parent_layout: QVBoxLayout | QHBoxLayout = None,
                 ):
        super().__init__()
        self._config = config
        self._key = config_name
        self._use_config = bool(config and config_name)

        inner = ClickFrame(hand_cursor=False, custom_class="light-line disable")
        layout = QHBoxLayout(inner)
        layout.setContentsMargins(5, 3, 5, 3)

        name_label = InstantTipLabel(title)
        name_label.setProperty("class", "line_title")
        name_label.setMinimumWidth(title_min_width())
        if text:
            name_label.setToolTip(text)
        layout.addWidget(name_label)

        if self._use_config:
            _cfg, _key = config, config_name
        else:
            _cfg = ConfigBridge.memory({config_name or "value": 0})
            _key = config_name or "value"

        slider = SliderEntry(
            config=_cfg, config_name=_key,
            config_range=config_range or (0, 100), step=step,
            num_type_text=num_type_text, live=live,
            callback=callback,
        )
        spin = SpinEntry(
            config=_cfg, config_name=_key,
            config_range=config_range or (0, 100), step=step,
            live=True, width=100, callback=callback,
        )

        reset_btn = QPushButtonHandCursor("重置")
        reset_btn.setProperty("class", "small reset")
        if self._use_config:
            reset_btn.clicked.connect(
                lambda: _do_reset(config, config_name, title, callback))

        # 滑块 tip 全部重定向到标题，标题显示合并信息
        s = slider._slider
        def _merged_tip():
            val = f"范围：{s.range_text} - 当前：{s.value_text} {s.num_type_text}".rstrip()
            return f"{text}  |  {val}" if text else val
        name_label._get_tip_text = _merged_tip
        # leaveEvent 会通过 _bound_tips 关掉对方 popup
        s.bind_tip(name_label)
        # hover：timer 重连到新 _show_tip
        s._show_tip = lambda: name_label.show_tip()
        s._tip_timer.timeout.disconnect()
        s._tip_timer.timeout.connect(s._show_tip)
        # 拖拽 → 标题 popup
        s.show_tip = lambda *a, **kw: name_label.show_tip()
        s.update_tip = lambda t: name_label.update_tip(_merged_tip())
        s.hide_tip = lambda: name_label.hide_tip()

        layout.addWidget(slider, 1)
        layout.addWidget(reset_btn)
        layout.addWidget(spin)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(inner)

        self._inner = inner
        if tag:
            _flash_registry.register(tag, inner)

        if parent_layout is not None:
            parent_layout.addWidget(self)


# ═══════════════════════════════════════════════════════════════
# ColorItem
# ═══════════════════════════════════════════════════════════════

class ColorItem(QWidget):
    """颜色配置项: title + ColorEntry + 重置。

    Args:
        title: 左侧标签
        text: 描述文字
        config / config_name: 配置双绑
        default_color: 无 config 时的默认色
        rgba: True 支持透明度
        btn_text: 按钮文字
        callback: 值变更回调
        parent_layout: 父布局
    """

    def __init__(self,
                 title: str,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 text: str = "",
                 default_color: tuple = (255, 0, 0),
                 rgba: bool = False,
                 btn_text: str = "设置",
                 callback: Callable = None,
                 tag: str = None,
                 parent_layout: QVBoxLayout | QHBoxLayout = None,
                 ):
        super().__init__()
        self._config = config
        self._key = config_name
        self._cb_callback = callback
        self._use_config = bool(config and config_name)

        inner = ClickFrame(hand_cursor=False, custom_class="light-line disable")
        layout = QHBoxLayout(inner)
        layout.setContentsMargins(5, 3, 5, 3)

        name_label = QLabel(title)
        name_label.setProperty("class", "line_title")
        name_label.setMinimumWidth(title_min_width())
        layout.addWidget(name_label)
        layout.addStretch(1)

        if text:
            desc_label = QLabel(text)
            desc_label.setProperty("class", "tip-text")
            layout.addWidget(desc_label)

        _cfg = config if self._use_config else None
        _key = config_name if self._use_config else None
        self._entry = ColorEntry(
            config=_cfg, config_name=_key,
            rgba=rgba, text=btn_text, default=default_color,
            callback=callback,
        )

        reset_btn = QPushButtonHandCursor("重置")
        reset_btn.setProperty("class", "small reset")
        if self._use_config:
            reset_btn.clicked.connect(
                lambda: _do_reset(config, config_name, title, callback))

        layout.addWidget(reset_btn)
        layout.addWidget(self._entry)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(inner)

        self._inner = inner
        if tag:
            _flash_registry.register(tag, inner)

        if parent_layout is not None:
            parent_layout.addWidget(self)

    @property
    def value(self) -> tuple:
        return self._entry.color()


# ═══════════════════════════════════════════════════════════════
# BottomItem
# ═══════════════════════════════════════════════════════════════

class BottomItem(QWidget):
    """操作按钮项: title + text + 重置 + 确认/取消按钮。

    Args:
        title: 左侧标签
        text: 描述文字
        text_tooltip: 悬浮提示
        btn_text: 主按钮文字，默认 "设置"
        btn_bg: 按钮背景色 rgba 元组，如 (0,200,100,180)
        btn_class: 按钮 QSS class
        callback: 主按钮点击回调
        cancel_callback: 取消回调。设置后按钮可切换 设置/取消 状态
        btn_cancel_text: 取消状态按钮文字
        btn_cancel_bg: 取消状态按钮背景
        reset_callback: 重置按钮回调
        parent_layout: 父布局
    """

    def __init__(self,
                 title: str,
                 text: str = "",
                 text_tooltip: str = None,
                 btn_text: str = "设置",
                 btn_bg: tuple[int, int, int, int] = None,
                 btn_class: str = None,
                 callback: Callable = None,
                 cancel_callback: Callable = None,
                 btn_cancel_text: str = None,
                 btn_cancel_bg: tuple[int, int, int, int] = (220, 220, 0, 180),
                 reset_callback: Callable = None,
                 tag: str = None,
                 parent_layout: QVBoxLayout | QHBoxLayout = None,
                 ):
        super().__init__()
        self._callback = callback
        self._cancel_callback = cancel_callback
        self._btn_text = btn_text
        self._btn_cancel_text = btn_cancel_text
        self._btn_cancel_bg = btn_cancel_bg
        self._cancel_status = False

        inner = ClickFrame(hand_cursor=False, custom_class="light-line disable")
        layout = QHBoxLayout(inner)
        layout.setContentsMargins(5, 3, 5, 3)

        # 标题
        title_label = QLabel(title)
        title_label.setProperty("class", "line_title")
        title_label.setMinimumWidth(title_min_width())
        if text_tooltip:
            title_label.setToolTip(text_tooltip)
        layout.addWidget(title_label)
        layout.addStretch(1)

        # 描述
        self._desc_label: QLabel | None = None
        if text:
            self._desc_label = QLabel(text)
            self._desc_label.setProperty("class", "tip-text")
            if text_tooltip:
                self._desc_label.setToolTip(text_tooltip)
            layout.addWidget(self._desc_label)

        # 重置按钮
        if reset_callback:
            reset_btn = QPushButtonHandCursor("重置")
            reset_btn.setProperty("class", "small reset")
            reset_btn.clicked.connect(
                lambda: (reset_callback() if _confirm_reset(title) else None))
            layout.addWidget(reset_btn)

        # 主按钮
        self._btn = QPushButtonHandCursor(btn_text)
        if btn_class:
            self._btn.setProperty("class", btn_class)
        if btn_bg:
            self._btn.setStyleSheet(f"background-color:rgba{btn_bg}")
        self._btn.clicked.connect(self._run)
        layout.addWidget(self._btn)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(inner)

        self._inner = inner
        if tag:
            _flash_registry.register(tag, inner)

        if parent_layout is not None:
            parent_layout.addWidget(self)

    def setText(self,
                text: str,
                ):
        """更新描述文字。

        Args:
            text: 新文字
        """
        if self._desc_label is not None:
            self._desc_label.setText(text)

    def _run(self):
        """按钮点击: 处理 callback / cancel_callback 切换逻辑。"""
        if self._cancel_callback is not None:
            if self._cancel_status:
                self._cancel_callback()
                self._btn.setText(self._btn_text)
                self._btn.setStyleSheet("")
                self._cancel_status = False
            else:
                if self._callback:
                    self._callback()
                self._btn.setText(self._btn_cancel_text)
                self._btn.setStyleSheet(
                    f"background-color: rgba{self._btn_cancel_bg}")
                self._cancel_status = True
        else:
            if self._callback:
                self._callback()


# ═══════════════════════════════════════════════════════════════
# KeyItem
# ═══════════════════════════════════════════════════════════════

KEY_NAME_MAP: dict[str, str] = {
    "mouse_right": "鼠标右键",
    "mouse_middle": "鼠标中键",
    "mouse_x": "鼠标后退键",
    "mouse_x2": "鼠标前进键",
}

class KeyItem(QWidget):
    """按键绑定项: title + 按键显示 + 设置按钮（右键解绑/重置）。

    需要 xiaoe_keyboard.Keyboard 实例，同 small_map enable_set_key 逻辑。

    Args:
        title: 左侧标签
        config / config_name: 同 CheckItem
        text: 悬浮提示
        keyboard: xiaoe_keyboard.Keyboard 实例
        parent_layout: 父布局
    """

    def __init__(self,
                 title: str,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 text: str = "",
                 keyboard=None,
                 tag: str = None,
                 parent_layout: QVBoxLayout | QHBoxLayout = None,
                 ):
        try:
            import xiaoe_keyboard  # noqa: F401
        except ImportError:
            raise ImportError(
                "KeyItem 需要 xiaoe_keyboard 库，请执行: pip install xiaoe_keyboard"
            )
        super().__init__()
        self._config = config
        self._key = config_name
        self._keyboard = keyboard

        inner = ClickFrame(hand_cursor=False, custom_class="light-line disable")
        layout = QHBoxLayout(inner)
        layout.setContentsMargins(5, 3, 5, 3)

        name_label = InstantTipLabel(title)
        name_label.setProperty("class", "line_title")
        name_label.setMinimumWidth(title_min_width())
        if text:
            name_label.setToolTip(text)
        layout.addWidget(name_label)

        # 按键显示区
        self._key_layout = QHBoxLayout()
        self._update_key_display()
        layout.addLayout(self._key_layout)
        layout.addStretch(1)

        # 设置按钮（左键设置，右键上下文菜单）
        self._set_btn = InstantTipButton("设置")
        self._set_btn.clicked.connect(self._on_set_click)
        self._set_btn.setContextMenuPolicy(Qt.CustomContextMenu)
        self._set_btn.customContextMenuRequested.connect(self._on_right_click)
        self._set_btn.setToolTip("右键按钮可解绑、重置按键")
        layout.addWidget(self._set_btn)

        self._set_btn.bind_tip(name_label)
        name_label.bind_tip(self._set_btn)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(inner)

        self._inner = inner
        if tag:
            _flash_registry.register(tag, inner)

        if self._config and self._key:
            self._config.value_changed.connect(self._on_config_change)

        if parent_layout is not None:
            parent_layout.addWidget(self)

    # ── 显示 ──

    def _update_key_display(self):
        """从 config 读取按键列表并刷新显示，KEY_NAME_MAP 映射鼠标名。"""
        while self._key_layout.count():
            item = self._key_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        keys = self._config.get(self._key) if self._config and self._key else []
        for k in keys:
            name = KEY_NAME_MAP.get(k, k) if k else "未绑定"
            kl = QLabel(str(name))
            kl.setProperty("class", "key-label")
            self._key_layout.addWidget(kl)

    def _update_key_display_with_wait(self):
        """捕获模式中显示「等待组合键...」。"""
        while self._key_layout.count():
            item = self._key_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        kl = QLabel("等待组合键...")
        kl.setProperty("class", "key-label")
        self._key_layout.addWidget(kl)

    def _on_config_change(self,
                          key: str,
                          _,
                          ):
        """config 变更 → 刷新显示并恢复按钮状态。"""
        if key == self._key:
            self._set_btn.setText("设置")
            self._set_btn.setProperty("key-capturing", False)
            flash_style(self._set_btn)
            self._update_key_display()

    # ── 设置按钮 ──

    def _on_set_click(self):
        """切换捕获模式 (同 small_map enable_set_key)。"""
        if self._keyboard is None:
            return
        if self._keyboard.get_hotkey_setting() is None:
            # 开始捕获
            self._keyboard.set_hotkey_setting(self._key)
            self._set_btn.setText("取消")
            self._set_btn.setProperty("key-capturing", True)
            flash_style(self._set_btn)
            self._update_key_display_with_wait()
        else:
            # 取消捕获
            self._keyboard.set_hotkey_setting(None)
            self._set_btn.setText("设置")
            self._set_btn.setProperty("key-capturing", False)
            flash_style(self._set_btn)
            self._update_key_display()

    # ── 右键菜单 ──

    def _on_right_click(self,
                        _pos,
                        ):
        """右键弹窗: 解绑 / 重置 / 取消。"""
        from xiaoe_ui.utils.msg_box import ask
        result = ask(f"更多按键设置 - 【{self._key}】",
                     f"解绑或重置【{self._key}】",
                     yes_text="解绑", no_text="重置", with_cancel=True)
        if result is True:
            self._clear_key()
        elif result is False:
            self._reset_key()

    def _clear_key(self):
        """解绑: 设为 [None] 并同步 keyboard。"""
        if self._config and self._key:
            self._config.set(self._key, [None])
            self._sync_keyboard()

    def _reset_key(self):
        """重置为默认值并同步 keyboard。"""
        if self._config and self._key:
            self._config.reset(self._key)
            self._sync_keyboard()

    def _sync_keyboard(self):
        """将 config 中的按键同步到 keyboard。"""
        if self._keyboard:
            keys = self._config.get(self._key)
            self._keyboard.set_one_hotkey_dict(
                self._key, set(keys) if keys else set())


# TextEntry / SpinEntry / MultiEntry / ImagePicker / DatePicker
# 已迁移至 xiaoe_ui.widgets.entry (Layer 2)，此处通过顶部 re-export 提供。
# ═══════════════════════════════════════════════════════════════

# GradientItem
# ═══════════════════════════════════════════════════════════════

class GradientItem(QWidget):
    """渐变色配置项: title + GradientBar + config 绑定。

    Args:
        title: 左侧标签
        config / config_name: 配置双绑
        text: 描述文字
        default: 无 config 时的默认色标列表
        callback: 值变更回调
        parent_layout: 父布局
    """

    def __init__(self,
                 title: str,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 text: str = "",
                 default: list[dict] | None = None,
                 callback: Callable = None,
                 tag: str = None,
                 parent_layout: QVBoxLayout | QHBoxLayout = None,
                 ):
        super().__init__()
        self._config = config
        self._key = config_name
        self._cb_callback = callback
        self._use_config = bool(config and config_name)
        from xiaoe_ui.widgets.status_widgets import ColorPickerButton

        if default is None:
            default = [
                {"pos": 0.0, "color": (255, 255, 255, 255)},
                {"pos": 1.0, "color": (0, 0, 0, 255)},
            ]

        self._bg_key = "preview_bg"
        self._bg_config = ConfigBridge.memory({self._bg_key: (255, 255, 255, 0)})
        self._bg_config.value_changed.connect(self._on_bg_config_read)

        inner = ClickFrame(hand_cursor=False, custom_class="light-line disable")
        layout = QHBoxLayout(inner)
        layout.setContentsMargins(5, 3, 5, 3)

        name_label = InstantTipLabel(title)
        name_label.setProperty("class", "line_title")
        name_label.setMinimumWidth(title_min_width())
        if text:
            name_label.setToolTip(text)
        layout.addWidget(name_label)

        reset_btn = QPushButtonHandCursor("重置")
        reset_btn.setProperty("class", "small reset")
        if self._use_config:
            reset_btn.clicked.connect(
                lambda: _do_reset(config, config_name, title, callback))
        else:
            reset_btn.clicked.connect(
                lambda: (self._bar.setStops(default),
                         callback(default) if callback else None)
            )
        layout.addWidget(reset_btn)

        cur = config.get(config_name) if self._use_config else default
        self._bar = GradientBar(stops=cur)
        self._bar.valueChanged.connect(self._on_commit)
        self._bar.setPreviewBg(self._bg_config.get(self._bg_key))

        # 预览背景 RGBA 按钮 (重置右边, 渐变条左边)
        self._preview_btn = ColorPickerButton(
            color=tuple(self._bg_config.get(self._bg_key)),
            rgba=True,
            tooltip_text="选择渐变条的预览背景色，默认全透明，不会保存到配置",
            dialog_title="选择渐变条的预览背景色，默认全透明，不会保存到配置",
        )
        self._preview_btn.colorChanged.connect(self._on_bg_pick)
        layout.addWidget(self._preview_btn)
        layout.addWidget(self._bar, 1)

        if self._use_config:
            config.value_changed.connect(self._on_config_read)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(inner)

        self._inner = inner
        if tag:
            _flash_registry.register(tag, inner)

        if parent_layout is not None:
            parent_layout.addWidget(self)

    def _on_bg_pick(self, val: tuple):
        self._bg_config.set(self._bg_key, val)
        self._bar.setPreviewBg(val)

    def _on_bg_config_read(self, key: str, new_val):
        if key == self._bg_key:
            self._bar.setPreviewBg(new_val)
            self._preview_btn.setColor(new_val)

    @property
    def value(self) -> list[dict]:
        return self._bar.stops()

    def _on_commit(self, stops: list[dict]):
        if self._use_config:
            self._config.set(self._key, stops)
        if self._cb_callback:
            self._cb_callback(stops)

    def _on_config_read(self, key: str, new_val):
        if key == self._key and new_val is not None:
            self._bar.setStops(new_val)
