"""CustomSpinBox — StatusLineEdit + ▲/▼ 按钮, 长按连发。"""

from __future__ import annotations

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QHBoxLayout, QPushButton, QVBoxLayout, QWidget,
)


class CustomSpinBox(QWidget):
    """数字编辑框：StatusLineEdit + ▲/▼ 按钮。

    step 为 int 且 decimals=0 → int 模式，否则 float。
    长按按钮 300ms 后每 50ms 连发。

    Args:
        min_val / max_val: 范围
        value: 初始值
        step: 步长
        decimals: 小数位数
        prefix / suffix: 前/后缀
        live: True → 按钮点击立即提交
        height: 组件高度
    """

    valueChanged = Signal(object)
    editingFinished = Signal()

    def __init__(self, parent: QWidget = None,
                 min_val: float = 0, max_val: float = 100,
                 value: float = 0,
                 step: float = 1, decimals: int = 0,
                 prefix: str = "", suffix: str = "",
                 live: bool = False, height: int = 28):
        super().__init__(parent)
        self._min = min_val
        self._max = max_val
        self._step = step
        self._decimals = decimals
        self._live = live
        self._prefix = prefix
        self._suffix = suffix
        self._is_float = isinstance(step, float) or decimals > 0
        self._direction = 0
        self._baseline = value

        from xiaoe_ui.widgets.status_widgets import StatusLineEdit

        cur = self._fmt(value)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        if self._is_float:
            def _v(s):
                return round(float(s), self._decimals)
            self._edit = StatusLineEdit(text=cur, value_type=_v)
        else:
            self._edit = StatusLineEdit(text=cur, value_type=int)

        self._edit.setCursor(Qt.IBeamCursor)
        self._edit.editingFinished.connect(self._on_edit_commit)
        layout.addWidget(self._edit, 1)

        btn_layout = QVBoxLayout()
        btn_layout.setContentsMargins(0, 0, 0, 0)
        btn_layout.setSpacing(0)

        self._btn_up = QPushButton("▲")
        self._btn_down = QPushButton("▼")
        for b in [self._btn_up, self._btn_down]:
            b.setProperty("class", "spin-btn")
            b.setCursor(Qt.PointingHandCursor)
            b.setFocusPolicy(Qt.NoFocus)
            b.setFixedSize(18, height // 2)
        btn_layout.addWidget(self._btn_up)
        btn_layout.addWidget(self._btn_down)
        layout.addLayout(btn_layout)

        self.setFixedHeight(height)

        self._btn_up.pressed.connect(lambda: self._start_long(1))
        self._btn_up.released.connect(self._stop_long)
        self._btn_down.pressed.connect(lambda: self._start_long(-1))
        self._btn_down.released.connect(self._stop_long)

        self._long_timer = QTimer(self)
        self._long_timer.setSingleShot(True)
        self._long_timer.timeout.connect(self._start_repeat)
        self._repeat_timer = QTimer(self)
        self._repeat_timer.setInterval(50)
        self._repeat_timer.timeout.connect(self._repeat_step)

    # ── display ──

    def _fmt(self, val: float) -> str:
        p = self._prefix or ""
        s = self._suffix or ""
        if self._is_float:
            return f"{p}{val:.{self._decimals}f}{s}"
        return f"{p}{int(val)}{s}"

    def _parse_val(self) -> float | int:
        try:
            t = self._edit.text()
            if self._prefix:
                t = t[len(self._prefix):]
            if self._suffix:
                t = t[:-len(self._suffix)]
            if self._is_float:
                return float(t)
            return int(t)
        except (ValueError, TypeError):
            return self._min

    # ── buttons ──

    def _start_long(self, direction: int):
        self._direction = direction
        self._step_once()
        if self._live:
            self._commit()
        else:
            self._edit.update_baseline(self._fmt(self._parse_val()))
        self._long_timer.start(300)

    def _start_repeat(self):
        self._repeat_timer.start()

    def _repeat_step(self):
        self._direction and self._step_once()
        if self._live:
            self._commit()
        else:
            self._edit.update_baseline(self._fmt(self._parse_val()))

    def _stop_long(self):
        self._long_timer.stop()
        self._repeat_timer.stop()
        if not self._live:
            self._commit()

    def _step_once(self):
        val = self._parse_val() + self._direction * self._step
        val = max(self._min, min(self._max, val))
        if self._is_float:
            val = round(val, self._decimals)
        else:
            val = int(val)
        self._edit.blockSignals(True)
        self._edit.setText(self._fmt(val))
        self._edit.blockSignals(False)
        self._baseline = val

    # ── editing ──

    def _on_edit_commit(self):
        val = self._parse_val()
        val = max(self._min, min(self._max, val))
        if self._is_float:
            val = round(val, self._decimals)
        else:
            val = int(val)
        self._baseline = val
        self._edit.blockSignals(True)
        self._edit.setText(self._fmt(val))
        self._edit.blockSignals(False)
        self._commit()

    def _commit(self):
        val = self._baseline
        self.editingFinished.emit()
        self.valueChanged.emit(val)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Up:
            self._start_long(1)
            self._stop_long()
        elif event.key() == Qt.Key_Down:
            self._start_long(-1)
            self._stop_long()
        else:
            super().keyPressEvent(event)

    def wheelEvent(self, event):
        event.ignore()

    # ── status ──

    def flashSuccess(self):
        self._edit.flash_success()

    def flashError(self):
        from xiaoe_ui.widgets.status_widgets import _set_status
        _set_status(self._edit, "error")

    # ── public API ──

    def value(self) -> float | int:
        return self._parse_val()

    def setValue(self, val: float):
        val = max(self._min, min(self._max, val))
        if self._is_float:
            val = round(val, self._decimals)
        else:
            val = int(val)
        self._baseline = val
        self._edit.blockSignals(True)
        self._edit.setText(self._fmt(val))
        self._edit.update_baseline(self._fmt(val))
        self._edit.blockSignals(False)

    def setRange(self, lo: float, hi: float):
        self._min = lo
        self._max = hi

    def setMaximum(self, n: float):
        self._max = n

    def setSingleStep(self, step: float):
        self._step = step

    def setDecimals(self, n: int):
        self._decimals = n
        self._is_float = n > 0 or isinstance(self._step, float)

    def setPrefix(self, p: str):
        self._prefix = p

    def setSuffix(self, s: str):
        self._suffix = s

    def height(self) -> int:
        return self.height()
