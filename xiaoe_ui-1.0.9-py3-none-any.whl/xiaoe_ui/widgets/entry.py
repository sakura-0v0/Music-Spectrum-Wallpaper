"""Layer 2 表单输入 — 给裸组件加 config 绑定，不带标题。"""

from __future__ import annotations

from typing import Callable

from PySide6.QtCore import Qt, QEvent
from PySide6.QtWidgets import (
    QHBoxLayout, QVBoxLayout, QWidget,
)

from xiaoe_ui.widgets.spin_box import CustomSpinBox
from xiaoe_ui.config.bridge import ConfigBridge
from xiaoe_ui.widgets.use_mixin_fast_widget import (
    CustomSlider, QCheckBoxHandCursor, CustomComboBox,
)


# ═══════════════════════════════════════════════════════════════
# SpinEntry — CustomSpinBox + config
# ═══════════════════════════════════════════════════════════════

class SpinEntry(QWidget):
    """数字输入: CustomSpinBox + config 绑定。

    decimals 自动从 step 推导: step 为 int → 0, step 为 float → 小数位数。

    Args:
        config / config_name: 配置双绑
        step: 步长，同时决定 int/float 模式和小数位数
        config_range / prefix / suffix / live / validate: 透传 CustomSpinBox
        default: 无 config 时的默认值
        callback: 提交回调
        width: 输入框宽度
    """

    def __init__(self,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 step: float = 1,
                 config_range: tuple = None,
                 prefix: str = "",
                 suffix: str = "",
                 default = 0,
                 live: bool = False,
                 validate: Callable = None,
                 callback: Callable = None,
                 width: int = 80,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._config = config
        self._key = config_name
        self._cb_callback = callback
        self._validate = validate
        self._use_config = bool(config and config_name)
        self._last_valid = default

        decimals = len(str(step).split(".")[-1]) if isinstance(step, float) else 0

        if config_range is None:
            config_range = (-99999, 99999)
        lo, hi = config_range

        self._field = CustomSpinBox(
            min_val=lo, max_val=hi, value=default, step=step,
            decimals=decimals, prefix=prefix, suffix=suffix, live=live,
        )
        self._field.setFixedWidth(width)

        self._field.valueChanged.connect(self._on_commit)
        if self._use_config:
            cur = config.get(config_name)
            if cur is not None:
                self._last_valid = cur
                self._field.setValue(cur)
            config.value_changed.connect(self._on_config_read)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._field)

    def value(self):
        return self._field.value()

    def setValue(self, v):
        self._last_valid = v
        self._field.setValue(v)

    def _on_commit(self, val):
        if self._validate and not self._validate(val):
            self._field.setValue(self._last_valid)
            self._field.flashError()
            return
        self._last_valid = val
        if self._use_config:
            self._config.set(self._key, val)
        if self._cb_callback:
            self._cb_callback(val)

    def _on_config_read(self, key: str, new_val):
        if key == self._key:
            self._last_valid = new_val
            self._field.blockSignals(True)
            self._field.setValue(new_val)
            self._field.blockSignals(False)
            self._field.flashSuccess()


# ═══════════════════════════════════════════════════════════════
# TextEntry — StatusLineEdit + config
# ═══════════════════════════════════════════════════════════════

class TextEntry(QWidget):
    """文本输入: StatusLineEdit + config 绑定。

    Args:
        config / config_name: 配置双绑
        placeholder: 占位文字
        value_type: str/int/float 或自定义校验函数；抛异常=校验失败，也可在内修正数值
        default: 无 config 时的默认值
        callback: 提交回调
        width: 输入框宽度
    """

    def __init__(self,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 placeholder: str = "",
                 value_type: Callable[[str], object] = str,
                 default: str = "",
                 callback: Callable[[str], None] = None,
                 width: int = 150,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._config = config
        self._key = config_name
        self._cb_callback = callback
        self._use_config = bool(config and config_name)

        from xiaoe_ui.widgets.status_widgets import StatusLineEdit

        cur = str(config.get(config_name)) if self._use_config else str(default)
        self._field = StatusLineEdit(text=cur, value_type=value_type)
        self._field.setFixedWidth(width)
        if placeholder:
            self._field.setPlaceholderText(placeholder)

        self._field.editingFinished.connect(self._on_commit)
        if self._use_config:
            config.value_changed.connect(self._on_config_read)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._field)

    def _on_commit(self):
        text = self._field.text()
        if self._use_config:
            self._config.set(self._key, text)
        if self._cb_callback:
            self._cb_callback(text)

    def _on_config_read(self, key: str, new_val):
        if key == self._key:
            s = str(new_val) if new_val is not None else ""
            self._field.blockSignals(True)
            self._field.update_baseline(s)
            self._field.setText(s)
            self._field.blockSignals(False)
            self._field.flash_success()


# ═══════════════════════════════════════════════════════════════
# MultiEntry — StatusTextEdit + config
# ═══════════════════════════════════════════════════════════════

class MultiEntry(QWidget):
    """多行文本: StatusTextEdit + config 绑定，失焦/Enter 提交。"""

    def __init__(self,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 height: int = 80,
                 default: str = "",
                 callback: Callable[[str], None] = None,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._config = config
        self._key = config_name
        self._cb_callback = callback
        self._use_config = bool(config and config_name)

        from xiaoe_ui.widgets.status_widgets import StatusTextEdit, _set_status

        self._set_status = _set_status
        self._edit = StatusTextEdit(
            text=config.get(config_name) if self._use_config else default,
            height=height,
        )

        if self._use_config:
            self._edit.installEventFilter(self)
            config.value_changed.connect(self._on_config_read)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._edit)

    def eventFilter(self, obj, event):
        if obj is self._edit:
            if event.type() == QEvent.FocusOut:
                self._commit()
            elif event.type() == QEvent.KeyPress and event.key() in (
                Qt.Key_Return, Qt.Key_Enter
            ) and not (event.modifiers() & (Qt.ShiftModifier | Qt.ControlModifier)):
                self._commit()
        return super().eventFilter(obj, event)

    def _commit(self):
        val = self._edit.toPlainText()
        if self._use_config:
            self._config.set(self._key, val)
        if self._cb_callback:
            self._cb_callback(val)

    def _on_config_read(self, key: str, new_val):
        if key == self._key:
            s = str(new_val) if new_val else ""
            self._edit.blockSignals(True)
            self._edit.setText(s)
            self._edit.update_baseline(s)
            self._edit.blockSignals(False)
            self._set_status(self._edit, "success")


# ═══════════════════════════════════════════════════════════════
# ImagePicker — StatusImagePicker + config
# ═══════════════════════════════════════════════════════════════

class ImagePicker(QWidget):
    """图片选择: StatusImagePicker + config 绑定。"""

    def __init__(self,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 size: int = 80,
                 default: str = None,
                 callback: Callable[[str], None] = None,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._config = config
        self._key = config_name
        self._cb_callback = callback
        self._use_config = bool(config and config_name)
        self._size = size

        from xiaoe_ui.widgets.status_widgets import StatusImagePicker

        cur = config.get(config_name) if self._use_config else default
        self._picker = StatusImagePicker(
            width=size, height=size, path=cur or "",
            on_changed=self._on_commit,
        )

        if self._use_config:
            config.value_changed.connect(self._on_config_read)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._picker)

    def _on_commit(self, path: str):
        if self._use_config:
            self._config.set(self._key, path)
        if self._cb_callback:
            self._cb_callback(path)

    def _on_config_read(self, key: str, new_val):
        if key == self._key:
            self._picker._refresh(str(new_val) if new_val else "")


# ═══════════════════════════════════════════════════════════════
# DatePicker — StatusDateEdit + config
# ═══════════════════════════════════════════════════════════════

class DatePicker(QWidget):
    """日期选择: StatusDateEdit + config 绑定。"""

    def __init__(self,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 fmt: str = "yyyy-MM-dd",
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._config = config
        self._key = config_name
        self._fmt = fmt
        self._use_config = bool(config and config_name)

        from xiaoe_ui.widgets.status_widgets import StatusDateEdit

        cur = config.get(config_name) if config and config_name else ""
        self._field = StatusDateEdit(text=str(cur), fmt=fmt)
        self._field._edit.editingFinished.connect(self._on_commit)

        if self._use_config:
            config.value_changed.connect(self._on_config_read)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._field)

    def _on_commit(self):
        text = self._field._edit.text()
        if self._use_config:
            self._config.set(self._key, text)

    def _on_config_read(self, key: str, new_val):
        if key == self._key and new_val is not None:
            self._field._edit.setText(str(new_val))


# ═══════════════════════════════════════════════════════════════
# ColorEntry — ColorPickerButton + config
# ═══════════════════════════════════════════════════════════════

class ColorEntry(QWidget):
    """颜色选择: ColorPickerButton + config 绑定。"""

    def __init__(self,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 rgba: bool = False,
                 text: str = "设置",
                 dialog_title: str = "选择颜色",
                 default: tuple = (255, 0, 0),
                 callback: Callable = None,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._config = config
        self._key = config_name
        self._cb_callback = callback
        self._use_config = bool(config and config_name)
        self._rgba = rgba

        from xiaoe_ui.widgets.status_widgets import ColorPickerButton

        cur = config.get(config_name) if self._use_config else default
        self._btn = ColorPickerButton(
            color=cur, rgba=rgba, tooltip_text=text,
            dialog_title=dialog_title,
        )
        self._btn.colorChanged.connect(self._on_commit)

        if self._use_config:
            config.value_changed.connect(self._on_config_read)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._btn)

    def color(self) -> tuple:
        return self._btn.color()

    def setColor(self, c: tuple):
        self._btn.setColor(c)

    def _on_commit(self, val: tuple):
        if self._use_config:
            self._config.set(self._key, val)
        if self._cb_callback:
            self._cb_callback(val)

    def _on_config_read(self, key: str, new_val):
        if key == self._key and new_val is not None:
            self._btn.setColor(new_val)


# ═══════════════════════════════════════════════════════════════
# SliderEntry — CustomSlider + config
# ═══════════════════════════════════════════════════════════════

class SliderEntry(QWidget):
    """滑块: CustomSlider + config 绑定。

    Args:
        live: True=拖动时实时提交，False=松手时提交
    """

    def __init__(self,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 config_range: tuple = (0, 100),
                 step: float = 1,
                 num_type_text: str = "",
                 live: bool = True,
                 callback: Callable = None,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._config = config
        self._key = config_name
        self._cb_callback = callback
        self._use_config = bool(config and config_name)
        self._min, self._max = config_range
        self._step = step
        self._is_float = isinstance(step, float)
        self._live = live

        steps = int(round((self._max - self._min) / step))
        self._slider = CustomSlider(
            Qt.Horizontal,
            range_text=f"{self._min}~{self._max}",
            num_type_text=num_type_text,
        )
        self._slider.setRange(0, steps)

        if self._use_config:
            cur = config.get(config_name)
            if isinstance(cur, (int, float)):
                pos = int(round((cur - self._min) / step))
                self._slider.setValue(pos)

        if live:
            self._slider.valueChanged.connect(self._on_change)
        else:
            self._slider.valueChanged.connect(self._on_slide)
            self._slider.sliderReleased.connect(self._on_release)

        # 初始化 value_text（信号在 setValue 之后连接，手动补上）
        self._slider.value_text = self._fmt(self._slider.value() * self._step + self._min)

        if self._use_config:
            config.value_changed.connect(self._on_config_read)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._slider, 1)

    def _fmt(self, val):
        if self._is_float:
            return f"{val:.2f}"
        return str(int(val))

    def _commit(self, val):
        if self._use_config:
            self._config.set(self._key, val)
        if self._cb_callback:
            self._cb_callback(val)

    def _on_change(self, pos: int):
        val = round(self._min + pos * self._step, 6)
        if not self._is_float:
            val = int(val)
        self._slider.value_text = self._fmt(val)
        self._commit(val)

    def _on_slide(self, pos: int):
        val = round(self._min + pos * self._step, 6)
        if not self._is_float:
            val = int(val)
        self._slider.value_text = self._fmt(val)

    def _on_release(self):
        pos = self._slider.value()
        val = round(self._min + pos * self._step, 6)
        if not self._is_float:
            val = int(val)
        self._commit(val)

    def _on_config_read(self, key: str, new_val):
        if key == self._key and isinstance(new_val, (int, float)):
            pos = int(round((new_val - self._min) / self._step))
            self._slider.blockSignals(True)
            self._slider.setValue(pos)
            self._slider.blockSignals(False)


# ═══════════════════════════════════════════════════════════════
# CheckEntry — QCheckBox + config
# ═══════════════════════════════════════════════════════════════

class CheckEntry(QWidget):
    """复选框: QCheckBox + config 绑定。"""

    def __init__(self,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 default: bool = False,
                 callback: Callable[[bool], None] = None,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._key = config_name
        self._use_config = bool(config and config_name)

        self._cb = QCheckBoxHandCursor()

        if self._use_config:
            cur = config.get(config_name)
            self._cb.setChecked(cur if isinstance(cur, bool) else default)
            self._cb.stateChanged.connect(
                lambda s: (config.set(config_name, s == 2),
                           callback(s == 2) if callback else None))
            config.value_changed.connect(self._on_config_read)
        else:
            self._cb.setChecked(default)
            self._cb.stateChanged.connect(
                lambda s: callback(s == 2) if callback else None)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._cb)

    def _on_config_read(self, key: str, new_val):
        if key == self._key:
            self._cb.blockSignals(True)
            self._cb.setChecked(new_val)
            self._cb.blockSignals(False)


# ═══════════════════════════════════════════════════════════════
# ComboEntry — CustomComboBox + config
# ═══════════════════════════════════════════════════════════════

class ComboEntry(QWidget):
    """下拉框: CustomComboBox + config 绑定。

    Args:
        store_index: True=配置中存索引(int), False=存原始值
    """

    def __init__(self,
                 config: ConfigBridge = None,
                 config_name: str = None,
                 options: list = None,
                 default_index: int = 0,
                 width: int = 120,
                 store_index: bool = False,
                 callback: Callable = None,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._key = config_name
        self._use_config = bool(config and config_name)
        self._store_index = store_index
        self._callback = callback
        self._default_index = default_index
        if options is None:
            options = []
        self._options = options

        self._combo = CustomComboBox()
        self._combo.addItems([str(o) for o in options])
        self._combo.setFixedWidth(width)

        if self._use_config:
            self._config = config
            cur = config.get(config_name)
            if store_index:
                idx = cur if isinstance(cur, int) else default_index
            else:
                try:
                    idx = options.index(cur)
                except ValueError:
                    idx = default_index
            self._combo.setCurrentIndex(idx)
            self._combo.currentIndexChanged.connect(self._on_combo_changed)
            config.value_changed.connect(self._on_config_read)
        else:
            self._combo.setCurrentIndex(default_index)
            self._combo.currentIndexChanged.connect(self._on_combo_changed)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._combo)

    def _get_value(self, i: int):
        return i if self._store_index else self._options[i]

    def _on_combo_changed(self, i: int):
        val = self._get_value(i)
        if self._use_config:
            self._config.set(self._key, val)
        if self._callback:
            self._callback(val)

    def _on_config_read(self, key: str, new_val):
        if key == self._key:
            self._combo.blockSignals(True)
            if self._store_index:
                idx = new_val if isinstance(new_val, int) else self._default_index
            else:
                try:
                    idx = self._options.index(new_val)
                except ValueError:
                    idx = self._default_index
            self._combo.setCurrentIndex(idx)
            self._combo.blockSignals(False)
