from __future__ import annotations
"""可折叠配置块 ABox（等价于 small_map 的 create_a_box）。"""

from typing import Callable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy,
)

from xiaoe_ui.widgets.click_frame import ClickFrame
from xiaoe_ui.widgets.use_mixin_fast_widget import QPushButtonHandCursor


class ABox:
    """可折叠的配置块，带标题栏和展开/收起按钮。

    用法:
        box = ABox("基本设置", parent_layout)
        box.content_layout.addWidget(CheckItem("enable", "启用功能"))
        box.content_layout.addWidget(ComboItem("mode", "模式", ["A", "B"]))
    """

    def __init__(self,
                 title: str,
                 parent_layout: QVBoxLayout | QHBoxLayout = None,
                 expanded: bool = True,
                 no_hide_btn: bool = False,
                 ico_text: str = None,
                 ):
        """
        Args:
            title: 标题文字
            parent_layout: 父布局（可选，直接 addWidget 也行）
            expanded: 是否默认展开
            no_hide_btn: 隐藏折叠按钮
            ico_text: 标题前的图标文字
        """
        self._expanded = expanded

        # 外层框架
        self.frame = QFrame()
        self.frame.setProperty("class", "block light-line default-hover-line")
        self.frame.setFrameStyle(QFrame.Box)
        self.frame.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        main_layout = QVBoxLayout(self.frame)
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(10, 10, 10, 10)

        # 标题栏
        title_frame = ClickFrame(default_line=False, custom_class="light-line")
        title_frame.on_left_click(self._toggle)

        title_layout = QHBoxLayout()
        title_layout.setSpacing(0)
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_frame.setLayout(title_layout)

        # 图标
        ico_label = QLabel()
        ico_label.setProperty("class", "section_title")
        ico_label.setContentsMargins(0, 0, 6, 0)
        if ico_text:
            ico_label.setText(ico_text)

        # 标题
        title_label = QLabel(title)
        title_label.setProperty("class", "section_title")
        title_label.setAlignment(Qt.AlignCenter)

        # 展开/收起按钮
        show_btn = QPushButtonHandCursor()
        show_btn.setProperty("class", "title-hide-btn")
        show_btn.setFixedWidth(40)
        show_btn.clicked.connect(self._toggle)

        # 占位按钮（保持布局对称）
        hide_placeholder = QPushButton()
        hide_placeholder.setStyleSheet("color: rgba(0,0,0,0);"
                                       "background-color: rgba(0,0,0,0);"
                                       "border: none;")
        hide_placeholder.setFixedWidth(40)

        if not no_hide_btn:
            title_layout.addWidget(hide_placeholder)
        title_layout.addStretch(1)
        if ico_text:
            title_layout.addWidget(ico_label)
        title_layout.addWidget(title_label)
        title_layout.addStretch(1)
        if not no_hide_btn:
            title_layout.addWidget(show_btn)

        main_layout.addWidget(title_frame)

        # 分隔线
        sep = QFrame()
        sep.setFrameStyle(QFrame.HLine)
        sep.setProperty("class", "bold-line")
        main_layout.addWidget(sep)

        # 内容区
        self._content_frame = QFrame()
        self._content_frame.setContentsMargins(0, 0, 0, 0)
        self.content_layout = QVBoxLayout(self._content_frame)
        self.content_layout.setSpacing(10)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(self._content_frame)

        if not expanded:
            self._content_frame.hide()
            show_btn.setText("↓")
        else:
            show_btn.setText("↑")

        self._show_btn = show_btn

        # 添加到父布局
        if parent_layout is not None:
            parent_layout.addWidget(self.frame)

    def _toggle(self):
        self._expanded = not self._expanded
        self._content_frame.setVisible(self._expanded)
        self._show_btn.setText("↑" if self._expanded else "↓")

    def set_expanded(self, expanded: bool):
        self._expanded = expanded
        self._content_frame.setVisible(expanded)
        self._show_btn.setText("↑" if expanded else "↓")


class HideItem:
    """可折叠的单行配置项（等价于 small_map 的 create_hide_box_item）。

    用法:
        def build_hide_content(layout):
            layout.addWidget(QLabel("展开的内容"))

        hide = HideItem("高级选项", "点击展开", build_hide_content, parent_layout)
        # 刷新内容
        hide.refresh()
    """

    def __init__(self,
                 title: str,
                 desc: str = "",
                 show_func: Callable[[QVBoxLayout], None] = None,
                 parent_layout: QVBoxLayout | QHBoxLayout = None,
                 default_open: bool = False,
                 ):
        self._show_func = show_func
        self._parent_layout = parent_layout

        outer = QVBoxLayout()

        # 标题行
        title_frame = ClickFrame(default_line=False, custom_class="light-line")
        title_frame.on_left_click(self._toggle)
        title_layout = QHBoxLayout()
        title_frame.setLayout(title_layout)

        label = QLabel(f"{title:　<6}")
        label.setProperty("class", "line_title")

        desc_label = QLabel(desc)
        desc_label.setProperty("class", "tip-text")

        self._show_btn = QPushButtonHandCursor("↓")
        self._show_btn.setProperty("class", "small")
        self._show_btn.clicked.connect(self._toggle)

        title_layout.addWidget(label)
        title_layout.addStretch(1)
        title_layout.addWidget(desc_label)
        title_layout.addWidget(self._show_btn)

        outer.addWidget(title_frame)

        # 内容区
        self._content_frame = ClickFrame(hand_cursor=False,
                                         custom_class="light-line default-hover-line disable")
        self._content_layout = QVBoxLayout()
        self._content_layout.setSpacing(2)
        self._content_frame.setLayout(self._content_layout)
        self._content_frame.hide()

        if show_func:
            show_func(self._content_layout)

        outer.addWidget(self._content_frame)

        if default_open:
            self._content_frame.show()
            self._show_btn.setText("↑")

        if parent_layout is not None:
            parent_layout.addLayout(outer)

        self._outer = outer

    def _toggle(self):
        if self._content_frame.isVisible():
            self._content_frame.hide()
            self._show_btn.setText("↓")
        else:
            self._content_frame.show()
            self._show_btn.setText("↑")

    def refresh(self):
        """重新生成内容区（调用 show_func）。"""
        # 清空
        while self._content_layout.count():
            item = self._content_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        # 重新填充
        if self._show_func:
            self._show_func(self._content_layout)
