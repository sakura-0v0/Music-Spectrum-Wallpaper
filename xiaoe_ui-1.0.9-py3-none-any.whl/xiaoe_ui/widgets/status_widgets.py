"""带状态显示的元素 — 继承自 Qt 基础控件，内嵌 edited/success/error 状态边框。

StatusLineEdit(QLineEdit) / StatusTextEdit(QTextEdit) 等纯净控件，
不含表单行布局（标题+stretch+控件），布局请用 form_layout.make_form_row()。
"""

from __future__ import annotations

import os
from typing import Callable

from PySide6.QtCore import Qt, QTimer, QDate, QDateTime, QLocale, QTime, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QCalendarWidget,
    QColorDialog,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
    QSizePolicy,
)

from xiaoe_ui import InstantTooltipMixin
from xiaoe_ui.core.dialog import Dialog
from xiaoe_ui.widgets.use_mixin_fast_widget import QPushButtonHandCursor
from xiaoe_ui.widgets.basic import flash_style, HandCursorMixin
from xiaoe_ui.widgets.click_frame import ClickFrame


# ═══════════════════════════════════════════════════════════════
# DateTimePickerDialog — 同 dcjl_plus DateTimePickerDialog
# ═══════════════════════════════════════════════════════════════

class DateTimePickerDialog(Dialog):
    """日期时间选择弹窗

    继承 Dialog (WinManager)，日历可折叠，SpinBox + 实时预览。
    """

    def __init__(self,
                 current: QDateTime,
                 fmt: str = "yyyy-MM-dd HH:mm:ss",
                 parent=None,
                 ):
        super().__init__(parent=parent, win_title="选择日期时间",
                         width=420, height=370, set_fixed_size=False)
        self._fmt = fmt
        self._result: QDateTime | None = None
        self._syncing = False

        d, t = current.date(), current.time()
        layout = self.root_layout
        layout.setSpacing(6)

        # ── 日期 SpinBox 行 ──
        date_row = QHBoxLayout()
        date_row.setSpacing(4)
        self._sp_y = self._sp(2000, 2100, d.year())
        date_row.addWidget(self._sp_y)
        date_row.addWidget(QLabel("年"))
        self._sp_m = self._sp(1, 12, d.month())
        date_row.addWidget(self._sp_m)
        date_row.addWidget(QLabel("月"))
        self._sp_d = self._sp(1, 31, d.day())
        date_row.addWidget(self._sp_d)
        date_row.addWidget(QLabel("日"))
        layout.addLayout(date_row)

        # ── 日历折叠按钮 ──
        self._cal_toggle = QPushButton("显示日历 ▼")
        self._cal_toggle.setFixedWidth(100)
        self._cal_toggle.setProperty("class", "small")
        self._cal_toggle.clicked.connect(self._toggle_cal)
        layout.addWidget(self._cal_toggle, alignment=Qt.AlignmentFlag.AlignRight)

        # ── 日历区域（初始隐藏）──
        self._cal_wrap = QWidget()
        self._cal_wrap.hide()
        cal_layout = QVBoxLayout(self._cal_wrap)
        cal_layout.setSpacing(4)
        cal_layout.setContentsMargins(0, 0, 0, 0)

        nav = QHBoxLayout()
        nav.setSpacing(0)
        btn_prev = QPushButton("<")
        btn_prev.setFixedSize(30, 28)
        btn_prev.clicked.connect(lambda: self._cal.showPreviousMonth())
        self._nav_label = QLabel()
        self._nav_label.setAlignment(Qt.AlignCenter)
        self._nav_label.setProperty("class", "line_title")
        btn_next = QPushButton(">")
        btn_next.setFixedSize(30, 28)
        btn_next.clicked.connect(lambda: self._cal.showNextMonth())
        nav.addWidget(btn_prev)
        nav.addWidget(self._nav_label, 1)
        nav.addWidget(btn_next)
        cal_layout.addLayout(nav)

        self._cal = QCalendarWidget()
        self._cal.setLocale(QLocale(QLocale.Chinese))
        self._cal.setSelectedDate(d)
        self._cal.setGridVisible(True)
        self._cal.setVerticalHeaderFormat(QCalendarWidget.NoVerticalHeader)
        self._cal.setNavigationBarVisible(False)
        self._cal.setAutoFillBackground(True)
        self._cal.setAttribute(Qt.WA_StyledBackground, True)
        cal_layout.addWidget(self._cal)
        layout.addWidget(self._cal_wrap)

        # ── 时间 SpinBox 行 ──
        time_row = QHBoxLayout()
        time_row.setSpacing(4)
        self._sp_h = self._sp(0, 23, t.hour())
        time_row.addWidget(self._sp_h)
        time_row.addWidget(QLabel("时"))
        self._sp_min = self._sp(0, 59, t.minute())
        time_row.addWidget(self._sp_min)
        time_row.addWidget(QLabel("分"))
        self._sp_s = self._sp(0, 59, t.second())
        time_row.addWidget(self._sp_s)
        time_row.addWidget(QLabel("秒"))
        layout.addLayout(time_row)

        # ── 预览 ──
        self._preview = QLabel()
        self._preview.setAlignment(Qt.AlignCenter)
        self._preview.setProperty("class", "section_title")
        layout.addWidget(self._preview)

        # ── 按钮 ──
        btns = QHBoxLayout()
        btns.addStretch(1)
        btn_ok = QPushButton("确定")
        btn_ok.clicked.connect(self._on_ok)
        btns.addWidget(btn_ok)
        btn_cancel = QPushButton("取消")
        btn_cancel.clicked.connect(self.reject)
        btns.addWidget(btn_cancel)
        layout.addLayout(btns)

        self._cal.selectionChanged.connect(self._on_cal_changed)
        self._cal.currentPageChanged.connect(self._update_nav)
        self._update_nav()
        self._update_preview()

    def _sp(self, lo: int, hi: int, v: int):
        from xiaoe_ui.widgets.spin_box import CustomSpinBox
        sp = CustomSpinBox(min_val=lo, max_val=hi, value=v, step=1, live=True)
        sp.setFixedWidth(80)
        sp.valueChanged.connect(lambda _: self._on_spin())
        return sp

    def _toggle_cal(self):
        visible = not self._cal_wrap.isVisible()
        self._cal_wrap.setVisible(visible)
        self._cal_toggle.setText("隐藏日历 ▲" if visible else "显示日历 ▼")
        self.adjustSize()

    def _on_spin(self):
        if self._syncing:
            return
        self._syncing = True
        try:
            y, m = self._sp_y.value(), self._sp_m.value()
            d = min(self._sp_d.value(), QDate(y, m, 1).daysInMonth())
            self._sp_d.setMaximum(QDate(y, m, 1).daysInMonth())
            self._sp_d.setValue(d)
            self._cal.setSelectedDate(QDate(y, m, d))
            self._update_preview()
        finally:
            self._syncing = False

    def _on_cal_changed(self):
        if self._syncing:
            return
        self._syncing = True
        try:
            d = self._cal.selectedDate()
            self._sp_y.setValue(d.year())
            self._sp_m.setValue(d.month())
            self._sp_d.setMaximum(d.daysInMonth())
            self._sp_d.setValue(d.day())
            self._update_preview()
        finally:
            self._syncing = False

    def _update_nav(self):
        y, m = self._cal.yearShown(), self._cal.monthShown()
        self._nav_label.setText(f"{y}年 {m}月")

    def _current_dt(self) -> QDateTime:
        return QDateTime(
            QDate(self._sp_y.value(), self._sp_m.value(), self._sp_d.value()),
            QTime(self._sp_h.value(), self._sp_min.value(), self._sp_s.value()))

    def _update_preview(self):
        self._update_nav()
        ts = self._fmt.split(" ")[1] if " " in self._fmt else "HH:mm:ss"
        for attr, sp in [("HH", self._sp_h), ("mm", self._sp_min), ("ss", self._sp_s)]:
            sp.setVisible(attr in ts)
        dt = self._current_dt()
        self._preview.setText(f"预览：{dt.toString(self._fmt)}")

    def _on_ok(self):
        self._result = self._current_dt()
        self.accept()

    def result(self) -> QDateTime | None:
        return self._result


# ═══════════════════════════════════════════════════════════════
# 状态工具
# ═══════════════════════════════════════════════════════════════

def _start_success(widget: QLineEdit | QTextEdit):
    """success 绿框 5 秒后回 normal。"""
    if hasattr(widget, '_st_timer') and widget._st_timer:
        widget._st_timer.stop()
    widget._st_timer = QTimer(widget)
    widget._st_timer.setSingleShot(True)
    widget._st_timer.timeout.connect(
        lambda: (
            widget.setProperty("status", "normal"),
            flash_style(widget),
        ) if widget.property("status") == "success" else None
    )
    widget._st_timer.start(5000)


def _set_status(widget: QLineEdit | QTextEdit,
                status: str,
                ):
    widget.setProperty("status", status)
    flash_style(widget)
    if status == "success":
        _start_success(widget)


# ═══════════════════════════════════════════════════════════════
# StatusLineEdit — 继承 QLineEdit，内嵌状态边框逻辑
# ═══════════════════════════════════════════════════════════════

class StatusLineEdit(QLineEdit):
    """带状态边框的文本输入框，继承 QLineEdit。

    编辑中对比基线值 → 不同则 edited 黄框。
    回车/失焦 → 校验 → success 绿框(5s) / error 红框。

    Args:
        text: 初始文本
        placeholder: 占位文字
        value_type: 值校验函数，如 int/float/str，失败抛 ValueError
        parent: 父控件
    """

    def __init__(self,
                 text: str = "",
                 placeholder: str = "",
                 value_type: Callable[[str], object] = str,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._value_type = value_type
        self._baseline = text

        self.setText(text)
        self.setProperty("status", "normal")
        if placeholder:
            self.setPlaceholderText(placeholder)

        self.textChanged.connect(self._on_text_changed)
        self.editingFinished.connect(self._on_editing_finished)

    @property
    def value(self) -> str:
        return self.text()

    def update_baseline(self, text: str):
        """更新比较基线（外部同步值时调用）。"""
        self._baseline = text

    def flash_success(self):
        """显示 success 绿框，5 秒后自动恢复。"""
        _set_status(self, "success")

    def _on_text_changed(self, text: str):
        _set_status(self, "edited" if text != self._baseline else "normal")

    def _on_editing_finished(self):
        text = self.text()
        try:
            result = self._value_type(text)
            formatted = str(result)
            if formatted != text:
                self.setText(formatted)
            _set_status(self, "success")
            self._baseline = formatted
        except (ValueError, TypeError):
            _set_status(self, "error")


# ═══════════════════════════════════════════════════════════════
# StatusDateEdit — 日期选择（输入框 + 📅 按钮），继承 QWidget
# ═══════════════════════════════════════════════════════════════

class StatusDateEdit(QWidget):
    """带状态边框的日期选择控件: 输入框 + 📅 按钮。"""

    def __init__(self,
                 text: str = "",
                 fmt: str = "yyyy-MM-dd",
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._fmt = fmt
        self._baseline = text

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self._edit = QLineEdit()
        self._edit.setText(text)
        self._edit.setFixedWidth(140)
        self._edit.setProperty("status", "normal")
        self._edit.textChanged.connect(
            lambda t: _set_status(self._edit,
                                  "edited" if t != self._baseline else "normal"))
        self._edit.editingFinished.connect(self._on_commit)

        btn = QPushButtonHandCursor("📅")
        btn.setFixedWidth(40)
        btn.setProperty("class", "small")
        btn.clicked.connect(self._pick)

        layout.addWidget(self._edit)
        layout.addWidget(btn)

    @property
    def value(self) -> str:
        return self._edit.text()

    @property
    def edit(self) -> QLineEdit:
        return self._edit

    def update_baseline(self, text: str):
        self._baseline = text

    def flash_success(self):
        """显示 success 绿框，5 秒后自动恢复。"""
        _set_status(self._edit, "success")

    def _pick(self):
        text = self._edit.text()
        dt = QDateTime.fromString(text, self._fmt) if text else QDateTime.currentDateTime()
        if not dt.isValid():
            dt = QDateTime.currentDateTime()
        dlg = DateTimePickerDialog(dt, self._fmt, parent=self)
        if dlg.exec() == QDialog.Accepted and dlg.result() is not None:
            formatted = dlg.result().toString(self._fmt)
            self._edit.setText(formatted)
            self._baseline = formatted
            _set_status(self._edit, "success")
            self._edit.editingFinished.emit()

    def _on_commit(self):
        """同 dcjl_plus _parse/_validate：多格式校验。"""
        text = self._edit.text()
        if not text.strip():
            _set_status(self._edit, "success")
            self._baseline = ""
            return
        dt = self._parse(text.strip())
        if dt.isValid():
            self._edit.setText(dt.toString(self._fmt))
            self._baseline = dt.toString(self._fmt)
            _set_status(self._edit, "success")
        else:
            _set_status(self._edit, "error")

    def _parse(self, text: str) -> QDateTime:
        dt = QDateTime.fromString(text, self._fmt)
        if dt.isValid():
            return dt
        dt = QDateTime.fromString(text, Qt.ISODate)
        if dt.isValid():
            return dt
        d = QDate.fromString(text, Qt.ISODate)
        if d.isValid():
            return QDateTime(d, QTime(0, 0))
        for df in ("yyyy-M-d", "yyyy-M-d HH:mm:ss",
                   "yyyy/M/d", "yyyy/M/d HH:mm:ss"):
            dt = QDateTime.fromString(text, df)
            if dt.isValid():
                return dt
        return QDateTime()


# ═══════════════════════════════════════════════════════════════
# StatusTextEdit — 继承 QTextEdit，内嵌状态边框 + 失焦提交
# ═══════════════════════════════════════════════════════════════

class StatusTextEdit(QTextEdit):
    """带状态边框的多行文本编辑框，继承 QTextEdit。

    编辑中：与基线不同 → edited 黄框
    失焦：保存为基线 → success 绿框 5 秒
    """

    def __init__(self,
                 text: str = "",
                 height: int = 80,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._baseline = text

        self.setText(text)
        self.setFixedHeight(height)
        self.textChanged.connect(self._on_text_changed)

    @property
    def value(self) -> str:
        return self.toPlainText()

    def update_baseline(self, text: str):
        self._baseline = text

    def focusOutEvent(self, e):
        super().focusOutEvent(e)
        self._baseline = self.toPlainText()
        _set_status(self, "success")

    def _on_text_changed(self):
        _set_status(self,
                    "edited" if self.toPlainText() != self._baseline else "normal")


# ═══════════════════════════════════════════════════════════════
# StatusImagePicker — 图片选择器，ClickLabel + hover × 按钮
# ═══════════════════════════════════════════════════════════════

class StatusImagePicker(QWidget):
    """图片选择控件：预览区 + hover 右上角 × 按钮，完全照搬 dcjl_plus image_picker。"""

    def __init__(self,
                 width: int = 220,
                 height: int = 220,
                 path: str = "",
                 on_changed: Callable[[str], None] = None,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._w, self._h = width, height
        self._path = path
        self._on_changed = on_changed

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self._img_frame = ClickFrame(hand_cursor=True, default_line=True)
        self._img_frame.setFixedSize(width, height)
        self._img_frame.on_left_click(self._pick)

        self._img_label = QLabel("未设置")
        self._img_label.setAlignment(Qt.AlignCenter)
        padding = 2
        fl = QHBoxLayout(self._img_frame)
        fl.setContentsMargins(padding, padding, padding, padding)
        fl.addWidget(self._img_label)

        self._close_btn = QPushButton("×", self._img_frame)
        self._close_btn.setFixedSize(20, 20)
        self._close_btn.setCursor(Qt.PointingHandCursor)
        self._close_btn.setProperty("class", "image-picker-close")
        self._close_btn.clicked.connect(self._clear)
        self._close_btn.hide()

        def _repos():
            self._close_btn.move(max(self._w - 22, 0), 2)

        self._img_frame.on_resize(_repos)
        self._img_frame.on_enter(lambda: (_repos(), self._close_btn.show() if self._path else None))
        self._img_frame.on_leave(lambda: self._close_btn.hide())

        layout.addWidget(self._img_frame)

        if path:
            self._refresh(path)

    @property
    def value(self) -> str:
        return self._path

    def refresh(self, path: str):
        """同 dcjl_plus refresh()。"""
        self._refresh(path)

    def _refresh(self, path: str):
        self._path = path
        if not path:
            self._img_label.setText("未设置图片")
            return
        if not os.path.exists(path):
            self._img_label.setText("找不到图片")
            return
        from PySide6.QtGui import QPixmap
        pix = QPixmap(path)
        if pix.isNull():
            self._img_label.setText("找不到图片")
            return
        self._img_label.setPixmap(pix.scaled(
            self._w, self._h, Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def _pick(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "选择图片", "", "Images (*.png *.jpg *.jpeg *.bmp *.gif)")
        if path:
            self._refresh(path)
            if self._on_changed:
                self._on_changed(path)

    def _clear(self):
        self._refresh("")
        if self._on_changed:
            self._on_changed("")


# ═══════════════════════════════════════════════════════════════
# ColorPickerButton — 可复用的颜色选择按钮 (斑马条纹背景 + 颜色对话框)
# ═══════════════════════════════════════════════════════════════
class PickerButton(HandCursorMixin, InstantTooltipMixin, QPushButton):
    pass
class ColorPickerButton(QWidget):
    """颜色选择按钮：条纹背景容器 + QPushButton + 颜色选择对话框。

    将颜色选择逻辑封装为表单控件，可独立使用或嵌入配置项。

    Args:
        color: 初始颜色 (r,g,b) 或 (r,g,b,a)
        rgba: True 则支持透明度
        tooltip_text: 按钮tooltip文字，空字符串不显示
        dialog_title: 颜色对话框标题
        width / height: 按钮尺寸
        parent: 父控件
    """

    colorChanged = Signal(tuple)

    def __init__(self, parent: QWidget = None,
                 color: tuple = (128, 128, 128),
                 rgba: bool = False,
                 tooltip_text: str = "",
                 dialog_title: str = "选择颜色",
                 width: int = 60, height: int = 24):
        super().__init__(parent)
        self._rgba = rgba
        self._cur: tuple = tuple(color)
        self._dialog_title = dialog_title

        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.setProperty("class", "color-picker-bg")
        self.setAttribute(Qt.WA_StyledBackground, True)

        wrap_layout = QVBoxLayout(self)
        wrap_layout.setContentsMargins(0,0,0,0)
        wrap_layout.setAlignment(Qt.AlignCenter)

        self._btn = PickerButton()
        self._btn.setProperty("class", "color-picker-btn")
        self._btn.setFixedSize(width, height)
        self._btn.clicked.connect(self._pick)
        if tooltip_text:
            self._btn.setToolTip(tooltip_text)
        wrap_layout.addWidget(self._btn)

        self._update_style()

    # ── public ──

    def color(self) -> tuple:
        """返回当前颜色 (r,g,b) 或 (r,g,b,a)。"""
        return self._cur

    def setColor(self, c: tuple):
        """设置颜色并刷新样式，不触发信号。"""
        self._cur = tuple(c)
        self._update_style()

    # ── internal ──

    def _update_style(self):
        c = self._cur
        if self._rgba and len(c) >= 4:
            bg = f"rgba({c[0]},{c[1]},{c[2]},{c[3]})"
        else:
            bg = f"rgb({c[0]},{c[1]},{c[2]})"
        self._btn.setStyleSheet(f"background-color: {bg};")

    def _pick(self):
        c = self._cur
        if len(c) < 3:
            c = (128, 128, 128)
        dlg = QColorDialog(QColor(*c[:4]), self)
        dlg.setOption(QColorDialog.DontUseNativeDialog, True)
        if self._rgba:
            dlg.setOption(QColorDialog.ShowAlphaChannel, True)
        dlg.setWindowTitle(self._dialog_title)
        if dlg.exec() == QColorDialog.Accepted:
            qc = dlg.currentColor()
            if self._rgba:
                self._cur = (qc.red(), qc.green(), qc.blue(), qc.alpha())
            else:
                self._cur = (qc.red(), qc.green(), qc.blue())
            self._update_style()
            self.colorChanged.emit(self._cur)
