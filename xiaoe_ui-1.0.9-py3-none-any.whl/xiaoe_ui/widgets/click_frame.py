from __future__ import annotations
"""可点击控件：ClickFrame、ClickLabel、即时 Tooltip。

ClickFrame 支持:
- 左右键分别注册回调
- selected / clicked / light 动态属性 + 视觉反馈
- 类方法 suspend_highlights / restore_highlights 用于 setStyleSheet 保护
"""

import weakref
from typing import Callable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton,
)

from xiaoe_ui.widgets.basic import flash_style


class ClickFrame(QFrame):
    """可点击 QFrame，支持左右键回调，带 selected/clicked/light 视觉反馈。

    Args:
        parent: 父控件
        hand_cursor: 鼠标悬停是否显示手型
        default_line: 默认显示细边框 (reaction-default-line)
        tooltip: 提示文字
        custom_class: 自定义 QSS class

    类方法:
        suspend_highlights() → 暂存并清除所有高亮
        restore_highlights(saved) → 恢复高亮
    """

    # 类级：所有当前高亮的实例 + 抑制标志
    _active_frames: 'weakref.WeakSet[ClickFrame]' = weakref.WeakSet()
    _suppress: bool = False

    def __init__(self, parent=None, hand_cursor: bool = True,
                 default_line: bool = False, tooltip: str = None,
                 custom_class: str = None):
        super().__init__(parent)
        self._pressed = False
        self._left_cb: Callable | None = None
        self._right_cb: Callable | None = None
        self._on_enter_cb: Callable | None = None
        self._on_leave_cb: Callable | None = None
        self._on_resize_cb: Callable | None = None
        self._mouse_inside: bool = False
        self._skip_restore: bool = False

        if hand_cursor:
            self.setCursor(Qt.PointingHandCursor)

        self.setFrameStyle(QFrame.Box)
        if custom_class:
            self.setProperty("class", custom_class)
        else:
            cls = "reaction reaction-default-line" if default_line else "reaction"
            self.setProperty("class", cls)

        if tooltip:
            self.setToolTip(tooltip)

    # ── 回调注册 ──

    def on_left_click(self, cb: Callable):
        """注册左键点击回调。"""
        self._left_cb = cb
        return self

    def on_right_click(self, cb: Callable):
        """注册右键点击回调。"""
        self._right_cb = cb
        return self

    def on_enter(self, cb: Callable):
        """注册鼠标进入回调。"""
        self._on_enter_cb = cb
        return self

    def on_leave(self, cb: Callable):
        """注册鼠标离开回调。"""
        self._on_leave_cb = cb
        return self

    def on_resize(self, cb: Callable):
        """注册 resize 回调。"""
        self._on_resize_cb = cb
        return self

    # ── 高亮状态管理 ──

    def _is_highlighted(self) -> bool:
        return (self.property("selected") == "true" or
                self.property("clicked") == "true" or
                self.property("light") == "true")

    def _register_highlight(self):
        """根据当前高亮状态加入/移除 _active_frames。"""
        if self._is_highlighted():
            ClickFrame._active_frames.add(self)
        else:
            ClickFrame._active_frames.discard(self)

    def set_selected(self, sel: bool):
        """设置 selected 属性并刷新样式。"""
        self.setProperty("selected", "true" if sel else "false")
        self._register_highlight()
        flash_style(self)

    def set_light(self, on: bool):
        """设置 light 属性并刷新样式。"""
        self.setProperty("light", "true" if on else "false")
        self._register_highlight()
        flash_style(self)

    # ── 类方法: setStyleSheet 保护 ──

    @classmethod
    def suspend_highlights(cls) -> list:
        """setStyleSheet 前调用: 暂存并清除所有高亮，避免 4px 边框残留。

        Returns:
            [(frame, {selected, clicked, light}), ...] 恢复数据
        """
        cls._suppress = True
        saved = []
        for frame in list(cls._active_frames):
            state = {
                'selected': frame.property("selected"),
                'clicked': frame.property("clicked"),
                'light': frame.property("light"),
            }
            saved.append((frame, state))
            frame.setProperty("selected", "false")
            frame.setProperty("clicked", "false")
            frame.setProperty("light", "false")
            flash_style(frame)
        return saved

    @classmethod
    def restore_highlights(cls, saved: list):
        """setStyleSheet 后调用: 恢复高亮。

        抑制期间鼠标离开的实例跳过恢复（用户已移开鼠标）。
        """
        cls._suppress = False
        for frame, state in saved:
            if frame._skip_restore:
                frame._skip_restore = False
                continue
            if state['selected'] == 'true':
                frame.setProperty("selected", "true")
            if state['clicked'] == 'true':
                frame.setProperty("clicked", "true")
            if state['light'] == 'true':
                frame.setProperty("light", "true")
            if frame._is_highlighted():
                cls._active_frames.add(frame)
            flash_style(frame)

    # ── 鼠标事件 ──

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        self._pressed = True
        self.setProperty("clicked", "true")
        self._register_highlight()
        flash_style(self)

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        if self._pressed and self.rect().contains(event.pos()):
            if event.button() == Qt.LeftButton and self._left_cb:
                self._left_cb()
            elif event.button() == Qt.RightButton and self._right_cb:
                self._right_cb()
        self._pressed = False
        self.setProperty("clicked", "false")
        self._register_highlight()
        flash_style(self)

    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        if event.buttons() & Qt.LeftButton and self._pressed:
            inside = self.rect().contains(event.pos())
            current = self.property("clicked")
            if inside and current != "true":
                self.setProperty("clicked", "true")
            elif not inside and current != "false":
                self.setProperty("clicked", "false")
            flash_style(self)

    def enterEvent(self, event):
        self._mouse_inside = True
        super().enterEvent(event)
        if self._on_enter_cb:
            self._on_enter_cb()

    def leaveEvent(self, event):
        self._mouse_inside = False
        if ClickFrame._suppress:
            self._skip_restore = True
        super().leaveEvent(event)
        if self._on_leave_cb:
            self._on_leave_cb()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._on_resize_cb:
            self._on_resize_cb()

    # ── BigButton: 大型虚拟按钮 ──

class BigButton(ClickFrame):
    """大型虚拟按钮 — ClickFrame + 居中标题文字，同 small_map create_click_label。

    Args:
        text: 按钮文字
        parent: 父控件
        default_line: 默认显示边框
        custom_class: 自定义 QSS class
        tooltip: 提示文字
        click_cb: 点击回调
    """

    def __init__(self, text: str, parent=None,
                 default_line: bool = True,
                 custom_class: str = None,
                 tooltip: str = None,
                 hand_cursor: bool = True,
                 click_cb: Callable = None):
        super().__init__(parent, hand_cursor=hand_cursor,
                         default_line=default_line,
                         custom_class=custom_class,
                         tooltip=tooltip)
        self._title = QLabel(text)
        self._title.setProperty("class", "section_title")
        self._title.setAlignment(Qt.AlignCenter)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 15, 10, 15)
        layout.addWidget(self._title)
        if click_cb:
            self.on_left_click(click_cb)

    def setText(self, text: str):
        self._title.setText(text)
