"""渐变色编辑器 — QPainter 渐变预览 + 可拖拽色标。"""

from __future__ import annotations

from copy import deepcopy

from PySide6.QtCore import Qt, QPointF, Signal
from PySide6.QtGui import (
    QColor, QLinearGradient, QPainter, QPainterPath, QPen, QBrush,
)
from PySide6.QtWidgets import QWidget, QColorDialog, QSizePolicy

_TRI_H = 10   # ▼ 高度
_BAR_H = 24   # 渐变条高度
_LABEL_H = 10 # 顶部标签区高度


class GradientBar(QWidget):
    """渐变色条 + 可拖拽 ▼ 色标。

    色标格式: ``{"pos": 0.0~1.0, "color": (r,g,b,a)}``
    最少 2 个，右键删除。

    Args:
        stops: 初始色标列表，默认白→黑
        live: True=拖动时实时发射 valueChanged，False=松手时发射
        parent: 父控件
    """

    valueChanged = Signal(list)

    def __init__(self, parent: QWidget = None,
                 stops: list[dict] | None = None,
                 live: bool = True):
        super().__init__(parent)
        self._stops: list[dict] = deepcopy(stops) if stops else [
            {"pos": 0.0, "color": (255, 255, 255, 255)},
            {"pos": 1.0, "color": (0, 0, 0, 255)},
        ]
        self._selected: int | None = None
        self._hovered: int | None = None
        self._dragging: int | None = None
        self._did_drag = False
        self._live = live
        self._hover_pos: QPointF | None = None
        self.setMouseTracking(True)
        self.setFixedHeight(_LABEL_H + 6 + _BAR_H + _TRI_H + 4)
        self.setMinimumWidth(160)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setCursor(Qt.ArrowCursor)

    # ── public ──

    def stops(self) -> list[dict]:
        return deepcopy(self._stops)

    def setStops(self, stops: list[dict]):
        self._stops = deepcopy(stops)
        self._stops.sort(key=lambda s: s["pos"])
        self._selected = None
        self._hovered = None
        self.update()

    def setPreviewBg(self, color: tuple | None):
        """设置预览背景色 (r,g,b,a)，None=透明。"""
        self._preview_bg = color
        self.update()

    # ── geometry ──

    def _bar(self):
        """渐变条 QRect。"""
        m = 16
        w = self.width() - m * 2
        return m, _LABEL_H + 6, max(w, 1), _BAR_H

    def _stop_x(self, i: int):
        x, _, w, _ = self._bar()
        return int(x + self._stops[i]["pos"] * w)

    def _stop_tri(self, i: int):
        """中间色标 ▼ 三角形三个顶点。端点返回 None。"""
        if i == 0 or i == len(self._stops) - 1:
            return None
        cx = self._stop_x(i)
        _, y, _, _ = self._bar()
        top = y + _BAR_H
        bot = top + _TRI_H
        return QPointF(cx, top), QPointF(cx - 6, bot), QPointF(cx + 6, bot)

    # ── hit test ──

    def _hit_test(self, pos: QPointF) -> int | None:
        x0, y0, _, _ = self._bar()
        # 端点 ▶ ◀ — 条形区域 + 外侧箭头
        for i in (0, len(self._stops) - 1):
            cx = self._stop_x(i)
            if (abs(pos.x() - cx) <= 14
                    and y0 - 2 <= pos.y() <= y0 + _BAR_H + 2):
                return i
        # 中间 ▼
        for i in range(1, len(self._stops) - 1):
            cx = self._stop_x(i)
            if (abs(pos.x() - cx) <= 8
                    and y0 <= pos.y() <= y0 + _BAR_H + _TRI_H + 4):
                return i
        return None

    # ── paint ──

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        x, y, w, h = self._bar()

        # ── 顶部标签区: 色标位置 % ──
        f = p.font()
        f.setPixelSize(9)
        p.setFont(f)
        for s in self._stops:
            cx = int(x + s["pos"] * w)
            txt = f"{s['pos'] * 100:.1f}%"
            tw = p.fontMetrics().horizontalAdvance(txt)
            p.setPen(QColor(100, 100, 100))
            p.drawText(int(cx - tw / 2), _LABEL_H - 1, txt)

        # ── 预览背景色 ──
        pb = getattr(self, '_preview_bg', None)
        if pb and len(pb) >= 4:
            p.setBrush(QBrush(QColor(*pb)))
        else:
            p.setBrush(QBrush(QColor(255, 255, 255, 0)))
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(x, y, w, h, 3, 3)

        # ── 渐变条 (横向, 覆盖在背景上) ──
        grad = QLinearGradient(QPointF(x, 0), QPointF(x + w, 0))
        for s in self._stops:
            grad.setColorAt(s["pos"], QColor(*s["color"]))
        p.setPen(QPen(QColor(100, 100, 100), 1))
        p.setBrush(QBrush(grad))
        p.drawRoundedRect(x, y, w, h, 3, 3)

        # ── 鼠标虚线 ──
        if self._hover_pos is not None and self._dragging is None:
            mx = max(x, min(x + w, int(self._hover_pos.x())))
            mp = (mx - x) / w * 100
            mtxt = f"{mp:.1f}%"
            mtw = p.fontMetrics().horizontalAdvance(mtxt)
            p.setPen(QColor(80, 80, 80))
            p.drawText(int(mx - mtw / 2), _LABEL_H - 1, mtxt)

            pen = QPen(QColor(80, 80, 80), 1)
            pen.setStyle(Qt.CustomDashLine)
            pen.setDashPattern([3, 3])
            p.setPen(pen)
            p.drawLine(mx, y, mx, y + h)

        # ── 中间色标 ▼ ──
        n = len(self._stops)
        for i in range(1, n - 1):
            s = self._stops[i]
            pts = self._stop_tri(i)
            if pts is None:
                continue
            a, b, c = pts
            path = QPainterPath()
            path.moveTo(a)
            path.lineTo(b)
            path.lineTo(c)
            path.closeSubpath()
            self._draw_marker(p, path, i, s)

        # ── 端点 ▶ ◀ (在最上层, 指向渐变条) ──
        arrow_w = 9
        mid_y = y + h // 2
        for i in (0, n - 1):
            s = self._stops[i]
            path = QPainterPath()
            if i == 0:
                path.moveTo(x - arrow_w, mid_y - 8)
                path.lineTo(x, mid_y)
                path.lineTo(x - arrow_w, mid_y + 8)
            else:
                path.moveTo(x + w + arrow_w, mid_y - 8)
                path.lineTo(x + w, mid_y)
                path.lineTo(x + w + arrow_w, mid_y + 8)
            path.closeSubpath()
            self._draw_marker(p, path, i, s)

        # ── hover 空白处 → 圆形 + ──
        if self._hover_pos is not None and self._dragging is None:
            hx = max(x, min(x + w, int(self._hover_pos.x())))
            by = y + _BAR_H + _TRI_H // 2
            r = 6
            p.setPen(QPen(QColor(120, 120, 120), 1))
            p.setBrush(QBrush(QColor(255, 255, 255, 220)))
            p.drawEllipse(QPointF(hx, by), r, r)
            p.drawLine(QPointF(hx - 3, by), QPointF(hx + 3, by))
            p.drawLine(QPointF(hx, by - 3), QPointF(hx, by + 3))

    def _draw_marker(self, p: QPainter, path: QPainterPath, i: int, s: dict):
        qc = QColor(*s["color"])
        if i == self._selected:
            p.setPen(QPen(QColor(80, 150, 255), 2))
            p.setBrush(QBrush(qc))
        elif i == self._hovered:
            p.setPen(QPen(QColor(150, 200, 255), 2))
            p.setBrush(QBrush(qc))
        else:
            p.setPen(QPen(QColor(80, 80, 80), 1))
            p.setBrush(QBrush(qc))
        p.drawPath(path)

    # ── mouse ──

    def mousePressEvent(self, event):
        if event.button() == Qt.RightButton:
            hit = self._hit_test(event.position())
            if hit is not None and hit != 0 and hit != len(self._stops) - 1:
                del self._stops[hit]
                self._selected = None
                self.update()
                self.valueChanged.emit(self.stops())
            return

        if event.button() == Qt.LeftButton:
            self._hover_pos = None
            hit = self._hit_test(event.position())
            if hit is not None:
                self._selected = hit
                self._dragging = hit
                self._did_drag = False
                self.update()
            else:
                # 空白处新增
                x_m, _, w_m, _ = self._bar()
                pos = max(0.01, min(0.99,
                    (event.position().x() - x_m) / w_m))
                color = self._interp(pos)
                self._stops.append({"pos": pos, "color": color})
                self._stops.sort(key=lambda s: s["pos"])
                idx = self._stops.index(
                    next(s for s in self._stops if abs(s["pos"] - pos) < 0.001))
                self._selected = idx
                self._dragging = idx
                self._did_drag = True
                self.update()
                self.valueChanged.emit(self.stops())

    def mouseMoveEvent(self, event):
        if self._dragging is not None:
            x_m, _, w_m, _ = self._bar()
            new_pos = max(0.0, min(1.0,
                (event.position().x() - x_m) / w_m))
            if self._dragging == 0:
                new_pos = 0.0
            elif self._dragging == len(self._stops) - 1:
                new_pos = 1.0
            stop = self._stops[self._dragging]
            stop["pos"] = new_pos
            self._stops.sort(key=lambda s: s["pos"])
            self._dragging = self._stops.index(stop)
            self._selected = self._dragging
            self._did_drag = True
            if self._live:
                self.valueChanged.emit(self.stops())
            self.update()
        else:
            hit = self._hit_test(event.position())
            if hit is None:
                self._hovered = None
                self._hover_pos = event.position()
                self.update()
            else:
                self._hovered = hit
                self._hover_pos = None
                self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            if self._dragging is not None and not self._did_drag:
                s = self._stops[self._dragging]
                c = QColor(*s["color"])
                dlg = QColorDialog(c, self)
                dlg.setOption(QColorDialog.ShowAlphaChannel, True)
                dlg.setOption(QColorDialog.DontUseNativeDialog, True)
                dlg.setWindowTitle("选择色标颜色")
                if dlg.exec() == QColorDialog.Accepted:
                    nc = dlg.currentColor()
                    s["color"] = (nc.red(), nc.green(),
                                  nc.blue(), nc.alpha())
                    self.update()
                    self.valueChanged.emit(self.stops())
                self._selected = None
            elif self._dragging is not None and self._did_drag:
                self.valueChanged.emit(self.stops())
                self._selected = None
            self._dragging = None
            self._did_drag = False
            self.update()

    def leaveEvent(self, event):
        self._hovered = None
        self._hover_pos = None
        self.update()

    # ── helper ──

    def _interp(self, pos: float) -> tuple[int, int, int, int]:
        """在给定位置插值颜色。"""
        lo = self._stops[0]
        hi = self._stops[-1]
        for s in self._stops:
            if s["pos"] <= pos:
                lo = s
            if s["pos"] >= pos and hi["pos"] > pos:
                hi = s
                break
        if lo is hi:
            return lo["color"]
        t = (pos - lo["pos"]) / (hi["pos"] - lo["pos"]) if hi["pos"] != lo["pos"] else 0
        return tuple(
            int(lo["color"][i] + (hi["color"][i] - lo["color"][i]) * t)
            for i in range(4)
        )
