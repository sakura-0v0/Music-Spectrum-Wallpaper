from __future__ import annotations
"""主题选择弹出窗口，同 small_map 的 ThemeChoiceButton + ThemePopup。"""

from typing import OrderedDict

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
    QLabel, QScrollArea,
)

from xiaoe_ui.core.dialog import Dialog
from xiaoe_ui.core.singleton_mixin import SingletonMixin


_SINGLETON_KEY = "theme_popup"


class ThemePopup(Dialog, SingletonMixin):
    """主题选择弹出窗口，按分组网格展示主题按钮。

    非阻塞 Dialog + 单例管理，同一时间只存在一个。

    Args:
        themes: {group_name: [theme_name, ...], ...}
        parent: 父控件
    """

    themeSelected = Signal(str)

    def __init__(self,
                 themes: OrderedDict[str, list[str]],
                 parent: QWidget = None,
                 ):
        Dialog.__init__(self, parent=parent, win_title="选择主题",
                        width=550, height=400, set_fixed_size=False,
                        modal=False)
        SingletonMixin._singleton_init(self, _SINGLETON_KEY, only_one=True)

        self.root_layout.setSpacing(2)
        self.root_layout.setContentsMargins(10, 10, 10, 10)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setProperty("class", "no-border")

        content = QWidget()
        content.setProperty("class", "root")
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(2)

        self._make_buttons(themes, content_layout)

        scroll.setWidget(content)
        self.root_layout.addWidget(scroll)

    def _make_buttons(self,
                      themes: OrderedDict[str, list[str]],
                      content_layout: QVBoxLayout,
                      ):
        """按分组遍历，每组一个标题+网格按钮。"""
        max_per_row = 4

        def _fill_row(row_layout: QHBoxLayout | None,
                      btn_count: int,
                      ) -> None:
            if row_layout is None:
                return
            for _ in range(max_per_row - btn_count):
                e = QPushButton()
                e.setFlat(True)
                e.setStyleSheet(
                    "color:rgba(0,0,0,0);background:rgba(0,0,0,0);border:none;")
                e.setEnabled(False)
                e.setCursor(Qt.ArrowCursor)
                row_layout.addWidget(e)

        for group_name, group_themes in themes.items():
            if not group_themes:
                continue

            sep = QLabel(group_name)
            sep.setProperty("class", "section_title")
            sep.setAlignment(Qt.AlignCenter)
            content_layout.addWidget(sep)

            row_layout: QHBoxLayout | None = None
            btn_count = 0
            for theme_name in group_themes:
                if row_layout is None or btn_count >= max_per_row:
                    _fill_row(row_layout, btn_count)
                    row_layout = QHBoxLayout()
                    row_layout.setSpacing(2)
                    row_layout.setContentsMargins(0, 0, 0, 0)
                    content_layout.addLayout(row_layout)
                    btn_count = 0

                btn = QPushButton(theme_name)
                btn.setCursor(Qt.PointingHandCursor)
                btn.clicked.connect(
                    lambda checked, n=theme_name: self.on_theme_clicked(n))
                row_layout.addWidget(btn)
                btn_count += 1

            _fill_row(row_layout, btn_count)

    def on_theme_clicked(self,
                         name: str,
                         ):
        """选中主题，发射信号（不关闭弹窗，方便连续切换）。

        Args:
            name: 主题名
        """
        self.themeSelected.emit(name)

    def closeEvent(self,
                   event,
                   ):
        """关闭时释放单例注册。"""
        SingletonMixin._singleton_close(self)
        super().closeEvent(event)


class ThemeChoiceButton(QPushButton):
    """主题选择按钮，点击弹出 ThemePopup（非阻塞 Dialog，单例管理）。

    Args:
        parent: 父控件
    """

    currentIndexChanged = Signal(int)
    currentTextChanged = Signal(str)

    def __init__(self,
                 parent: QWidget = None,
                 ):
        super().__init__(parent)
        self._options: list[str] = []
        self._themes: OrderedDict[str, list[str]] = OrderedDict()
        self._index: int = -1
        self._text: str = ""
        self.setCursor(Qt.PointingHandCursor)
        self.setText("请选择")
        self.clicked.connect(self.show_popup)

    def set_themes(self,
                   themes: OrderedDict[str, list[str]],
                   ):
        """设置主题数据（嵌套字典）。

        Args:
            themes: {group_name: [theme_name, ...], ...}
        """
        self._options.clear()
        self._themes = themes
        for names in themes.values():
            self._options.extend(names)

    def setCurrentIndex(self,
                        index: int,
                        ):
        """设置当前选中索引。

        Args:
            index: 选项列表中的索引
        """
        if 0 <= index < len(self._options):
            self._index = index
            self._text = self._options[index]
            self.setText(self._text)
            self.currentIndexChanged.emit(index)
            self.currentTextChanged.emit(self._text)

    def setCurrentText(self,
                       text: str,
                       ):
        """设置当前选中文本。

        Args:
            text: 主题名
        """
        if text in self._options:
            self.setCurrentIndex(self._options.index(text))

    def currentIndex(self) -> int:
        """当前选中的索引。"""
        return self._index

    def currentText(self) -> str:
        """当前选中的文本。"""
        return self._text

    @SingletonMixin.open_too_many_except()
    def show_popup(self):
        """弹出主题选择窗口（单例，非阻塞）。同 dcjl 装饰器模式。"""
        if not self._options:
            return

        popup = ThemePopup(self._themes, self)
        popup.themeSelected.connect(self._on_theme_selected)
        popup.show()

    def _on_theme_selected(self,
                           name: str,
                           ):
        """弹窗选中回写。

        Args:
            name: 主题名
        """
        if name in self._options:
            self.setCurrentText(name)
