"""mixin 组合出的快速控件：按钮、复选框、组合框、滑块、即时提示等。"""
from PySide6.QtCore import Qt, QPoint
from PySide6.QtWidgets import QCheckBox, QComboBox, QLabel, QPushButton, QSlider

from xiaoe_ui.widgets.basic import HandCursorMixin, IgnoreWheelMixin
from xiaoe_ui.widgets.instant_tip import InstantTooltipMixin


# ── 手型鼠标 ──

class QPushButtonHandCursor(HandCursorMixin, QPushButton):
    """手型鼠标按钮。"""
    pass


class QCheckBoxHandCursor(HandCursorMixin, QCheckBox):
    """手型鼠标复选框。"""
    pass


# ── 组合框 ──

class CustomComboBox(HandCursorMixin, IgnoreWheelMixin, QComboBox):
    """忽略滚轮的组合框，防止误触滚动改变选项。"""
    pass


# ── 滑块 ──

class CustomSlider(IgnoreWheelMixin, InstantTooltipMixin, QSlider):
    """忽略滚轮，鼠标悬停/拖拽时即时显示自定义 tooltip。

    Args:
        range_text: 范围文本，如 "0~100"
        num_type_text: 单位文本，如 "px"
    """

    def __init__(self, *args,
                 range_text: str = "",
                 num_type_text: str = "",
                 **kwargs,
                 ):
        self.range_text = range_text
        self.num_type_text = num_type_text
        self.value_text = ""
        super().__init__(*args, **kwargs)
        self.setCursor(Qt.SizeHorCursor)

    def _get_tip_text(self) -> str:
        return f"范围：{self.range_text} - 当前：{self.value_text} {self.num_type_text}"

    def mousePressEvent(self, event):
        super().mousePressEvent(event)
        self._tip_locked = True
        self.show_tip()

    def mouseMoveEvent(self, event):
        super().mouseMoveEvent(event)
        self.update_tip(self._get_tip_text())

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        self._tip_locked = False
        if not self.underMouse():
            self.hide_tip()

    def leaveEvent(self, event):
        if not self._tip_locked:
            super().leaveEvent(event)


# ── 即时提示 ──

class InstantTipLabel(InstantTooltipMixin, QLabel):
    """带即时 tooltip 的 QLabel。"""
    pass


class InstantTipButton(InstantTooltipMixin, QPushButton):
    """带即时 tooltip 的 QPushButton。"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setCursor(Qt.PointingHandCursor)
