"""表单行布局 — 把"标题 + stretch + 控件"的重复代码抽到一处。

用法:
    from xiaoe_ui.widgets.form_layout import make_form_row
    from xiaoe_ui.widgets.status_widgets import StatusLineEdit

    field = StatusLineEdit(text="hello")
    row = make_form_row("名称", field)
    page.addWidget(row)
"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QWidget,
)

from xiaoe_ui.widgets.click_frame import ClickFrame
from xiaoe_ui.utils.dpi import title_min_width


def make_form_row(title: str,
                  widget: QWidget,
                  ) -> ClickFrame:
    """标准表单行: [标题] [stretch] [控件]。

    Args:
        title: 左侧标签文字
        widget: 右侧表单控件

    Returns:
        ClickFrame 行容器，可直接 addWidget 到布局
    """
    inner = ClickFrame(hand_cursor=False, custom_class="light-line disable")
    layout = QHBoxLayout(inner)
    layout.setContentsMargins(5, 3, 5, 3)

    name_label = QLabel(title)
    name_label.setProperty("class", "line_title")
    name_label.setMinimumWidth(title_min_width())
    layout.addWidget(name_label)
    layout.addStretch(1)
    layout.addWidget(widget)

    return inner
