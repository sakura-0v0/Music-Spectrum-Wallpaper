from PySide6.QtWidgets import QFrame


def empty_frame(width, is_H=False, class_text ="block"):
    """
    创建定长或定宽的frame
    Args:
        width: 宽度或高度
        is_H: True：设置固定的高度。False：设置固定的宽度。
    """
    f = QFrame()
    f.setProperty("class", class_text)
    if not is_H:
        f.setFixedWidth(width)
    else:
        f.setFixedHeight(width)
    return f