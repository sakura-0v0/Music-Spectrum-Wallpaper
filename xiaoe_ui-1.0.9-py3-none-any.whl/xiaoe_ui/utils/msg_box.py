from __future__ import annotations
"""通用消息弹窗，继承 MsgBox (QMessageBox + WinManager)，同 dcjl_plus show_custom_message。

通过 WinManager 注入样式和背景，同 MainWin/Dialog 方式。
"""
from xiaoe_ui.core.dialog import Dialog
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QMessageBox, QDialog, QDialogButtonBox, QVBoxLayout, QLabel, QLineEdit,
)

from xiaoe_ui.core.win_manager import WinManager

btn_min_width = 70

class MsgBox(WinManager, QMessageBox):
    """带 WinManager 背景的 QMessageBox。

    通过 WinManager.set_style_source / set_bg_source 注入样式。
    """

    def __init__(self, *args, btn_min_width = btn_min_width, **kwargs):
        self.btn_min_width = btn_min_width
        super().__init__(*args, **kwargs)
        self.is_setup = True
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.add_bg(bg_alpha_class="block")
        self._register()
        self.apply_all()

    def button(self, *args, **kwargs):
        btn = super().button(*args, **kwargs)
        btn.setMinimumWidth(self.btn_min_width)
        return btn


def ask(title: str, message: str,
        yes_text: str = "是", no_text: str = "否",
        with_cancel: bool = False,
        icon=QMessageBox.Question) -> bool | None:
    """询问弹窗 Yes/No 或 Yes/No/Cancel。

    Args:
        title: 弹窗标题
        message: 消息内容
        yes_text: "是"按钮文字
        no_text: "否"按钮文字
        with_cancel: True 则添加"取消"按钮
        icon: QMessageBox 图标

    Returns:
        True (Yes), False (No), None (Cancel)
    """
    buttons = (QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
               if with_cancel else QMessageBox.Yes | QMessageBox.No)

    box = MsgBox()
    box.setIcon(icon)
    box.setWindowTitle(title)
    box.setText(message)
    box.setStandardButtons(buttons)
    box.button(QMessageBox.Yes).setText(yes_text)
    box.button(QMessageBox.No).setText(no_text)
    if with_cancel:
        box.button(QMessageBox.Cancel).setText("取消")
    box.setDefaultButton(QMessageBox.Yes)

    result = box.exec()

    if with_cancel:
        if result == QMessageBox.Yes:
            return True
        elif result == QMessageBox.No:
            return False
        return None
    return result == QMessageBox.Yes


def info(title: str, message: str) -> bool:
    """信息弹窗 Ok。

    Args:
        title: 标题
        message: 内容

    Returns:
        True
    """
    box = MsgBox()
    box.setIcon(QMessageBox.Information)
    box.setWindowTitle(title)
    box.setText(message)
    box.setStandardButtons(QMessageBox.Ok)
    box.button(QMessageBox.Ok).setText("确定")
    box.exec()
    return True


def warn(title: str, message: str) -> bool:
    """警告弹窗 Ok。

    Args:
        title: 标题
        message: 内容

    Returns:
        True
    """
    box = MsgBox()
    box.setIcon(QMessageBox.Warning)
    box.setWindowTitle(title)
    box.setText(message)
    box.setStandardButtons(QMessageBox.Ok)
    box.button(QMessageBox.Ok).setText("确定")
    box.exec()
    return True


def error(title: str, message: str) -> bool:
    """错误弹窗 Ok。

    Args:
        title: 标题
        message: 内容

    Returns:
        True
    """
    box = MsgBox()
    box.setIcon(QMessageBox.Critical)
    box.setWindowTitle(title)
    box.setText(message)
    box.setStandardButtons(QMessageBox.Ok)
    box.button(QMessageBox.Ok).setText("确定")
    box.exec()
    return True


def input_dialog(title: str, message: str, default_text: str = "") -> str | None:
    """带输入框的对话框。

    Args:
        title: 标题
        message: 提示文字
        default_text: 默认输入

    Returns:
        输入文本，取消返回 None
    """
    dlg = Dialog(win_title=title, width=350, height=150)
    dlg.root_layout.addWidget(QLabel(message))
    inp = QLineEdit(default_text)
    dlg.root_layout.addWidget(inp)
    btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    btns.button(QDialogButtonBox.Ok).setText("确定")
    btns.button(QDialogButtonBox.Cancel).setText("取消")
    btns.accepted.connect(dlg.accept)
    btns.rejected.connect(dlg.reject)
    dlg.root_layout.addWidget(btns)

    if dlg.exec() == QDialog.Accepted:
        return inp.text()
    return None
