from __future__ import annotations
"""自定义字体选择对话框，使用框架 Dialog 统一风格。"""

from PySide6.QtWidgets import (
    QDialogButtonBox,
    QFontComboBox,
    QLabel, QDialog,
)
from PySide6.QtGui import QFont


def font_picker_dialog(
    default_family: str = "",
    title: str = "选择字体",
    parent=None,
) -> str | None:
    """弹出字体选择对话框，返回字体族名。

    Args:
        default_family: 预选字体族名，如 ``"Microsoft YaHei"``
        title: 窗口标题
        parent: 父窗口

    Returns:
        字体族名字符串，取消返回 None
    """
    from xiaoe_ui.core.dialog import Dialog

    dlg = Dialog(parent, win_title=title, width=420, height=220)

    dlg.root_layout.addWidget(QLabel("请选择要使用的字体:"))

    combo = QFontComboBox()
    combo.setFontFilters(QFontComboBox.ScalableFonts)
    if default_family:
        combo.setCurrentFont(QFont(default_family))
    dlg.root_layout.addWidget(combo)

    title_lbl = QLabel("主标题 Section Title")
    title_lbl.setProperty("class", "section_title")

    sub_lbl = QLabel("副标题 Line Title")
    sub_lbl.setProperty("class", "line_title")

    tip_lbl = QLabel("这是一段提示文字 The quick brown fox")
    tip_lbl.setProperty("class", "tip-text")

    def _update_preview(family: str):
        for lbl in (title_lbl, sub_lbl, tip_lbl):
            lbl.setStyleSheet(f"font-family: \"{family}\";")

    _update_preview(combo.currentFont().family())
    combo.currentFontChanged.connect(lambda f: _update_preview(f.family()))

    dlg.root_layout.addWidget(title_lbl)
    dlg.root_layout.addWidget(sub_lbl)
    dlg.root_layout.addWidget(tip_lbl)

    dlg.root_layout.addStretch(1)

    btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    btns.button(QDialogButtonBox.Ok).setText("确定")
    btns.button(QDialogButtonBox.Cancel).setText("取消")
    btns.accepted.connect(dlg.accept)
    btns.rejected.connect(dlg.reject)
    dlg.root_layout.addWidget(btns)

    if dlg.exec() == QDialog.Accepted:
        return combo.currentFont().family()
    return None
