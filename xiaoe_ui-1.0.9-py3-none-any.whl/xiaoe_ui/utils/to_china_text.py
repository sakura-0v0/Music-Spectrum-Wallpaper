from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTranslator, QLibraryInfo

def to_china_text(app: QApplication) -> None:
    """将QT自带的窗口翻译为中文"""
    translator = QTranslator()
    translations_path = QLibraryInfo.path(QLibraryInfo.TranslationsPath)
    if translator.load("qt_zh_CN", translations_path):
        app._translator = translator
        app.installTranslator(translator)