from __future__ import annotations
"""线程安全UI调度：将回调投递到Qt主线程执行，支持同步阻塞等待返回值。"""

import queue
from typing import Any, Callable, Dict
from PySide6.QtCore import QObject, Signal, QTimer


class _QtRun(QObject):
    """单例调度器，使用队列+信号实现主线程调用同步返回。"""
    _instance = None

    # 类变量用于管理多个并发调用
    _result_id: int = 0
    _result_queues: Dict[int, queue.Queue] = {}
    _run_signal = Signal(dict)   # 定义信号，携带 {'func': callable}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, '_initialized'):
            super().__init__()
            self._run_signal.connect(lambda d: d['func']())
            self._initialized = True

    def _get_id(self) -> int:
        """分配唯一ID并创建结果队列"""
        self._result_id += 1
        q = queue.Queue()
        self._result_queues[self._result_id] = q
        return self._result_id

    def run(self, func: Callable) -> None:
        """异步执行：不等待结果"""
        self._run_signal.emit({'func': func})

    def run_block(self, func: Callable) -> Any:
        """同步执行：阻塞等待返回值"""
        my_id = self._get_id()
        q = self._result_queues[my_id]

        def wrapper():
            try:
                result = func()
            except Exception as e:
                # 将异常放入队列，以便在调用端重新抛出
                q.put(('__EXC__', e))
            else:
                q.put(('__OK__', result))

        self._run_signal.emit({'func': wrapper})
        # 阻塞等待结果
        status, value = q.get(block=True)
        del self._result_queues[my_id]
        if status == '__EXC__':
            raise value
        return value


# 全局单例
_qt_run = _QtRun()


# ---------- 对外接口（与第一个模块完全一致） ----------
def run_in_main(func: Callable) -> None:
    """异步在主线程执行 func"""
    _qt_run.run(func)


def run_in_main_block(func: Callable) -> Any:
    """同步阻塞在主线程执行 func，返回其返回值"""
    return _qt_run.run_block(func)


def in_main_block(func: Callable) -> Callable:
    """
    同步装饰器：将函数变为“在主线程执行，调用方阻塞等待返回值”。
    用法：@in_main
    """
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return run_in_main_block(lambda: func(*args, **kwargs))
    return wrapper


def in_main(func: Callable) -> Callable:
    """
    异步装饰器：将函数变为“在主线程执行，调用方不等待结果”。
    用法：@in_main_async
    注意：被装饰函数不应有返回值（或返回值被忽略）。
    """
    def wrapper(*args: Any, **kwargs: Any) -> None:
        run_in_main(lambda: func(*args, **kwargs))
    return wrapper