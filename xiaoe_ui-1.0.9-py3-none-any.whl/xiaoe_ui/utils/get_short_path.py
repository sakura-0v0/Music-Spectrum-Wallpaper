def get_short_path(path: str, max_len: int = 25) -> str:
    """截断过长路径的显示文字。同 small_map tools/get_short_path。

    Args:
        path: 完整文件路径
        max_len: 最大显示长度，默认 25

    Returns:
        缩略后的显示文字，如 "E:/.../background.png"
    """
    text = path
    if len(path) > max_len:
        start = text[:3]
        end = text.split("/")[-1]
        if len(end) + 4 + 3 > max_len:
            end = end[:max_len - 4 - 3 - 2] + ".."
        text = f"{start}.../{end}"
    return text
