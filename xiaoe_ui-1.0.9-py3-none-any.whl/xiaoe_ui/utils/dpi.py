"""分辨率缩放工具，以 1920×1080 为基准等比换算。"""

from __future__ import annotations

from PySide6.QtWidgets import QApplication

_BASE_W: int = 1920
_BASE_H: int = 1080


def _get_scale_ratio() -> float:
    """计算当前屏幕相对于 1920×1080 的缩放比例（取宽高中较小值）。"""
    app = QApplication.instance()
    if app:
        screen = app.primaryScreen()
        if screen:
            size = screen.size()
            return min(size.width() / _BASE_W, size.height() / _BASE_H)
    return 1.0


def resize_elem(val: int) -> int:
    """以 1920×1080 为基准放大 px 值。

    Args:
        val: 1080p 基准下的像素值

    Returns:
        当前分辨率下的实际像素值
    """
    return int(val * _get_scale_ratio())


def de_resize_elem(val: int) -> int:
    """resize_elem 的逆运算。

    Args:
        val: 当前分辨率下的实际像素值

    Returns:
        1080p 基准下的像素值
    """
    return int(val / _get_scale_ratio())


_title_min_width_cache: int | None = None


def title_min_width(chars: int = 7) -> int:
    """返回 N 个中文字符的像素宽度，结果缓存。

    用于统一配置项标题的最小宽度。
    """
    global _title_min_width_cache
    if _title_min_width_cache is not None:
        return _title_min_width_cache
    from PySide6.QtWidgets import QLabel
    label = QLabel("中" * chars)
    label.setProperty("class", "line_title")
    import PySide6.QtGui
    fm = PySide6.QtGui.QFontMetrics(label.font())
    _title_min_width_cache = fm.horizontalAdvance("中" * chars) + 6
    return _title_min_width_cache
