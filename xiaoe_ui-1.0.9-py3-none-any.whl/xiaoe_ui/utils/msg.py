from __future__ import annotations
"""线程安全日志，带颜色标记。"""

from PySide6.QtCore import QObject, Signal


class Msg(QObject):
    """线程安全日志发射器，通过Qt信号将日志投递到主线程。

    用法:
        msg = Msg()
        msg.info("这是一条信息")
        msg.ok("操作成功")
        msg.warn("警告信息")
        msg.err("错误信息")

        # 连接到UI
        msg.new_msg.connect(text_widget.append)
    """

    new_msg = Signal(str)

    _COLORS = {
        'info': '#5dade2',
        'ok': '#27ae60',
        'warn': '#f39c12',
        'err': '#e74c3c',
    }

    def _emit(self, kind, text):
        color = self._COLORS.get(kind, '#ffffff')
        html = f'<span style="color:{color}">[{kind.upper()}]</span> {text}'
        self.new_msg.emit(html)

    def info(self, text):
        self._emit('info', text)

    def ok(self, text):
        self._emit('ok', text)

    def warn(self, text):
        self._emit('warn', text)

    def err(self, text):
        self._emit('err', text)
