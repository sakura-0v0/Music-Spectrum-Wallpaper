from __future__ import annotations
"""长按检测工具，同 small_map check_key_hook / cancel_key_hook。"""

from typing import Callable

from PySide6.QtCore import QTimer


class LongPressDetector:
    """检测按键长按。

    key_down(name) → 启动计时，超时触发 long_cb
    key_up(name)   → timer 活跃 = 未超时 → 短按；timer 已触发 → 长按，不触发短按

    用法:
        detector = LongPressDetector()
        # 在键盘的 down_fun 中:
        detector.key_down("my_key", timeout=1.0,
                          long_cb=lambda: print("长按"))
        # 在键盘的 up_fun 中:
        detector.key_up("my_key",
                        short_cb=lambda: print("短按"))
    """

    def __init__(self):
        self._timers: dict[str, QTimer] = {}

    def key_down(self, name: str, timeout: float = 1.0,
                 long_cb: Callable[[], None] = None):
        """按键按下：启动超时计时器。

        Args:
            name: 按键标识名
            timeout: 长按判定时间（秒）
            long_cb: 超时后触发的回调（即长按）
        """
        timer = self._timers.get(name)
        if timer is None:
            timer = QTimer()
            timer.setSingleShot(True)
            timer.timeout.connect(lambda n=name: self._on_timeout(n))
            self._timers[name] = timer
        elif timer.isActive():
            timer.stop()

        # 将回调挂在 timer 上
        timer._long_cb = long_cb  # type: ignore[attr-defined]
        timer.start(int(timeout * 1000))

    def _on_timeout(self, name: str):
        """计时器到点，触发长按回调。"""
        timer = self._timers.get(name)
        if timer and hasattr(timer, '_long_cb') and timer._long_cb:
            timer._long_cb()

    def key_up(self, name: str, short_cb: Callable[[], None] = None):
        """按键松开：判断是短按还是长按。

        timer 活跃 → 未超时 → 短按 → 触发 short_cb
        timer 已触发 → 长按 → 不触发 short_cb

        Args:
            name: 按键标识名
            short_cb: 短按回调
        """
        timer = self._timers.get(name)
        if timer and timer.isActive():
            timer.stop()
            if short_cb:
                short_cb()
