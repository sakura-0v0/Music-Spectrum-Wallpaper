from __future__ import annotations
"""通用静态资源路径解析器，支持 PyInstaller 各种打包模式。"""

import os
import sys


def resolve_static(rel_path: str) -> str:
    """将相对项目根目录的路径解析为实际文件路径。

    解析顺序:
        1. PyInstaller 打包后 (``sys._MEIPASS`` / ``sys._internal``)
        2. 当前工作目录 (开发环境 ``python demo.py``)
        3. xiaoe_ui 包内回退 (pip install 后 ``site-packages/xiaoe_ui/``)

    Args:
        rel_path: 相对项目根目录的路径，如 ``"xiaoe_ui/static/yes.png"``

    Returns:
        解析后的绝对路径

    Raises:
        FileNotFoundError: 所有路径均不存在
    """
    # 1. PyInstaller 打包后（新旧版本）
    for attr in ("_MEIPASS", "_internal"):
        base = getattr(sys, attr, None)
        if base is not None:
            p = os.path.join(base, rel_path)
            if os.path.exists(p):
                return p

    # 2. 当前工作目录（开发环境）
    p = os.path.join(os.getcwd(), rel_path)
    if os.path.exists(p):
        return p

    # 3. xiaoe_ui 包内回退（pip install）
    import xiaoe_ui
    pkg_dir = os.path.dirname(os.path.dirname(os.path.abspath(xiaoe_ui.__file__)))
    p = os.path.join(pkg_dir, rel_path)
    if os.path.exists(p):
        return p

    raise FileNotFoundError(f"静态资源未找到: {rel_path}")
