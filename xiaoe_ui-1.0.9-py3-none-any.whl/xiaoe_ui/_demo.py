"""
xiaoe_ui 框架演示 — 平铺展示框架全部能力。

运行: xiaoe_ui-demo  或  python -m xiaoe_ui.demo
"""

import sys
import os
from typing import List

from xiaoe_ui.utils.long_press import LongPressDetector
from xiaoe_ui.utils.static_path import resolve_static
from xiaoe_ui.core.win_manager import WinManager

from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QFrame,
)
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QColor, QBrush, QPainterPath

from xiaoe_ui import (
    MainWin, MainLayout, LeftList,
    TopBoxWindow, NotifyOverlay, Dialog, FramelessWin,
    StyleEngine, make_line, make_tip,
    CheckItem, ComboItem, SliderItem, ColorItem, KeyItem, BottomItem,
    TextEntry, SpinEntry, MultiEntry, ImagePicker, DatePicker, ComboEntry,
    GradientItem, flash_config_widget, register_tag,
    StatusLineEdit, StatusDateEdit, StatusTextEdit, StatusImagePicker,
    make_form_row,
    ClickFrame, BigButton, InstantTipLabel, InstantTipButton,
    ClickThroughMixin,
    ThemePage, Msg, ask, info, warn, error, input_dialog, run_in_main,
)

from xiaoe_ui._demo_configs import config, theme_cfg, key_cfg, form_cfg, ct_config, engine
from xiaoe_ui.utils.to_china_text import to_china_text

msg = Msg()
notify: NotifyOverlay | None = None

try:
    from xiaoe_keyboard import Keyboard, HotkeyType
    _has_keyboard = True
except Exception:
    _has_keyboard = False


def _draw_heart(painter, rect):
    import math
    cx, cy = rect.center().x(), rect.center().y()
    s = min(rect.width(), rect.height()) * 0.028
    path = QPainterPath()
    first = True
    for i in range(101):
        t = i * 2 * math.pi / 100
        x = cx + s * 16 * math.sin(t) ** 3
        y = cy - s * (13 * math.cos(t) - 5 * math.cos(2 * t)
                      - 2 * math.cos(3 * t) - math.cos(4 * t))
        if first:
            path.moveTo(x, y)
            first = False
        else:
            path.lineTo(x, y)
    path.closeSubpath()
    painter.setBrush(QBrush(QColor(255, 100, 150, 200)))
    painter.setPen(QColor(255, 60, 120, 200))
    painter.drawPath(path)


# ═══════════════════════════════════════════════════════════
# 穿透窗口演示 — FramelessWin + ClickThroughMixin 组合积木
#   FramelessWin: 无边框、拖拽移动、8方向 resize、编辑模式
#   ClickThroughMixin: Qt 穿透 flag + 全局鼠标钩子 + 命中测试
#   注册 callback: on_left/on_right/on_middle + on_hover/on_press/on_normal
# ═══════════════════════════════════════════════════════════

class ClickThroughDemoWin(ClickThroughMixin, FramelessWin):
    """穿透窗口演示 — FramelessWin + ClickThroughMixin 组合积木。

    穿透模式下仅已注册按钮可被点击，空白区域穿透到下层。
    FramelessWin 提供编辑模式（拖拽移动、8方向 resize）。
    覆写 _load_config / _save_config 持久化窗口位置大小。
    """

    def __init__(self, ct_config, parent = None):
        self._ct_config = ct_config
        super().__init__(
            parent=parent,
            cuantou=True,
            use_global_style=True,
            on_top_with_global=False,
            rsize_margin=6,
        )
        # ── UI: 添加到 FramelessWin.content_frame, 使用框架统一 block 样式 ──
        root_layout = QVBoxLayout(self)
        root_layout.setContentsMargins(0,0,0,0)
        main_frame = QWidget(self)
        main_frame.setProperty("class", "root with-big-radius")
        root_layout.addWidget(main_frame, 1)

        layout = QVBoxLayout(main_frame)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(10)

        title = QLabel("穿透窗口演示")
        title.setProperty("class", "section_title")
        layout.addWidget(title)

        self._click_count = 0
        self._status = QLabel("状态：正常（点击 0 次）")
        self._status.setProperty("class", "tip-text")
        layout.addWidget(self._status)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)
        self._btn_left = QPushButton("识别左键")
        self._btn_right = QPushButton("识别右键")
        self._btn_middle = QPushButton("识别中键")
        for b in [self._btn_left, self._btn_right, self._btn_middle]:
            btn_row.addWidget(b)
        layout.addLayout(btn_row)

        hint = QLabel("穿透时仅按钮区域响应 · 空白穿透到下层")
        hint.setProperty("class", "tip-text")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        main_frame.setStyleSheet(
            "QWidget.with-big-radius {"
            "   border-radius: 20px;"
            "}"
        )

        # ── 注册可点击控件 ──
        def _clicked(btn_name):
            self._click_count += 1
            c = self._click_count
            print(f"  [DEMO] 点击#{c} {btn_name}")
            self._status.setText(f"状态：正常（点击 {c} 次）")
            notify.show(f"触发{btn_name} (#{c})")

        def _pressed(btn_name):
            print(f"  [DEMO] 按下 {btn_name}")
            self._status.setText(f"状态：按下 · {btn_name}")

        def _normal():
            print(f"  [DEMO] 松开鼠标")
            self._status.setText(f"状态：松开鼠标（点击 {self._click_count} 次）")

        self.register_clickable(
            self._btn_left,
            on_left=lambda: _clicked("左键"),
            on_press=lambda: _pressed("左键"),
            on_normal=_normal,
        )
        self.register_clickable(
            self._btn_right,
            on_right=lambda: _clicked("右键"),
            on_press=lambda: _pressed("右键"),
            on_normal=_normal,
        )
        self.register_clickable(
            self._btn_middle,
            on_middle=lambda: _clicked("中键"),
            on_press=lambda: _pressed("中键"),
            on_normal=_normal,
        )

        self.register_click_other(lambda: notify.show("触发空白区域"))

        # ── 默认几何（构造时穿透 flag 已一次性设好，不再调 setWindowFlags）──
        self.adjustSize()
        self.resize(self.sizeHint().width(),
                    self.sizeHint().height())

    def _set_status(self, state: str, btn: str = ""):
        t = f"状态：{state}{' · ' + btn if btn else ''}"
        self._status.setText(t)

    # ── 持久化窗口位置大小 ──

    def _load_config(self):
        geo = self._ct_config.get("ct_win_geo")
        if geo:
            self.setGeometry(geo["x"], geo["y"], geo["width"], geo["height"])
            self.keep_aspect_ratio = geo.get("keep_aspect_ratio", False)
            if self.keep_aspect_ratio and geo["width"] > 0 and geo["height"] > 0:
                self.aspect_ratio = geo["width"] / geo["height"]

    def _save_config(self):
        self._ct_config.set("ct_win_geo", {
            "x": self.x(),
            "y": self.y(),
            "width": self.width(),
            "height": self.height(),
            "keep_aspect_ratio": self.keep_aspect_ratio,
        })


# ═══════════════════════════════════════════════════════════
# 2. 主窗口 — 继承 MainWin(FramelessWin + WinManager)
#    覆盖 add_ui() 构建界面，构造时传入 engine 和 theme_cfg
# ═══════════════════════════════════════════════════════════

class DemoApp(MainWin):
    def __init__(self, engine: StyleEngine, theme_cfg):
        super().__init__(win_title="xiaoe_ui 演示", scroll=False)
        self._engine = engine
        self._theme_cfg = theme_cfg
        self.init_xiaoe_keyboard()
        self.setup_ui()
        self.resize(1100, 700)
        self.apply_all()

    def init_xiaoe_keyboard(self):
        if not _has_keyboard:
            return

        lp = LongPressDetector()

        def _save_fun(name, value):
            key_cfg.set(name, list(value))
            notify.show(f"热键 {name} 已保存: {list(value)}")

        down_q = lambda: notify.show("按下 Q", hide_after=0.5)
        up_w = lambda: notify.show("松开 W", hide_after=0.5)
        down_e = lambda: notify.show("按下 E", hide_after=0.5)
        up_e = lambda: notify.show("松开 E", hide_after=0.5)
        long_r = lambda: notify.show("长按 R: 1秒", hide_after=0.5)
        long_t = lambda: notify.show("长按 T: 2秒", hide_after=0.5)
        long_y = lambda: notify.show("长按 Y: 1秒", hide_after=0.5)
        short_y = lambda: notify.show("短按 Y", hide_after=0.5)

        hotkey_list: List[HotkeyType] = [
            {"name": "demo_key_down",
             "value": set(key_cfg.get("demo_key_down")),
             "down_fun": down_q},
            {"name": "demo_key_up",
             "value": set(key_cfg.get("demo_key_up")),
             "up_fun": up_w},
            {"name": "demo_key_down_up",
             "value": set(key_cfg.get("demo_key_down_up")),
             "down_fun": down_e, "up_fun": up_e},
            {"name": "demo_long_1s",
             "value": set(key_cfg.get("demo_long_1s")),
             "down_fun": lambda: lp.key_down("demo_long_1s", 1.0, long_r),
             "up_fun": lambda: lp.key_up("demo_long_1s")},
            {"name": "demo_long_2s",
             "value": set(key_cfg.get("demo_long_2s")),
             "down_fun": lambda: lp.key_down("demo_long_2s", 2.0, long_t),
             "up_fun": lambda: lp.key_up("demo_long_2s")},
            {"name": "demo_long_or_short",
             "value": set(key_cfg.get("demo_long_or_short")),
             "down_fun": lambda: lp.key_down("demo_long_or_short", 1.0, long_y),
             "up_fun": lambda: lp.key_up("demo_long_or_short", short_y)},
            {"name": "demo_key_combo",
             "value": set(key_cfg.get("demo_key_combo")),
             "down_fun": lambda: notify.show("组合键 ctrl_l + U 触发", hide_after=0.5)},
            {"name": "sync_key",
             "value": set(key_cfg.get("sync_key")),
             "down_fun": lambda: notify.show("同步热键触发", hide_after=0.5)},
        ]

        self._kb = Keyboard(
            hotkey_list,
            run_fun_callback=run_in_main,
            save_fun=_save_fun,
            is_read_mouse=True,
        )

    # ── 构建整个 UI ──
    # MainLayout: 左右双栏骨架，自带左/右独立滚动区
    # LeftList:   侧栏导航管理器，管理左侧按钮 + 右侧 QStackedWidget
    # add_page:   一级页面，返回 page layout 往里面加控件
    # add_group:  二级折叠分组，group.add_page() 注册子页面
    def add_ui(self):
        layout = MainLayout(self)
        self.left = LeftList(
            callback_after_select_page=layout.scroll_to_top)

        self._build_home()

        cfg = self.left.add_group("config", "配置项", icon="⚙️")
        self._build_widgets(cfg.add_page("widgets", "绑定配置控件", icon="⚙️"))
        self._build_callback(cfg.add_page("callback", "纯回调模式", icon="🔨"))
        self._build_sync(cfg.add_page("sync", "配置同步", icon="🔗"))
        self._build_key(cfg.add_page("key", "热键绑定", icon="⌨"))

        win_grp = self.left.add_group("windows", "窗口类型展示", icon="🔲")
        self._build_main_wins(win_grp.add_page("main_wins", "主窗口类型", icon="🏠"))
        self._build_custom_dlg(win_grp.add_page("custom_dlg", "自定义对话框", icon="💬"))
        self._build_preset_dlg(win_grp.add_page("preset_dlg", "预置对话框", icon="💬"))
        self._build_click_through(win_grp.add_page("click_through", "穿透窗口交互", icon="🖱"))
        self._build_overlay(win_grp.add_page("overlay", "悬浮窗绘制", icon="✏️"))

        comp_grp = self.left.add_group("components", "组件", icon="🧩")
        self._build_click(comp_grp.add_page("click", "交互组件", icon="🖱"))
        self._build_form(comp_grp.add_page("form", "表单组件", icon="📝"))
        self._build_notify_center(comp_grp.add_page("notify", "通知中心", icon="🔔"))
        self._build_log(comp_grp.add_page("log", "日志管道", icon="📋"))
        self._build_jump(comp_grp.add_page("jump", "跳转演示", icon="🔗"))
        self._build_theme(self.left.add_page("theme", "主题设置", icon="✨"))
        self._build_about(self.left.add_page("about", "关于"))

        self.left.add_stretch_before_left()
        self.left.switch_to("home")

        layout.left_layout.addLayout(self.left.left_layout)
        layout.right_layout.addWidget(self.left.stack)

    # ── 首页 ──

    def _build_home(self):
        page = self.left.add_page("home", "首页", icon="🏠")
        title = QLabel("🎀 xiaoe_ui")
        title.setProperty("class", "app_title")
        title.setAlignment(Qt.AlignCenter)
        page.addWidget(title)
        sub = QLabel("基于 PySide6 的快速桌面应用 UI 框架")
        sub.setProperty("class", "section_title")
        sub.setAlignment(Qt.AlignCenter)
        page.addWidget(sub)
        make_line(page)
        page.addWidget(make_tip(
            "• 无边框窗口 + 背景图管理  (core/main_win.py, core/win_manager.py)\n"
            "• 侧栏导航 一级/二级分组  (nav/left_list.py)\n"
            "• 配置控件双绑 + 互刷新  (config/bridge.py, widgets/item.py)\n"
            "• 带状态边框的表单元素  (widgets/status_widgets.py)\n"
            "• TopBoxWindow 透明悬浮窗  (core/top_win.py)\n"
            "• NotifyOverlay 通知横幅  (core/notify.py)\n"
            "• MsgBox 消息弹窗 + Dialog  (utils/msg_box.py, core/dialog.py)"))
        page.addStretch(1)

    # ── 配置控件: 传入 config + config_name 即自动双绑，不传则纯 callback ──

    def _build_widgets(self, page):
        make_tip(
            "L3 配置项 = 标题 + L2 Entry + 重置\n"
            "  CheckItem  = 标题 + CheckEntry\n"
            "  ComboItem  = 标题 + ComboEntry\n"
            "  SliderItem = 标题 + SliderEntry + SpinEntry + 重置\n"
            "  ColorItem  = 标题 + ColorEntry + 重置\n"
            "  GradientItem = 标题 + GradientBar + 重置\n"
            "支持 config 双绑和纯 callback 两种模式。\n"
            "路径: xiaoe_ui/widgets/item.py + entry.py",
            parent_layout=page)
        make_line(page, False)

        CheckItem("布尔配置", text="绑定 config，可带 callback 通知",
                  config=config, config_name="demo_bool",
                  callback=lambda v: notify.show(
                      f"布尔配置已{'开启' if v else '关闭'}"),
                  parent_layout=page)
        make_line(page, False)

        ComboItem("多项配置", text="下拉选择，绑定 config",
                  options=["选项A", "选项B", "选项C"],
                  config=config, config_name="demo_combo",
                  callback=lambda v: notify.show(
                      f"多项配置切换为: {config.get('demo_combo')}"),
                  parent_layout=page)
        make_line(page, False)

        SliderItem("滑块配置", text="int 类型，拖动滑块",
                   config=config, config_name="demo_slider",
                   config_range=(0, 100), step=5,
                   callback=lambda v: notify.show(
                       f"滑块配置 = {config.get('demo_slider')}"),
                   tag="jump_flash_demo",
                   parent_layout=page)
        SliderItem("浮点滑块", text="float 类型，0.0~1.0",
                   config=config, config_name="demo_float",
                   config_range=(0.0, 1.0), step=0.01,
                   callback=lambda v: notify.show(
                       f"浮点滑块 = {config.get('demo_float')}"),
                   parent_layout=page)
        make_line(page, False)

        ColorItem("颜色配置", config=config, config_name="demo_color",
                  text="点击选取颜色，绑定 config",
                  callback=lambda v: notify.show(
                      f"颜色配置 = {config.get('demo_color')}"),
                  parent_layout=page)
        ColorItem("RGBA 颜色", config=config, config_name="demo_color_rgba",
                  rgba=True, text="支持透明度 (ShowAlphaChannel)",
                  callback=lambda v: notify.show(f"RGBA 颜色 = {v}"),
                  parent_layout=page)
        make_line(page, False)

        page.addWidget(make_form_row("文本配置",
            TextEntry(config=config, config_name="demo_text",
                      placeholder="输入文本，绑定 config",
                      callback=lambda v: notify.show(f"文本配置 = {v}"))))
        make_line(page, False)

        GradientItem("渐变色", config=config, config_name="demo_gradient",
                     text="左键拖拽 / 点选改色 / 右键删除",
                     callback=lambda v: notify.show("渐变色已更新"),
                     parent_layout=page)
        make_line(page, False)

        make_tip(
            "BottomItem 是动作按钮而非值编辑器，不绑定配置值，仅触发 callback。\n"
            "支持 reset_callback / cancel_callback 实现状态切换。",
            parent_layout=page)
        BottomItem("按钮配置", text="点击按钮触发 callback",
                   btn_text="执行",
                   callback=lambda: notify.show("按钮配置已触发！"),
                   parent_layout=page)
        page.addStretch(1)

    # ── 无 config 模式: 不传 config + config_name, 仅通过 callback 接收值变化 ──
    # 适用场景: 临时状态、计算属性、不持久化的 UI 状态
    def _build_callback(self, page):
        make_tip(
            "不传 config + config_name，仅通过 callback 响应操作。\n"
            "所有配置项都支持此模式。路径: xiaoe_ui/widgets/item.py",
            parent_layout=page)
        make_line(page, False)

        make_tip("基本用法: 操作时 callback 自动接收当前值作为参数",
                 parent_layout=page)
        CheckItem("无配置复选框", text="点击触发回调",
                  callback=lambda v: notify.show(f"复选框状态: {v}"),
                  parent_layout=page)
        SliderItem("无配置滑块", text="拖动触发回调",
                   config_range=(0, 100), step=10,
                   callback=lambda v: notify.show(f"滑块当前值: {v}"),
                   parent_layout=page)
        ComboItem("无配置下拉框", text="选择触发回调",
                  options=["选项A", "选项B", "选项C"],
                  callback=lambda v: notify.show(f"选中了第 {v} 项"),
                  parent_layout=page)
        page.addWidget(make_form_row("无配置输入框",
            TextEntry(placeholder="输入触发回调", default="hello",
                      callback=lambda v: notify.show(f"输入内容: {v}"))))
        make_line(page, False)

        make_tip("进阶用法: 在 callback 中手动 get/set 其他 config 值",
                 parent_layout=page)
        CheckItem("回调中读配置", text="忽略回调参数，直接读 config",
                  callback=lambda _: notify.show(
                      f"从 config 读取 demo_combo = {config.get('demo_combo')}"),
                  parent_layout=page)
        BottomItem("通知测试", text="点击按钮，通知内容从 config 取值",
                   btn_text="显示",
                   callback=lambda: notify.show(
                       f"当前 demo_text = {config.get('demo_text')}"),
                   parent_layout=page)
        page.addStretch(1)

    # ── 配置同步: 只需给多个控件传相同的 config + config_name, 自动保持同步 ──
    def _build_sync(self, page):
        cfg = config
        make_tip(
            "双向绑定：多个控件传相同的 config + config_name，自动同步。\n"
            "· 操作任意控件 → 同 key 控件立刻跟变\n"
            "· 代码调用 config.set(key, val) → 同 key 控件也自动刷新\n"
            "无需手动写刷新逻辑，所有带 config/config_name 的控件均支持。",
            parent_layout=page)

        # ── CheckItem ──
        make_line(page, True)
        CheckItem("同步·复选框 A", text="同 key: sync_check",
                  config=cfg, config_name="sync_check", parent_layout=page)
        CheckItem("同步·复选框 B", text="A 变我跟变",
                  config=cfg, config_name="sync_check", parent_layout=page)

        # ── ComboItem ──
        make_line(page, True)
        ComboItem("同步·下拉 A", options=["选项A", "选项B", "选项C"],
                  config=cfg, config_name="sync_combo", parent_layout=page)
        ComboItem("同步·下拉 B", options=["选项A", "选项B", "选项C"],
                  config=cfg, config_name="sync_combo", parent_layout=page)

        # ── SliderItem ──
        make_line(page, True)
        SliderItem("同步·滑块 A", config=cfg, config_name="sync_value",
                   config_range=(0, 100), parent_layout=page)
        SliderItem("同步·滑块 B", config=cfg, config_name="sync_value",
                   config_range=(0, 100), parent_layout=page)

        # ── ColorItem ──
        make_line(page, True)
        ColorItem("同步·颜色 A", config=cfg, config_name="sync_color",
                  parent_layout=page)
        ColorItem("同步·颜色 B", config=cfg, config_name="sync_color",
                  parent_layout=page)

        # ── TextEntry ──
        make_line(page, True)
        page.addWidget(make_form_row("同步·文本 A", TextEntry(config=cfg, config_name="sync_text")))
        page.addWidget(make_form_row("同步·文本 B", TextEntry(config=cfg, config_name="sync_text")))

        # ── SpinEntry ──
        make_line(page, True)
        page.addWidget(make_form_row("同步·整数 A", SpinEntry(config=cfg, config_name="sync_int", config_range=(0, 100))))
        page.addWidget(make_form_row("同步·整数 B", SpinEntry(config=cfg, config_name="sync_int", config_range=(0, 100))))

        # ── 浮点 SpinEntry ──
        make_line(page, True)
        page.addWidget(make_form_row("同步·浮点 A", SpinEntry(config=cfg, config_name="sync_float", config_range=(0.0, 1.0), step=0.05)))
        page.addWidget(make_form_row("同步·浮点 B", SpinEntry(config=cfg, config_name="sync_float", config_range=(0.0, 1.0), step=0.05)))

        # ── MultiEntry ──
        make_line(page, True)
        page.addWidget(make_form_row("同步·多行 A", MultiEntry(config=cfg, config_name="sync_multi")))
        page.addWidget(make_form_row("同步·多行 B", MultiEntry(config=cfg, config_name="sync_multi")))

        # ── DatePicker ──
        make_line(page, True)
        page.addWidget(make_form_row("同步·日期 A", DatePicker(config=cfg, config_name="sync_date")))
        page.addWidget(make_form_row("同步·日期 B", DatePicker(config=cfg, config_name="sync_date")))

        # ── ImagePicker ──
        make_line(page, True)
        page.addWidget(make_form_row("同步·图片 A", ImagePicker(config=cfg, config_name="sync_image")))
        page.addWidget(make_form_row("同步·图片 B", ImagePicker(config=cfg, config_name="sync_image")))

        # ── KeyItem ──
        if _has_keyboard:
            make_line(page, True)
            KeyItem("同步·热键 A", config=key_cfg, config_name="sync_key",
                    keyboard=self._kb, parent_layout=page)
            KeyItem("同步·热键 B", config=key_cfg, config_name="sync_key",
                    keyboard=self._kb, parent_layout=page)

        # ── config.on() / config.off() ──
        make_line(page, True)
        make_tip(
            "config.on(key, callback): 按 key 注册回调，set/reset 时自动触发。\n"
            "config.off(key, callback): 取消注册。必须是同一个函数引用。\n"
            "路径: xiaoe_ui/config/bridge.py",
            parent_layout=page)
        page.addWidget(make_form_row("on 回调测试",
            SpinEntry(config=cfg, config_name="on_demo",
                      config_range=(0, 100),
                      callback=lambda v: notify.show(f"SpinEntry 回调: {v}"))))
        self._on_label = QLabel("config.on → 此处自动刷新")
        page.addWidget(self._on_label)
        cfg.on("on_demo", self._on_demo_handler)

        page.addStretch(1)

    def _on_demo_handler(self, v):
        self._on_label.setText(f"config.on('on_demo') → 收到值: {v}")

    # ── 穿透窗口演示 — ClickThroughMixin 全局钩子 + 命中测试 ──
    # FramelessWin + ClickThroughMixin 组合积木, 位置大小持久化到 config
    # BottomItem 按钮切换: callback=主动作, cancel_callback=取消动作, btn_cancel_text=取消态文字
    def _build_click_through(self, page):
        make_tip(
            "FramelessWin + ClickThroughMixin 组合积木演示。\n"
            "穿透模式下空白区域鼠标事件穿透到下层，仅已注册控件可被点击。\n"
            "依赖 mouse 库 (pip install mouse)，全局钩子捕获鼠标事件做命中测试。\n"
            "路径: xiaoe_ui/core/click_through.py",
            parent_layout=page)
        make_line(page, False)

        # 创建穿透窗口 — 默认隐藏, 位置大小从 ct_config 读取持久化
        self._ct_win = ClickThroughDemoWin(ct_config)
        geo = ct_config.get("ct_win_geo")
        if not geo:
            screen = QApplication.primaryScreen().availableGeometry()
            self._ct_win.resize(320, 200)
            self._ct_win.move(screen.right() - 440, screen.top() + 120)

        make_tip(
            "穿透窗口操作说明:\n"
            "  · 先点「显示」让窗口出现\n"
            "  · 按下按钮 → 状态标签显示 '按下'，释放触发通知\n"
            "  · 窗口空白区域点击 → 穿透到下层\n"
            "  · 支持左键 / 右键 / 中键，分别注册不同回调\n"
            "  · 点「调整」进入编辑模式，可拖拽移动、8向 resize\n"
            "  · 调整完点「保存」退出编辑模式，位置大小持久化到 config",
            parent_layout=page)

        BottomItem("显示穿透窗口",
                   text="点击显示/隐藏穿透演示窗口",
                   btn_text="显示",
                   btn_cancel_text="隐藏",
                   callback=lambda: (self._ct_win.show(), self._ct_win.start_mouse_hook()),
                   cancel_callback=lambda: (self._ct_win.stop_mouse_hook(), self._ct_win.hide()),
                   parent_layout=page)
        BottomItem("调整悬浮窗",
                   text="调整悬浮窗的大小、位置，调整完点保存",
                   btn_text="调整",
                   btn_cancel_text="保存",
                   callback=lambda: self._ct_win.enter_edit_mode(),
                   cancel_callback=lambda: self._ct_win.exit_edit_mode(),
                   parent_layout=page)
        page.addStretch(1)

    # ── TopBoxWindow 透明悬浮窗 + QPainter 自定义绘制 ──
    # default_color_cb 回调从 theme_cfg 读取颜色, 主题切换时自动跟变
    def _build_overlay(self, page):
        make_tip(
            "TopBoxWindow 透明置顶悬浮窗，QPainter 绘制矩形 / 对角线 / 自定义图形 / 文字。\n"
            "颜色、线宽、字号、隐藏延时均可通过 callback 覆盖。路径: xiaoe_ui/core/top_win.py",
            parent_layout=page)
        make_line(page, False)

        self._win_rect1 = TopBoxWindow(color_cb=lambda: (100, 255, 100, 200), line_width=3)
        self._win_rect2 = TopBoxWindow(color_cb=lambda: (255, 200, 50, 220), line_width=5)
        self._win_diag1 = TopBoxWindow(color_cb=lambda: (255, 80, 80, 200), line_width=2)
        self._win_diag2 = TopBoxWindow(color_cb=lambda: (255, 80, 80, 200), line_width=2)
        self._win_diag3 = TopBoxWindow(color_cb=lambda: (100, 200, 255, 200), line_width=2)
        self._win_cross = TopBoxWindow(
            color_cb=lambda: (100, 150, 255, 200), line_width=1,
            custom_draw=lambda p, r: (
                p.drawLine(r.center().x(), r.top(), r.center().x(), r.bottom()),
                p.drawLine(r.left(), r.center().y(), r.right(), r.center().y()),
                p.drawEllipse(r.center().x() - 30, r.center().y() - 30, 60, 60),
            ))
        self._win_heart = TopBoxWindow(custom_draw=_draw_heart)
        self._win_text = TopBoxWindow()
        self._win_box_text = TopBoxWindow()
        self._demo_wins = [
            self._win_rect1, self._win_rect2,
            self._win_diag1, self._win_diag2, self._win_diag3,
            self._win_cross, self._win_heart,
            self._win_text, self._win_box_text,
        ]

        BottomItem("绿色方框", text="400x300, 线宽3", btn_text="绘制",
                   callback=lambda: self._win_rect1.show_box(box=(200, 150, 600, 450)),
                   parent_layout=page)
        BottomItem("金色方框", text="300x250, 线宽5", btn_text="绘制",
                   callback=lambda: self._win_rect2.show_box(box=(650, 150, 950, 400)),
                   parent_layout=page)
        make_line(page, False)
        BottomItem("X 形双线", text="300x300, lr 带边框", btn_text="绘制",
                   callback=lambda: self._win_diag1.show_box(box=(150, 450, 450, 750), diagonal="lr"),
                   parent_layout=page)
        BottomItem("X 形·无边框", text="300x300, lr 纯线条", btn_text="绘制",
                   callback=lambda: self._win_diag2.show_box(box=(500, 450, 800, 750), diagonal="lr", show_box_line=False),
                   parent_layout=page)
        BottomItem("单斜线", text="250x250, 仅 l", btn_text="绘制",
                   callback=lambda: self._win_diag3.show_box(box=(850, 450, 1100, 700), diagonal="l"),
                   parent_layout=page)
        make_line(page, False)
        BottomItem("十字准星", text="200x200", btn_text="绘制",
                   callback=lambda: self._win_cross.show_box(box=(450, 200, 650, 400)),
                   parent_layout=page)
        BottomItem("爱心", text="600x350, 参数方程填充", btn_text="绘制",
                   callback=lambda: self._win_heart.show_box(box=(200, 300, 800, 650), show_box_line=False),
                   parent_layout=page)
        make_line(page, False)
        BottomItem("显示文字", text="屏幕居中, 3秒后隐藏", btn_text="绘制",
                   callback=lambda: self._win_text.show_text(
                       "Hello xiaoe_ui!", box=(500, 350, 700, 380), font_size=18, hide_after=3),
                   parent_layout=page)
        BottomItem("带框文字", text="带边框", btn_text="绘制",
                   callback=lambda: self._win_box_text.show_text(
                       "带框文字", box=(500, 300, 660, 340), font_size=18, show_box=True),
                   parent_layout=page)
        make_line(page, False)
        BottomItem("全部清除", text="关闭所有悬浮窗", btn_text="清除",
                   callback=self._clear_demo_wins,
                   parent_layout=page)
        page.addStretch(1)

    def _clear_demo_wins(self):
        for w in self._demo_wins:
            w.hide()

    # ── KeyItem 热键绑定: 需要 xiaoe_keyboard, 未安装时显示提示 ──
    # 热键保存到独立的 key_cfg 配置实例, 与业务/主题配置分离
    def _build_key(self, page):
        make_tip(
            "KeyItem 绑定热键（按下/松开/长按/组合键），通过 xiaoe_keyboard 捕获。\n"
            "点击「设置」进入捕获，右键可解绑或重置。路径: xiaoe_ui/widgets/item.py\n"
            "依赖: xiaoe_keyboard (可选)",
            parent_layout=page)
        make_line(page, False)

        if not _has_keyboard:
            page.addWidget(make_tip("热键绑定功能需要 xiaoe_keyboard 库\n请执行: pip install xiaoe_keyboard"))
        else:
            KeyItem("按键按下", config=key_cfg, config_name="demo_key_down",
                    text="Q: 仅响应按下", keyboard=self._kb, parent_layout=page)
            KeyItem("按键松开", config=key_cfg, config_name="demo_key_up",
                    text="W: 仅响应松开", keyboard=self._kb, parent_layout=page)
            KeyItem("按下+松开", config=key_cfg, config_name="demo_key_down_up",
                    text="E: 按下和松开都响应", keyboard=self._kb, parent_layout=page)
            KeyItem("长按1秒", config=key_cfg, config_name="demo_long_1s",
                    text="R: 按住1秒触发", keyboard=self._kb, parent_layout=page)
            KeyItem("长按2秒", config=key_cfg, config_name="demo_long_2s",
                    text="T: 按住2秒触发", keyboard=self._kb, parent_layout=page)
            KeyItem("长短按", config=key_cfg, config_name="demo_long_or_short",
                    text="Y: 短按松手 / 长按1秒分别触发", keyboard=self._kb, parent_layout=page)
            KeyItem("组合键", config=key_cfg, config_name="demo_key_combo",
                    text="U: 可设置组合键", keyboard=self._kb, parent_layout=page)
        page.addStretch(1)

    # ── 表单组件: L2 Entry + make_form_row → 完整表单行 ──
    # 使用独立的 form_cfg 配置实例，所有控件自动双向绑定
    def _build_form(self, page):
        make_tip(
            "L2 Entry (config 绑定, 无标题) + make_form_row → 完整表单行\n"
            "TextEntry / SpinEntry / MultiEntry / DatePicker / ImagePicker\n"
            "路径: xiaoe_ui/widgets/entry.py + xiaoe_ui/widgets/form_layout.py",
            parent_layout=page)
        make_line(page, False)

        page.addWidget(make_form_row("姓名", TextEntry(config=form_cfg, config_name="f_name", placeholder="请输入姓名")))
        page.addWidget(make_form_row("年龄", SpinEntry(config=form_cfg, config_name="f_age", config_range=(0, 150), width=100)))
        page.addWidget(make_form_row("身高(m)", SpinEntry(config=form_cfg, config_name="f_height", config_range=(0.0, 3.0), step=0.01, width=100)))
        page.addWidget(make_form_row("生日", DatePicker(config=form_cfg, config_name="f_birthday")))
        page.addWidget(make_form_row("性别", ComboEntry(config=form_cfg, config_name="f_gender", options=["未选择", "男", "女"])))
        page.addWidget(make_form_row("简介", MultiEntry(config=form_cfg, config_name="f_intro", height=60)))
        page.addWidget(make_form_row("头像", ImagePicker(config=form_cfg, config_name="f_avatar", size=180)))
        page.addStretch(1)

    # ── 对话框页 ──

    # ── 主窗口类型页 ──

    def _build_main_wins(self, page):
        make_tip(
            "MainWin 是框架的主窗口基类，继承后覆盖 add_ui() 构建界面。\n"
            "WinManager 子类自动注册，支持一键置顶/关闭/刷新样式。\n"
            "路径: xiaoe_ui/core/",
            parent_layout=page)
        make_line(page, False)

        make_tip("基本用法: MainWin + MainLayout(左右双栏) + LeftList(侧栏导航)",
                 parent_layout=page)
        BottomItem("简单主窗口", text="最简 MainWin，无侧栏",
                   btn_text="打开", callback=self._show_simple_mainwin,
                   parent_layout=page)
        BottomItem("带侧栏窗口", text="MainWin + LeftList + MainLayout",
                   btn_text="打开", callback=self._show_sidebar_win,
                   parent_layout=page)
        BottomItem("不抢焦点窗口", text="上面窗口 + WindowDoesNotAcceptFocus + self.on_top(True)",
                   btn_text="打开", callback=self._show_not_accept_focus_sidebar_win,
                   parent_layout=page)

        make_line(page, False)
        make_tip("单例模式: 混入 SingletonMixin 限制同 key 只允许一个实例",
                 parent_layout=page)
        BottomItem("单例窗口 (only_one)", text="同一 key 只允许一个实例，重复打开激活已有",
                   btn_text="打开", callback=self._show_singleton_win,
                   parent_layout=page)
        BottomItem("自定义 key 单例", text="不同 key 可并存多个，同 key 互斥",
                   btn_text="打开", callback=self._show_custom_key_win,
                   parent_layout=page)
        make_line(page, False)
        make_tip(
            "全局置顶仅对 WinManager 子类 (MainWin/Dialog/FramelessWin) 生效。\n"
            "TopBoxWindow / NotifyOverlay 不继承 WinManager，独立管理。",
            parent_layout=page)
        BottomItem("全局置顶", text="将所有由WinManager管理的窗口置顶",
                   btn_text="置顶窗口", callback=lambda :self.on_top_all_win(True),
                   cancel_callback=lambda :self.on_top_all_win(False),
                   btn_cancel_text="取消置顶",
                   parent_layout=page)
        page.addStretch(1)

    # ── 简单 MainWin: 注入 add_ui → setup_ui() → apply_all() ──
    def _show_simple_mainwin(self):
        w = MainWin(
            win_title="简单窗口",
            scroll=False,
        )
        lbl = QLabel("这是一个最简单的 MainWin 窗口")
        lbl.setAlignment(Qt.AlignCenter)
        w.add_ui = lambda: w.content_layout.addWidget(lbl)  # 注入 add_ui 避免 NotImplementedError
        w.setup_ui()
        w.resize(400, 300)
        w.apply_all()  # 必须手动调，is_main_win=False 不会自动应用
        # w.show()

    # ── MainWin + MainLayout + LeftList 骨架 ──
    def _show_sidebar_win(self):
        w = MainWin(
            win_title="带侧栏窗口",
            scroll=False,
        )
        def _add():
            layout = MainLayout(w)
            left = LeftList()
            pg1_label = QLabel("这是一级页面一的内容")
            pg1_label.setAlignment(Qt.AlignCenter)
            left.add_page("pg1", "页面一", icon="📄").addWidget(pg1_label)
            # 二级分组演示
            grp = left.add_group("sub", "二级分组", icon="📁")
            lbl_a = QLabel("这是子页面 A 的内容")
            lbl_a.setAlignment(Qt.AlignCenter)
            grp.add_page("sub1", "子页面A", icon="📎").addWidget(lbl_a)
            lbl_b = QLabel("这是子页面 B 的内容")
            lbl_b.setAlignment(Qt.AlignCenter)
            grp.add_page("sub2", "子页面B", icon="📎").addWidget(lbl_b)
            left.add_stretch_before_left()
            left.switch_to("pg1")
            layout.left_layout.addLayout(left.left_layout)
            layout.right_layout.addWidget(left.stack)
        w.add_ui = _add
        w.setup_ui()
        w.resize(500, 350)
        w.apply_all()
        w.show()
        # ── MainWin + MainLayout + LeftList 骨架 ──

    def _show_not_accept_focus_sidebar_win(self):
        w = MainWin(
            win_title="不抢占焦点的带侧栏置顶窗口",
            scroll=False,
            on_top_with_global=False, # 不跟随全局置顶管理
            custom_windows_flags=[Qt.WindowType.WindowDoesNotAcceptFocus]
        )

        def _add():
            layout = MainLayout(w)
            left = LeftList()
            pg1_label = QLabel("这是一级页面一的内容")
            pg1_label.setAlignment(Qt.AlignCenter)
            left.add_page("pg1", "页面一", icon="📄").addWidget(pg1_label)
            # 二级分组演示
            grp = left.add_group("sub", "二级分组", icon="📁")
            lbl_a = QLabel("这是子页面 A 的内容")
            lbl_a.setAlignment(Qt.AlignCenter)
            grp.add_page("sub1", "子页面A", icon="📎").addWidget(lbl_a)
            lbl_b = QLabel("这是子页面 B 的内容")
            lbl_b.setAlignment(Qt.AlignCenter)
            grp.add_page("sub2", "子页面B", icon="📎").addWidget(lbl_b)
            left.add_stretch_before_left()
            left.switch_to("pg1")
            layout.left_layout.addLayout(left.left_layout)
            layout.right_layout.addWidget(left.stack)

        w.add_ui = _add
        w.setup_ui()
        w.resize(500, 350)
        w.apply_all()
        w.on_top(True)

    # ── 单例窗口: MainWin + SingletonMixin, only_one=True ──
    # 重复打开同一窗口 → activateWindow() → 不新建
    def _show_singleton_win(self):
        from xiaoe_ui.core.singleton_mixin import SingletonMixin

        class SingletonWin(MainWin, SingletonMixin):
            def __init__(self):
                MainWin.__init__(self, win_title="单例窗口", scroll=False, )
                self.setup_ui()
                self.resize(400, 300)
                self.apply_all()
                SingletonMixin._singleton_init(self, "demo_singleton_win", only_one=True)

            def add_ui(self):
                lbl = QLabel("单例窗口 — 同一 key 只有一个")
                lbl.setAlignment(Qt.AlignCenter)
                self.content_layout.addWidget(lbl)

            def closeEvent(self, e):
                SingletonMixin._singleton_close(self)
                super().closeEvent(e)

        existing = SingletonWin.get_singleton("demo_singleton_win")
        if existing:
            existing.activateWindow()
            notify.show("单例窗口已存在，激活已有")
            return
        w = SingletonWin()
        w.show()
        notify.show("创建单例窗口")

    # ── 自定义 key 单例: 用户输入 key, 不同 key = 不同窗口, 同 key = 互斥 ──
    # 适用场景: 文件编辑器 (key=文件路径, 同一文件不重复打开)
    def _show_custom_key_win(self):
        from xiaoe_ui.core.singleton_mixin import SingletonMixin
        result = input_dialog("创建窗口", "输入窗口名称（作为单例 key）：", "editor_A")
        if not result:
            return
        key = f"demo_custom_{result}"

        existing = SingletonMixin.get_singleton(key)
        if existing:
            existing.activateWindow()
            notify.show(f"'{result}' 窗口已存在，激活已有")
            return

        class CustomKeyWin(MainWin, SingletonMixin):
            def __init__(self, k, name):
                self.k = k
                MainWin.__init__(self, win_title=f"窗口: {name}", scroll=False, )
                self.setup_ui()
                self.resize(400, 300)
                self.apply_all()
                SingletonMixin._singleton_init(self, k, only_one=True)

            def add_ui(self):
                lbl = QLabel(f"单例 key: {self.k}")
                lbl.setAlignment(Qt.AlignCenter)
                self.content_layout.addWidget(lbl)

            def closeEvent(self, e):
                SingletonMixin._singleton_close(self)
                super().closeEvent(e)

        w = CustomKeyWin(key, result)
        w.show()
        notify.show(f"创建窗口 '{result}'")

    # ── 自定义对话框 ──

    # ── 自定义对话框: Dialog 是空白容器, 所有控件由你添加 ──
    # 阻塞 (exec) / 非阻塞 (show) / 单例 (SingletonMixin)
    def _build_custom_dlg(self, page):
        make_tip(
            "Dialog 是高度自定义的空白容器，不内置任何按钮或布局\n"
            "阻塞 / 非阻塞 / 单例 各种用法",
            parent_layout=page)
        make_line(page, False)

        BottomItem("阻塞对话框", text="Dialog(exec())，阻塞主窗口等待关闭",
                   btn_text="打开", callback=self._show_blocking_dlg,
                   parent_layout=page)
        BottomItem("可调对话框", text="可调整大小的对话框",
                   btn_text="打开", callback=self._show_blocking_resize_dlg,
                   parent_layout=page)
        make_line(page, False)
        BottomItem("非阻塞多例对话框", text="Dialog(modal=False).show()，可打开多个",
                   btn_text="打开", callback=self._show_nonblocking_dlg,
                   parent_layout=page)
        BottomItem("单例对话框", text="only_one=True，同一 key 只一个实例",
                   btn_text="打开", callback=self._show_singleton_dlg,
                   parent_layout=page)
        BottomItem("自定义 key 单例", text="不同 key 可并存，同 key 互斥",
                   btn_text="打开", callback=self._show_custom_key_dlg,
                   parent_layout=page)
        page.addStretch(1)

    # ── 预置对话框: 框架提供的 MsgBox ask/info/warn/error/input_dialog ──
    # 阻塞式, 点按钮才关闭, 适合快速确认/提示场景
    def _build_preset_dlg(self, page):
        make_tip(
            "框架预置的阻塞式消息弹窗 MsgBox (QMessageBox + WinManager)",
            parent_layout=page)
        make_line(page, False)

        BottomItem("info 信息", text="信息提示弹窗",
                   btn_text="打开",
                   callback=lambda: info("提示", "这是一条 info 信息弹窗"),
                   parent_layout=page)
        BottomItem("warn 警告", text="警告提示弹窗",
                   btn_text="打开",
                   callback=lambda: warn("警告", "这是一条 warn 警告弹窗"),
                   parent_layout=page)
        BottomItem("error 错误", text="错误提示弹窗",
                   btn_text="打开",
                   callback=lambda: error("错误", "这是一条 error 错误弹窗"),
                   parent_layout=page)
        make_line(page, False)
        BottomItem("ask 双按钮", text='ask("标题","内容")，是/否',
                   btn_text="打开",
                   callback=self._show_ask_2btn,
                   parent_layout=page)
        BottomItem("ask 三按钮", text='ask(..., with_cancel=True)，是/否/取消',
                   btn_text="打开",
                   callback=self._show_ask_3btn,
                   parent_layout=page)
        BottomItem("ask 自定义文字", text='yes_text / no_text 自定义按钮文字',
                   btn_text="打开",
                   callback=self._show_ask_custom,
                   parent_layout=page)
        make_line(page, False)
        BottomItem("input 输入", text="带输入框的弹窗",
                   btn_text="打开", callback=self._show_input_dialog,
                   parent_layout=page)
        page.addStretch(1)

    # ── 自定义对话框回调: 展示 Dialog 高度自定义能力 ──

    # 阻塞式: dlg.exec() 阻塞主窗口, 关闭后才返回
    def _show_blocking_dlg(self):
        dlg = Dialog(parent=self, win_title="阻塞对话框", width=320, height=180)
        dlg.root_layout.setSpacing(8)
        dlg.root_layout.addWidget(QLabel("这是阻塞式 Dialog"))
        dlg.root_layout.addWidget(QLabel("调用 dlg.exec() 阻塞主窗口"))
        btn = QPushButton("关闭")
        btn.clicked.connect(dlg.accept)
        dlg.root_layout.addWidget(btn)
        dlg.exec()
        notify.show("阻塞对话框已关闭")

    def _show_blocking_resize_dlg(self):
        dlg = Dialog(parent=self, win_title="可调大小阻塞对话框", width=320, height=180, set_fixed_size=False)
        dlg.root_layout.setSpacing(8)
        dlg.root_layout.addWidget(QLabel("这是可调大小的阻塞式 Dialog，其他对话框也可以解锁大小调整"))
        dlg.root_layout.addWidget(QLabel("调用 dlg.exec() 阻塞主窗口"))
        btn = QPushButton("关闭")
        btn.clicked.connect(dlg.accept)
        dlg.root_layout.addWidget(btn)
        dlg.exec()
        notify.show("阻塞对话框已关闭")

    # 非阻塞多例: modal=False, .show() 不阻塞, 可同时开多个
    def _show_nonblocking_dlg(self):
        dlg = Dialog(parent=self, win_title="非阻塞对话框", width=320, height=180, modal=False)
        dlg.root_layout.setSpacing(8)
        dlg.root_layout.addWidget(QLabel("非阻塞对话框，主窗口可继续操作"))
        dlg.root_layout.addWidget(QLabel("可同时打开多个实例"))
        from xiaoe_ui.widgets.use_mixin_fast_widget import QCheckBoxHandCursor
        dlg.root_layout.addWidget(QCheckBoxHandCursor("不再提示"))
        dlg.show()
        notify.show("非阻塞对话框已打开 (可开多个)")

    # 单例对话框: Dialog + SingletonMixin + only_one, 重复打开激活已有
    def _show_singleton_dlg(self):
        from xiaoe_ui.core.singleton_mixin import SingletonMixin

        class SingletonDlg(Dialog, SingletonMixin):
            def __init__(self, parent):
                Dialog.__init__(self, parent=parent, win_title="单例对话框",
                                width=320, height=180, modal=False)
                SingletonMixin._singleton_init(self, "demo_singleton_dlg", only_one=True)
                self.root_layout.setSpacing(8)
                self.root_layout.addWidget(QLabel("单例对话框 — 同时只有一个实例"))
                self.root_layout.addWidget(QLabel("重复打开会激活已有窗口"))
                self.root_layout.addStretch(1)
                row = QHBoxLayout()
                row.addStretch(1)
                btn = QPushButton("知道了")
                btn.clicked.connect(self.close)
                row.addWidget(btn)
                self.root_layout.addLayout(row)

            def closeEvent(self, e):
                SingletonMixin._singleton_close(self)
                super().closeEvent(e)

        existing = SingletonDlg.get_singleton("demo_singleton_dlg")
        if existing:
            existing.activateWindow()
            notify.show("单例对话框已存在，激活已有")
            return
        SingletonDlg(self).show()
        notify.show("创建单例对话框")

    # 自定义 key 单例对话框: 不同 key 并存, 同 key 互斥 (同窗口单例模式)
    def _show_custom_key_dlg(self):
        from xiaoe_ui.core.singleton_mixin import SingletonMixin
        result = input_dialog("创建对话框", "输入单例 key：", "dlg_A")
        if not result:
            return
        key = f"demo_dlg_{result}"
        existing = SingletonMixin.get_singleton(key)
        if existing:
            existing.activateWindow()
            notify.show(f"'{result}' 已存在，激活已有")
            return

        class CustomKeyDlg(Dialog, SingletonMixin):
            def __init__(self, k, name, parent):
                Dialog.__init__(self, parent=parent, win_title=f"对话框: {name}",
                                width=300, height=140, modal=False)
                SingletonMixin._singleton_init(self, k, only_one=True)
                self.root_layout.addWidget(QLabel(f"单例 key: {k}"))
                self.root_layout.addWidget(QLabel(f"其他 key 的对话框不受影响"))

            def closeEvent(self, e):
                SingletonMixin._singleton_close(self)
                super().closeEvent(e)

        CustomKeyDlg(key, result, self).show()
        notify.show(f"创建对话框 '{result}'")

    # ── 预置对话框回调 ──

    def _show_ask_2btn(self):
        result = ask("确认", "确定执行此操作？")
        notify.show("已确认" if result else "已取消")

    def _show_ask_3btn(self):
        result = ask("保存", "文件已修改，是否保存？", with_cancel=True)
        if result is True:
            notify.show("已保存")
        elif result is False:
            notify.show("不保存")
        else:
            notify.show("已取消")

    def _show_ask_custom(self):
        result = ask("覆盖", "文件已存在，是否覆盖？",
                     yes_text="覆盖", no_text="保留")
        notify.show("已覆盖" if result else "已保留")

    def _show_input_dialog(self):
        result = input_dialog("输入", "请输入文本：", "默认内容")
        if result is not None:
            notify.show(f"输入内容: {result}")

    # ── 交互组件页 ──

    def _build_click(self, page):
        make_tip("ClickFrame / BigButton — 路径: xiaoe_ui/widgets/click_frame.py\n"
                 "InstantTipLabel / InstantTipButton — 路径: xiaoe_ui/widgets/instant_tip.py",
                 parent_layout=page)

        # ── ClickFrame 基础: default_line(默认线) + hand_cursor(手型光标) ──
        make_line(page, False)
        make_tip("ClickFrame — 基础样式", parent_layout=page)
        row1 = QHBoxLayout()
        f1 = ClickFrame(default_line=True)
        f1.setFixedSize(80, 50)
        f1.on_left_click(lambda: notify.show("默认带线"))
        register_tag("click_demo", f1)  # 供跳转演示页闪烁
        l1 = QLabel("带线")
        l1.setAlignment(Qt.AlignCenter)
        fl1 = QVBoxLayout(f1)
        fl1.addWidget(l1)
        row1.addWidget(f1)

        f2 = ClickFrame(default_line=False)
        f2.setFixedSize(80, 50)
        f2.on_left_click(lambda: notify.show("默认不带线"))
        l2 = QLabel("不带线")
        l2.setAlignment(Qt.AlignCenter)
        fl2 = QVBoxLayout(f2)
        fl2.addWidget(l2)
        row1.addWidget(f2)
        row1.addStretch(1)
        page.addLayout(row1)
        make_line(page, False)

        # ── ClickFrame hand_cursor ──
        make_tip("hand_cursor=True  /  hand_cursor=False", parent_layout=page)
        row2 = QHBoxLayout()
        f3 = ClickFrame(default_line=True, hand_cursor=True)
        f3.setFixedSize(80, 50)
        f3.on_left_click(lambda: notify.show("手型光标"))
        l3 = QLabel("手型")
        l3.setAlignment(Qt.AlignCenter)
        fl3 = QVBoxLayout(f3)
        fl3.addWidget(l3)
        row2.addWidget(f3)

        f4 = ClickFrame(default_line=True, hand_cursor=False)
        f4.setFixedSize(80, 50)
        f4.on_left_click(lambda: notify.show("箭头光标"))
        l4 = QLabel("箭头")
        l4.setAlignment(Qt.AlignCenter)
        fl4 = QVBoxLayout(f4)
        fl4.addWidget(l4)
        row2.addWidget(f4)
        row2.addStretch(1)
        page.addLayout(row2)
        make_line(page, False)

        # ── ClickFrame light-line: hover出线 / default-hover-line常驻线 / disable禁止交互 ──
        make_tip("ClickFrame — light-line 细线样式", parent_layout=page)
        row3 = QHBoxLayout()

        f5 = ClickFrame(custom_class="light-line")
        f5.setFixedSize(65, 50)
        f5.on_left_click(lambda: notify.show("light-line"))
        l5 = QLabel("hover\n出线")
        l5.setAlignment(Qt.AlignCenter)
        fl5 = QVBoxLayout(f5)
        fl5.addWidget(l5)
        row3.addWidget(f5)

        f6 = ClickFrame(custom_class="light-line default-hover-line")
        f6.setFixedSize(65, 50)
        f6.on_left_click(lambda: notify.show("light-line+line"))
        l6 = QLabel("带线")
        l6.setAlignment(Qt.AlignCenter)
        fl6 = QVBoxLayout(f6)
        fl6.addWidget(l6)
        row3.addWidget(f6)

        f7 = ClickFrame(custom_class="light-line disable", hand_cursor=False)
        f7.setFixedSize(80, 50)
        l7 = QLabel("不可交互")
        l7.setAlignment(Qt.AlignCenter)
        fl7 = QVBoxLayout(f7)
        fl7.addWidget(l7)
        row3.addWidget(f7)

        f8 = ClickFrame(custom_class="light-line default-hover-line disable", hand_cursor=False)
        f8.setFixedSize(80, 50)
        l8 = QLabel("带线\n不可交互")
        l8.setAlignment(Qt.AlignCenter)
        fl8 = QVBoxLayout(f8)
        fl8.addWidget(l8)
        row3.addWidget(f8)

        row3.addStretch(1)
        page.addLayout(row3)
        make_line(page, False)

        # ── BigButton ──
        make_tip("BigButton — 大型虚拟按钮", parent_layout=page)
        btn1 = BigButton("📝 打开编辑器", default_line=True,
                         click_cb=lambda: notify.show("BigButton 已点击"))
        page.addWidget(btn1)

        btn2 = BigButton("🔒 不可交互", custom_class="light-line disable", hand_cursor=False)
        page.addWidget(btn2)

        make_line(page, False)

        # ── InstantTip ──
        make_tip(
            "InstantTip — 即时 Tooltip，鼠标悬停立刻显示，无 Qt 默认延迟。\n"
            "InstantTipLabel: 带 tooltip 的 QLabel\n"
            "InstantTipButton: 带 tooltip 的 QPushButton",
            parent_layout=page)
        row4 = QHBoxLayout()
        tl = InstantTipLabel("悬停看提示")
        tl.setToolTip("我是 InstantTipLabel 的提示文字")
        tl.setProperty("class", "section_title")
        row4.addWidget(tl)
        row4.addStretch(1)
        tb = InstantTipButton("按钮悬停")
        tb.setToolTip("我是 InstantTipButton 的提示文字")
        row4.addWidget(tb)
        page.addLayout(row4)

        page.addStretch(1)

    # ── 通知中心 ──

    def _build_notify_center(self, page):
        SliderItem("通知高度", text="调整通知横幅的垂直位置 (屏幕高度占比)",
                   config=config, config_name="tz_y",
                   config_range=(0.0, 1.0), step=0.01,
                   callback=lambda v: notify.show(f"当前高度: {v:.2f}", hide_after=1.0),
                   parent_layout=page)
        make_line(page)

        make_tip("单行文本 — 不同消失时间", parent_layout=page)
        BottomItem("默认时长 (3秒)", text="点击显示单行通知，3秒后自动消失",
                   btn_text="显示",
                   callback=lambda: notify.show("这是一条默认时长的通知"),
                   parent_layout=page)
        BottomItem("快速消失 (0.5秒)", text="0.5秒后自动消失",
                   btn_text="显示",
                   callback=lambda: notify.show("0.5秒快速消失", hide_after=0.5),
                   parent_layout=page)
        BottomItem("长时停留 (8秒)", text="8秒后自动消失",
                   btn_text="显示",
                   callback=lambda: notify.show("这条通知停留 8 秒", hide_after=8),
                   parent_layout=page)
        make_line(page)

        make_tip("多行文本", parent_layout=page)
        BottomItem("多行通知", text="支持 \\n 换行显示，依然正常居中",
                   btn_text="显示",
                   callback=lambda: notify.show("第一行\n第二行\n第三行lllllllllllllllllllllllll"),
                   parent_layout=page)

        page.addStretch(1)

    # ── 日志管道 ──

    def _build_log(self, page):
        make_tip(
            "Msg — 线程安全日志管道。\n"
            "跨线程自动 run_in_main，任意线程发消息，Qt 主线程安全显示。\n"
            "支持 info / ok / warn / err 四种级别。\n"
            "路径: xiaoe_ui/utils/msg.py",
            parent_layout=page)
        make_line(page, False)

        log_area = QTextEdit()
        log_area.setReadOnly(True)
        log_area.setProperty("class", "log-area")
        log_area.setFixedHeight(150)
        msg.new_msg.connect(log_area.append)
        page.addWidget(log_area)

        btn_row = QHBoxLayout()
        for kind, fn in [("Info", lambda: msg.info("info 日志")),
                         ("OK", lambda: msg.ok("操作成功")),
                         ("Warn", lambda: msg.warn("警告信息")),
                         ("Error", lambda: msg.err("错误信息"))]:
            btn = QPushButton(kind)
            btn.setProperty("class", "small")
            btn.clicked.connect(fn)
            btn_row.addWidget(btn)
        btn_row.addStretch(1)
        page.addLayout(btn_row)

        page.addStretch(1)

    # ── 跳转演示 ──

    def _build_jump(self, page):
        make_tip(
            "LeftList.switch_to(key) 跳转到指定页面，二级页面自动展开分组。\n"
            "flash_config_widget(tag) 闪烁指定 tag 的配置项。\n"
            "路径: nav/left_list.py + widgets/item.py",
            parent_layout=page)
        make_line(page)

        # 1. 仅跳转
        make_tip("仅跳转", parent_layout=page)
        BottomItem("跳转到一级页面", text="switch_to('home') → 首页",
                   btn_text="跳转",
                   callback=lambda: self.left.switch_to("home"),
                   parent_layout=page)
        BottomItem("跳转到二级页面", text="switch_to('custom_dlg') → 自动展开「窗口展示」分组",
                   btn_text="跳转",
                   callback=lambda: self.left.switch_to("custom_dlg"),
                   parent_layout=page)
        make_line(page)

        # 2. 跳转 + 闪烁
        make_tip("跳转 + 闪烁", parent_layout=page)
        BottomItem("跳转并高亮滑块", text="switch_to('widgets') → flash_config_widget('jump_flash_demo')",
                   btn_text="跳转并闪烁",
                   callback=lambda: (
                       self.left.switch_to("widgets"),
                       flash_config_widget("jump_flash_demo"),
                   ),
                   parent_layout=page)
        make_line(page)

        # 3. 仅闪烁 (当前页)
        make_tip("仅闪烁 (当前页)", parent_layout=page)
        self._local_flash_item = BottomItem("闪烁本页按钮", text="tag='jump_local'，不跳转只闪烁",
                   btn_text="闪烁",
                   callback=lambda: flash_config_widget("jump_local"),
                   tag="jump_local",
                   parent_layout=page)
        make_line(page)
        BottomItem("闪烁手动注册的 ClickFrame", text="register_tag('click_demo', f1) → flash_config_widget",
                   btn_text="跳转并闪烁",
                   callback=lambda: (
                       self.left.switch_to("click"),
                       flash_config_widget("click_demo"),
                   ),
                   parent_layout=page)

        page.addStretch(1)

    # ── 主题页 ──

    def _build_theme(self, page):
        ThemePage(page, engine=self._engine, config=self._theme_cfg,
                  on_style_changed=self.apply_all, show_description=True)
        page.addStretch(1)

    # ── 关于页: Msg 日志管道 + MsgBox 消息弹窗 + WinManager 注入说明 ──
    # Msg.new_msg 信号连接 QTextEdit, 所有 notify/MsgBox 消息汇集显示
    def _build_about(self, page):
        title = QLabel("关于 xiaoe_ui")
        title.setProperty("class", "section_title")
        title.setAlignment(Qt.AlignCenter)
        page.addWidget(title)
        make_line(page)

        info = QLabel("xiaoe_ui v0.1.0 — 基于 PySide6 的快速桌面应用 UI 框架\n"
                      "融合 small_map 和 dcjl_plus 的优秀设计")
        info.setProperty("class", "tip-text")
        info.setFont(QFont("Consolas", 10))
        page.addWidget(info)
        make_line(page, False)
        page.addStretch(1)
    def closeEvent(self, event):
        self.close_all_wins() # 关闭全部由窗口管理器管理的窗口
        super().closeEvent(event)


# ═══════════════════════════════════════════════════════════
# 3. 启动 — WinManager 注入全局样式/背景/图标
#    主题/背景/图标独立管理，初始化时 apply_all() 一次性注入
# ═══════════════════════════════════════════════════════════

def main():
    """启动 xiaoe_ui demo 应用。"""
    # ── WinManager 全局注入 ──
    # 样式/背景/图标只需设置一次，所有 WinManager 子类 (MainWin/Dialog/MsgBox) 自动继承
    # set_style_source / set_bg_source / set_icon_source 设置全局来源
    # 主题切换时 ThemePage → WinManager.apply_style_all() 仅刷新样式

    global notify
    app = QApplication(sys.argv)

    _default_ico = resolve_static("xiaoe_ui/demo_static/default_ico.ico")

    # TopBoxWindow 外观回调 — JSON 存的 list，tuple() 转回元组拼 alpha
    TopBoxWindow.default_color_cb = lambda: tuple(theme_cfg.get("top_win_default_main_color")) + (220,)
    TopBoxWindow.default_text_color_cb = lambda: tuple(theme_cfg.get("top_win_default_main_color")) + (220,)
    TopBoxWindow.default_text_bg_cb = lambda: tuple(theme_cfg.get("config_background")) + (theme_cfg.get("block_alpha"),)
    NotifyOverlay.default_y_cb = lambda sh: int(sh * config.get("tz_y"))

    engine.set_internal_default("bg_image", "xiaoe_ui/demo_static/background.png")
    to_china_text(app)
    WinManager.set_icon_source(_default_ico)                                # 全局图标
    WinManager.set_style_source(lambda: engine.make_style(theme_cfg))        # QSS 生成函数
    WinManager.set_bg_source(lambda: engine.resolve_value(theme_cfg, "bg_image"))
    win = DemoApp(engine, theme_cfg)
    win.show()

    notify = NotifyOverlay()
    to_china_text(app)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
