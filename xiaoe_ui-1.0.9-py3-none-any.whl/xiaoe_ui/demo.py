
"""xiaoe_ui demo — 通过 ``xiaoe_ui-demo`` 或 ``python -m xiaoe_ui.demo`` 启动。"""
from xiaoe_ui._demo import main

if __name__ == "__main__":
    main()
