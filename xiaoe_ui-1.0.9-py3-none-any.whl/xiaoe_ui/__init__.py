from __future__ import annotations
"""xiaoe_ui — 基于 PySide6 的快速桌面应用 UI 框架。"""

from xiaoe_ui.core.frameless_win import FramelessWin
from xiaoe_ui.core.layout import MainLayout
from xiaoe_ui.core.main_win import MainWin
from xiaoe_ui.core.top_win import TopBoxWindow
from xiaoe_ui.core.notify import NotifyOverlay
from xiaoe_ui.core.dialog import Dialog
from xiaoe_ui.core.singleton_mixin import SingletonMixin
from xiaoe_ui.core.click_through import ClickThroughMixin
from xiaoe_ui.core.win_manager import WinManager

from xiaoe_ui.nav.left_list import LeftList, LeftGroup

from xiaoe_ui.theme.style import (
    make_style, apply_theme,
)
from xiaoe_ui.theme.engine import StyleEngine
from xiaoe_ui.utils.static_path import resolve_static

from xiaoe_ui.theme.theme_page import ThemePage
from xiaoe_ui.widgets.theme_btn import ThemeChoiceButton, ThemePopup

from xiaoe_ui.config.bridge import ConfigBridge

from xiaoe_ui.widgets.click_frame import ClickFrame, BigButton
from xiaoe_ui.widgets.instant_tip import InstantTooltipMixin
from xiaoe_ui.widgets.use_mixin_fast_widget import (
    InstantTipLabel, InstantTipButton,
    CustomComboBox, CustomSlider,
    QPushButtonHandCursor, QCheckBoxHandCursor,
)
from xiaoe_ui.widgets.basic import flash_style
from xiaoe_ui.widgets.a_box import ABox, HideItem
from xiaoe_ui.widgets.entry import (
    SpinEntry, TextEntry, MultiEntry, ImagePicker, DatePicker,
    ColorEntry, SliderEntry, CheckEntry, ComboEntry,
)
from xiaoe_ui.widgets.item import (
    CheckItem, ComboItem, SliderItem, ColorItem,
    KeyItem, BottomItem, GradientItem, make_line, make_tip,
    flash_config_widget, register_tag,
)
from xiaoe_ui.widgets.gradient import GradientBar
from xiaoe_ui.widgets.status_widgets import (
    StatusLineEdit, StatusDateEdit, StatusTextEdit, StatusImagePicker,
    ColorPickerButton,
)
from xiaoe_ui.widgets.form_layout import make_form_row

from xiaoe_ui.utils.msg import Msg
from xiaoe_ui.utils.msg_box import MsgBox, ask, info, warn, error, input_dialog
from xiaoe_ui.utils.font_picker import font_picker_dialog
from xiaoe_ui.utils.qt_run import run_in_main, run_in_main_block, in_main_block, in_main
from xiaoe_ui.utils.dpi import resize_elem, de_resize_elem, title_min_width
