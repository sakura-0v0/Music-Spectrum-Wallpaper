from __future__ import annotations
"""主布局骨架：左/右两个独立滚动区，带 block 圆角背景，同 small_map 外观。"""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QScrollArea, QWidget, QVBoxLayout, QHBoxLayout,
)


class MainLayout:
    """small_map 风格的左右双栏布局。

    左栏：侧栏导航（自带滚动，block 圆角背景）
    右栏：页面内容区（自带滚动，block 圆角背景）
    主窗口外层滚动禁用（需在 MainWin 构造时传 scroll=False）。

    Args:
        main_win: MainWin 实例
        left_width: 左栏固定宽度

    用法:
        win = MainWin(scroll=False)
        win.setup_ui()
        layout = MainLayout(win, left_width=180)
        layout.left_layout.addLayout(left_list.left_layout)
        layout.right_layout.addWidget(left_list.stack)
    """

    def __init__(
            self,
            main_win,
            left_width: int = 185,
            left_scroll_always_hide = True,
    ):
        self._main_win = main_win

        # 外层横向布局
        h_layout = QHBoxLayout()
        h_layout.setSpacing(5)
        h_layout.setContentsMargins(0, 0, 0, 0)

        # ── 左栏：带 block 样式的独立滚动区 ──
        self.left_scroll = QScrollArea()
        self.left_scroll.setWidgetResizable(True)
        self.left_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff if left_scroll_always_hide else Qt.ScrollBarAsNeeded)
        self.left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.left_scroll.setFixedWidth(left_width)

        left_widget = QWidget()
        left_widget.setProperty("class", "block")

        self.left_layout = QVBoxLayout(left_widget)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_scroll.setWidget(left_widget)

        h_layout.addWidget(self.left_scroll)

        # ── 右栏：带 block 样式的独立滚动区 ──
        self.right_scroll = QScrollArea()
        self.right_scroll.setWidgetResizable(True)
        self.right_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)


        right_widget = QWidget()
        right_widget.setProperty("class", "block")
        self.right_layout = QVBoxLayout(right_widget)
        self.right_layout.setSpacing(10)
        self.right_layout.setContentsMargins(5, 5, 5, 5)
        self.right_scroll.setWidget(right_widget)

        h_layout.addWidget(self.right_scroll, 1)

        main_win.content_layout.addLayout(h_layout)

    def scroll_to_top(self):
        """将右侧页面滚动到顶部"""
        self.right_scroll.verticalScrollBar().setValue(0)