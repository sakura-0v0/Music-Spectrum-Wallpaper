from __future__ import annotations

from xiaoe_ui.utils.create_empty_frame import empty_frame

"""主窗口基类：FramelessWin + WinManager + 标题栏 + 滚动区。"""

from PySide6.QtCore import Qt

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea,
    QPushButton, QFrame, QApplication,
)

from xiaoe_ui.core.frameless_win import FramelessWin
from xiaoe_ui.core.win_manager import WinManager
from xiaoe_ui.widgets.use_mixin_fast_widget import InstantTipLabel
from xiaoe_ui.utils.dpi import de_resize_elem


class _MainBtn(QPushButton):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setCursor(Qt.PointingHandCursor)


class MainWin(FramelessWin):
    """主窗口基类，继承后只需实现 ``add_ui()``。

    内置标题栏、滚动区、背景/图标自动加载（通过 WinManager）。
    需要单例窗口行为时，额外混入 :class:`SingletonMixin`。

    用法::

        class MyApp(MainWin):
            def add_ui(self):
                # 往 self.content_layout 添加 UI
                ...

    Args:
        win_title: 窗口标题，同时作为默认图标查找键
        content_h: True=内容区高度仅由子控件决定，不自动拉伸
        scroll: True=内容区包裹在 QScrollArea 中
        add_bottom_empty: True=底部添加空白的细条
        maxsize_btn: True=标题栏显示最大化按钮
        hide_btn: True=标题栏额外显示隐藏按钮
        auto_set_icon: True=自动从 title_icon 以 win_title 查找并设置任务栏图标
        add_down_block: True=内容区底部添加self.down_block_layout，你可以在这里放置组件。
    """

    # ── 实例 ──

    def __init__(
            self,
            win_title="xiaoe_ui",
            content_h=False,
            scroll=True,
            add_bottom_empty=True,
            maxsize_btn=True,
            hide_btn=False,
            auto_set_icon=True,
            add_down_block = False,
            **kwargs
    ):
        self.is_setup = False
        self._win_title = win_title
        self._content_h = content_h
        self._scroll = scroll
        self.add_down_block = add_down_block
        self._add_bottom_empty = add_bottom_empty
        self._maxsize_btn = maxsize_btn
        self._hide_btn = hide_btn
        self._auto_icon = auto_set_icon
        self._win_margin = 4

        super().__init__(main_win=True, rsize_margin=self._win_margin, **kwargs)
        self._register()
        self.add_bg()

    def add_ui(self):
        raise NotImplementedError("子类必须实现 add_ui()")

    def setup_ui(self):
        if self.is_setup:
            return
        self.is_setup = True
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setSpacing(0)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        # 标题栏
        self._setup_title_bar()

        # 滚动区
        scroll_area = QScrollArea()
        scroll_area.verticalScrollBar().setCursor(Qt.ArrowCursor)
        if self._scroll:
            scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        else:
            scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_area.setWidgetResizable(True)

        content_widget = QWidget()
        content_widget.setProperty("class", "root-no-background")
        self.content_layout = (
            QVBoxLayout(content_widget) if not self._content_h
            else QHBoxLayout(content_widget)
        )
        self.content_layout.setSpacing(5)
        self.content_layout.setContentsMargins(5, 5, 5, 5)

        scroll_area.setWidget(content_widget)

        scroll_f = QVBoxLayout()
        scroll_f.setContentsMargins(0, 0, 0, 0)
        scroll_f.addWidget(scroll_area)

        main_scroll_layout = QHBoxLayout()
        main_scroll_layout.setContentsMargins(0, 0, 0, 0)
        main_scroll_layout.addWidget(empty_frame(self._win_margin, ))
        main_scroll_layout.addLayout(scroll_f)
        main_scroll_layout.addWidget(empty_frame(self._win_margin, ))

        self.main_layout.addLayout(main_scroll_layout)
        if self.add_down_block:
            self._setup_down_block()
        if self._add_bottom_empty:
            self.main_layout.addWidget(empty_frame(self._win_margin, is_H=True))

        # 子类填充
        self.add_ui()

        if self._win_title:
            self.setWindowTitle(self._win_title)

        self._set_top(WinManager.is_top, is_setup=True)
        self.enter_edit_mode()

    def _setup_title_bar(self):
        bar_h = 30
        icon_h = 20
        btn_w, btn_h = 35, 25

        self.title_bar = QWidget()
        self.title_bar.setFixedHeight(bar_h)
        self.title_bar.setProperty("class", "block")

        tl = QHBoxLayout(self.title_bar)
        tl.setContentsMargins(de_resize_elem(10), de_resize_elem(3),
                              de_resize_elem(10), 0)

        self.title_icon_label = InstantTipLabel()
        self.title_icon_label.setFixedSize(icon_h, icon_h)
        tl.addWidget(self.title_icon_label)

        self.title_label = QLabel()
        self.title_label.setProperty("class", "win-title-text")
        tl.addWidget(self.title_label, 1)

        self.minimize_btn = _MainBtn("－")
        self.minimize_btn.setProperty("class", "alpha")
        self.minimize_btn.setFixedSize(btn_w, btn_h)
        self.minimize_btn.clicked.connect(self.showMinimized)
        tl.addWidget(self.minimize_btn)

        if self._hide_btn:
            self.tray_btn = _MainBtn("↘")
            self.tray_btn.setProperty("class", "alpha")
            self.tray_btn.setFixedSize(btn_w, btn_h)
            self.tray_btn.clicked.connect(self.hide)
            tl.addWidget(self.tray_btn)

        if self._maxsize_btn:
            self._is_maxsize = False
            self.maxsize_btn = _MainBtn("↗")
            self.maxsize_btn.setProperty("class", "alpha")
            self.maxsize_btn.setFixedSize(btn_w, btn_h)
            def _toggle_max(*_):
                if self._is_maxsize:
                    self.showNormal()
                    self._is_maxsize = False
                    self.maxsize_btn.setText("↗")
                    self.is_edit_mode = True
                else:
                    self.showMaximized()
                    self._is_maxsize = True
                    self.maxsize_btn.setText("↙")
                    self.is_edit_mode = False
            self.maxsize_btn.clicked.connect(_toggle_max)
            tl.addWidget(self.maxsize_btn)

        self.close_btn = _MainBtn("×")
        self.close_btn.setProperty("class", "alpha")
        self.close_btn.setFixedSize(btn_w, btn_h)
        self.close_btn.clicked.connect(self.close)
        tl.addWidget(self.close_btn)

        self.main_layout.insertWidget(0, self.title_bar)

    def _setup_down_block(self):
        frame = QWidget()
        frame.setProperty("class", "block")
        frame.setFixedHeight(35)
        self.down_block_layout = QHBoxLayout(frame)
        self.down_block_layout.setContentsMargins(6, 2, 12, 2)
        self.main_layout.addWidget(frame)

    def setWindowTitle(self, title):
        super().setWindowTitle(title)
        if hasattr(self, "title_label"):
            self.title_label.setText(title)
        if hasattr(self, "title_icon_label"):
            self.title_icon_label.setToolTip(title)

    def setWindowIcon(self, icon):
        super().setWindowIcon(icon)
        if hasattr(self, "title_icon_label") and self.title_icon_label:
            try:
                self.title_icon_label.setPixmap(
                    icon.pixmap(self.title_icon_label.height(), self.title_icon_label.height()))
            except Exception:
                pass

    def _set_top(self, top, is_setup=False):
        if top:
            self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        else:
            self.setWindowFlags(self.windowFlags() & ~Qt.WindowStaysOnTopHint)
        if not is_setup:
            self.show()

    # def resizeEvent(self, event):
    #     if hasattr(self, '_reset_bg_size'):
    #         self._reset_bg_size()
    #     super().resizeEvent(event)
