from __future__ import annotations

import traceback

import mouse
from PySide6.QtGui import QCursor

from xiaoe_ui.utils.qt_run import run_in_main

"""ClickThroughMixin — 穿透窗口交互混入，全局鼠标钩子 + 命中测试。

可混入任意 QWidget 子类。配合 FramelessWin 的穿透 flag 使用，
通过 ``mouse`` 库全局钩子对已注册控件做命中测试，
穿透模式下仍可选择性交互。

穿透 flag 由 FramelessWin._cuantou_set / set_cuantou 管理，本混入不参与。

依赖:
    ``mouse`` 库（``pip install mouse``），仅启动钩子时才需要。

用法::

    class MyPanel(FramelessWin, ClickThroughMixin):
        def __init__(self):
            super().__init__(cuantou=True)
            self.register_clickable(self.btn,
                on_left=lambda: print("左键点击"),
                on_right=lambda: print("右键点击"),
                on_press=lambda: print("按下"),
                on_normal=lambda: print("恢复"),
            )
            self.register_click_other(lambda: print("空白区域"))

        def showEvent(self, event):
            super().showEvent(event)
            self.start_mouse_hook()

        def hideEvent(self, event):
            self.stop_mouse_hook()
            super().hideEvent(event)
"""

from typing import Callable

from PySide6.QtCore import QPoint, Signal, QRect
from PySide6.QtWidgets import QWidget


class ClickThroughMixin:
    """穿透窗口交互混入 — 全局钩子 + 命中测试 + 回调分发。

    模拟普通按钮行为: press 记录按下控件 → release 在同一控件上则触发点击。
    down/double 均视为按下，同 small_map。

    调用者需覆写 showEvent/hideEvent 启停钩子，见模块文档。
    """

    _ct_signal = Signal(dict)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._ct_widgets: dict[int, dict] = {}
        self._ct_other_funcs: list[Callable] = []
        self._ct_hook_running: bool = False
        self._ct_hook_cb = None
        self._ct_pressed_widget: QWidget | None = None
        self._ct_pressed_button: str | None = None
        self._ct_mouse_pos: QPoint | None = None

    # ── 注册可点击控件 ──

    def register_clickable(
        self,
        widget: QWidget,
        on_left: Callable | None = None,
        on_right: Callable | None = None,
        on_middle: Callable | None = None,
        on_press: Callable | None = None,
        on_normal: Callable | None = None,
    ):
        """注册穿透模式下仍可点击的控件。

        Args:
            widget: 目标控件
            on_left: 左键点击（release 在控件内触发）
            on_right: 右键点击
            on_middle: 中键点击
            on_press: 鼠标按下时触发
            on_normal: 释放后恢复正常状态时触发
        """
        self._ct_widgets[id(widget)] = {
            "widget": widget,
            "on_left": on_left,
            "on_right": on_right,
            "on_middle": on_middle,
            "on_press": on_press,
            "on_normal": on_normal,
        }

    def unregister_clickable(self, widget: QWidget):
        """取消注册可点击控件。"""
        wid = id(widget)
        if self._ct_pressed_widget is widget:
            self._ct_pressed_widget = None
            self._ct_pressed_button = None
        self._ct_widgets.pop(wid, None)

    # ── 空白区域点击 ──

    def register_click_other(self, func: Callable):
        """注册点击空白区域（非注册控件）的回调。"""
        self._ct_other_funcs.append(func)

    def unregister_click_other(self, func: Callable):
        if func in self._ct_other_funcs:
            self._ct_other_funcs.remove(func)

    # ── 全局鼠标钩子 ──

    def start_mouse_hook(self):
        """启动全局鼠标钩子。需要 ``mouse`` 库（``pip install mouse``）。"""
        if self._ct_hook_running:
            return
        self._ct_signal.connect(self._on_mouse_event)
        self._ct_hook_cb = mouse.hook(
            lambda e: self._ct_signal.emit({"event": e})
        )
        self._ct_hook_running = True

    def stop_mouse_hook(self):
        """停止全局鼠标钩子。"""
        if not self._ct_hook_running:
            return
        try:
            if self._ct_hook_cb is not None:
                mouse.unhook(self._ct_hook_cb)
                self._ct_hook_cb = None
        except ImportError:
            traceback.print_exc()
        self._ct_hook_running = False

    # ── 事件处理 ──

    def _on_mouse_event(self, data: dict):
        """全局钩子回调入口。Move 存坐标，Button 分发到 press/release。"""
        if not self.isVisible():
            return
        event = data.get("event")
        if event is None:
            return

        try:
            if isinstance(event, mouse.ButtonEvent):
                pos = QCursor.pos()
                if event.event_type in ("down", "double"):
                    run_in_main(
                        lambda pos=pos, btn=event.button:
                        self._handle_press(pos, btn)
                    )
                elif event.event_type == "up":
                    run_in_main(
                        lambda pos = pos, btn = event.button:
                        self._handle_release(pos, btn)
                    )

        except Exception:
            traceback.print_exc()

    # ── 命中测试 ──

    def _hit_test(self, screen_pos: QPoint) -> QWidget | None:
        """返回屏幕坐标下的已注册控件，未命中返回 None。"""
        for info in self._ct_widgets.values():
            w = info["widget"]
            if not w.isVisible() or not w.isEnabled():
                continue
            local = w.mapFromGlobal(screen_pos)
            if w.rect().contains(local):
                return w
        return None

    # ── 状态处理 ──

    def _handle_press(self, screen_pos: QPoint, button: str):
        # 如果已经有按钮按着没释放，忽略后续 press（同 ClickFrame: 不会重复按下）
        if self._ct_pressed_button is not None:
            return

        hit = self._hit_test(screen_pos)
        if hit is not None:
            self._ct_pressed_widget = hit
            self._ct_pressed_button = button
            info = self._ct_widgets.get(id(hit))
            if info and info["on_press"]:
                info["on_press"]()
        else:
            for func in self._ct_other_funcs:
                func()

    def _handle_release(self, screen_pos: QPoint, button: str):
        pressed = self._ct_pressed_widget
        if pressed is None:
            return

        # 只处理对应按钮的 release
        if self._ct_pressed_button != button:
            return

        info = self._ct_widgets.get(id(pressed))

        # 在同一控件内释放 → 触发点击回调（同 ClickFrame: release 在 rect 内才触发）
        hit = self._hit_test(screen_pos)
        if hit is pressed:
            if info:
                cb_map = {
                    "left": info["on_left"],
                    "right": info["on_right"],
                    "middle": info["on_middle"],
                }
                cb = cb_map.get(button)
                if cb:
                    cb()

        if info and info["on_normal"]:
            info["on_normal"]()

        self._ct_pressed_widget = None
        self._ct_pressed_button = None
