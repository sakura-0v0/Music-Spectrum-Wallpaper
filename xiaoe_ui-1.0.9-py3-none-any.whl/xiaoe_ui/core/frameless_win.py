from __future__ import annotations

from typing import List

from xiaoe_ui.core.win_manager import WinManager
from xiaoe_ui.utils.create_empty_frame import empty_frame

"""可拖拽、可resize的无边框窗口基类。"""

from PySide6.QtCore import Qt, QPoint, QRect, QTimer
from PySide6.QtWidgets import QWidget, QLabel, QVBoxLayout, QFrame, QHBoxLayout
from PySide6.QtGui import QCursor, QMouseEvent


class FramelessWin(WinManager, QWidget):
    """无边框、可拖拽移动、可 resize 的窗口基类。

    特性:
        - 8方向 resize（可设最小宽高、宽高比锁定）
        - 拖拽标题栏移动
        - 编辑模式（显示拖拽行为）/ 运行模式
        - 穿透模式（Qt flags 切换，叠加在其他窗口上）
        - 可选 config 持久化窗口位置/大小

    如需穿透模式下仍可点击指定控件，请使用 ClickThroughMixin。
    """

    def __init__(self, *args, parent=None,
                 min_w=200, min_h=100,
                 rsize_margin=4,
                 main_win=False,
                 cuantou=False,
                 use_global_style = False,
                 custom_edit_overlay: QWidget = None,
                 show_default = True,
                 custom_windows_flags: List[Qt.WindowType] | None = None,
                 **kwargs
                 ):
        """
        Args:
            parent: 父窗口
            min_w / min_h: 最小宽高
            rsize_margin: resize 边缘检测宽度
            main_win: 是否为主窗口模式。如果开启，可改变大小、移动为常态，且只设置无边框flag。
            cuantou: 是否开启穿透模式
            use_global_style: 是否使用全局样式
            custom_edit_overlay: 自定义编辑模式遮罩层
            show_default: 是否默认显示
            custom_windows_flags: 添加额外窗口flag
        """
        super().__init__(parent, *args , **kwargs)
        self.main_win = main_win
        self.custom_edit_overlay = custom_edit_overlay
        self.use_global_style = use_global_style
        self.show_default = show_default
        self.custom_windows_flags = custom_windows_flags
        self.is_edit_mode = False
        self.is_resizing = False
        self.is_moving = False
        self.resize_direction = None
        self.keep_aspect_ratio = False
        self._edit_overlay = None
        self._is_first_enter_edit = True
        self.aspect_ratio = 1.0
        self.is_cuantou = cuantou
        self._init_cuantou = cuantou

        self.MARGIN = rsize_margin
        self.min_width = min_w
        self.min_height = min_h
        self.setMinimumSize(min_w, min_h)

        self.resize_timer = QTimer(self)
        self.resize_timer.setSingleShot(True)
        self.resize_timer.timeout.connect(self._apply_resize)

        self.last_mouse_pos = QPoint()
        self.drag_start_pos = QPoint()
        self.drag_geometry = QRect()

        self._create_edit_overlay()
        self._setup_child_ui()
        self._load_config()
        if self.use_global_style:
            self._register()
            self.apply_all()

    def _create_edit_overlay(self):
        # 半透明覆盖层，不改 stylesheet，避免样式丢失
        if self.main_win:
            return
        if self.custom_edit_overlay is not None:
            self._edit_overlay = self.custom_edit_overlay
            return
        self._edit_overlay = QFrame(self)
        self._edit_overlay.setProperty("class", "root")

        edit_layout = QVBoxLayout(self._edit_overlay)
        edit_layout.setContentsMargins(0,0,0,0)
        edit_layout.setSpacing(0)
        edit_layout.addWidget(empty_frame(self.MARGIN, is_H=True), 1)
        edit_main_layout = QHBoxLayout()
        edit_main_layout.setContentsMargins(0, 0, 0, 0)
        edit_main_layout.setSpacing(0)
        edit_layout.addLayout(edit_main_layout)
        edit_layout.addWidget(empty_frame(self.MARGIN, is_H=True))

        edit_main_layout.addWidget(empty_frame(self.MARGIN))
        self._edit_label = QLabel()
        edit_main_layout.addWidget(self._edit_label, 1)
        edit_main_layout.addWidget(empty_frame(self.MARGIN))
        # self._edit_overlay.setAttribute(Qt.WA_TransparentForMouseEvents, True)

        self._edit_label.setAlignment(Qt.AlignCenter)
        self._edit_label.setProperty("class", "section_title overlay_background")
        self._edit_label.setText("拖动调整窗口大小 · 位置")
        if self.use_global_style:
            self._edit_overlay.setStyleSheet(
                "font-size: 28px;"
            )
        else:
            self._edit_overlay.setStyleSheet(

                ".root {"
                "   background: rgba(255, 255, 255, 120);"
                "}"
                "QLabel.section_title {"
                "   font-size: 28px;"               
                "   font-weight: bold;"
                "   text-align: center;"
                "   color: rgb(0,0,0);"
                "}"
                ".block {"
                "   background: rgba(255, 255, 255, 220); "
                "}"
            )

        self._edit_overlay.hide()



    # ── 子类可重写 ──

    def _setup_child_ui(self):
        if self.main_win:
            self._cuantou_set(self.is_cuantou, main_win_set=True)
        else:
            self._cuantou_set(self.is_cuantou)
            self.setAttribute(Qt.WA_TranslucentBackground)

    def _load_config(self):
        """子类重写以从配置恢复窗口位置。"""
        pass

    def _save_config(self):
        """子类重写以保存窗口位置到配置。"""
        pass

    # ── 穿透模式 ──

    def _cuantou_set(self, ct: bool, main_win_set = False):
        if main_win_set:
            window_flags = Qt.FramelessWindowHint
        elif ct:
            self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            window_flags = (
                Qt.WindowStaysOnTopHint |
                Qt.FramelessWindowHint |
                Qt.Tool |
                Qt.X11BypassWindowManagerHint |
                Qt.WindowTransparentForInput
            )
        else:
            self.setAttribute(Qt.WA_TransparentForMouseEvents, False)
            window_flags = (
                Qt.WindowStaysOnTopHint |
                Qt.FramelessWindowHint |
                Qt.Tool
            )
        if self.custom_windows_flags is not None:
            for flag in self.custom_windows_flags:
                window_flags |= flag
        self.setWindowFlags(window_flags)
        self.is_cuantou = ct

    def set_cuantou(self, ct: bool):
        self._cuantou_set(ct)
        self.show()

    # ── 编辑模式 ──

    def enter_edit_mode(self):
        self.is_edit_mode = True
        if not self.main_win:
            self._was_visible_before_edit = self.isVisible()


            self.show()
            if self._edit_overlay is not None:
                self._edit_overlay.show()
                self._edit_overlay.raise_()
                self._edit_overlay.setGeometry(self.rect())

        if self.is_cuantou and not self.main_win:
            self._cuantou_set(False)
        self._set_mouse_tracking_all(self, True)
        self.update_cursor(self.mapFromGlobal(QCursor.pos()))
        if not self._is_first_enter_edit or self.show_default:
            self.show()
        self._is_first_enter_edit = False

    def exit_edit_mode(self):
        self.is_edit_mode = False
        self.is_resizing = False
        self.is_moving = False
        if self._edit_overlay is not None:
            self._edit_overlay.hide()
        # setWindowFlags 会重建 native 窗口冲掉几何，提前保存编辑后恢复
        saved_geo = self.geometry()
        if self._init_cuantou:
            self._cuantou_set(True)
        self.setGeometry(saved_geo)
        self._save_config()  # 在 show 之前保存，避免 showEvent→_load_config 读回旧值覆盖
        if getattr(self, '_was_visible_before_edit', True):
            self.show()
        else:
            self.hide()
        self._set_mouse_tracking_all(self, False)
        self.setCursor(Qt.ArrowCursor)

    def _set_mouse_tracking_all(self, widget, enable=True):
        widget.setMouseTracking(enable)
        for child in widget.findChildren(QWidget):
            child.setMouseTracking(enable)

    # ── 光标更新 ──

    def _get_resize_direction(self, pos):
        x, y = pos.x(), pos.y()
        w, h = self.width(), self.height()
        left = x <= self.MARGIN
        right = x >= w - self.MARGIN
        top = y <= self.MARGIN
        bottom = y >= h - self.MARGIN

        if left and top: return "top_left"
        if left and bottom: return "bottom_left"
        if right and top: return "top_right"
        if right and bottom: return "bottom_right"
        if left: return "left"
        if right: return "right"
        if top: return "top"
        if bottom: return "bottom"
        return None

    _CURSOR_MAP = {
        "top_left": Qt.SizeFDiagCursor,
        "top_right": Qt.SizeBDiagCursor,
        "bottom_left": Qt.SizeBDiagCursor,
        "bottom_right": Qt.SizeFDiagCursor,
        "left": Qt.SizeHorCursor,
        "right": Qt.SizeHorCursor,
        "top": Qt.SizeVerCursor,
        "bottom": Qt.SizeVerCursor,
    }

    def update_cursor(self, pos):
        if self.main_win:
            direction = self._get_resize_direction(pos)
            if direction in self._CURSOR_MAP:
                self.setCursor(self._CURSOR_MAP[direction])
            elif hasattr(self, 'title_bar') and self.title_bar.rect().contains(
                    self.title_bar.mapFrom(self, pos)):
                # 标题栏上：检查是否在按钮上
                pos_tb = self.title_bar.mapFrom(self, pos)
                in_btn = False
                for btn_name in ['minimize_btn', 'maxsize_btn', 'close_btn', 'tray_btn']:
                    btn = getattr(self, btn_name, None)
                    if btn and btn.rect().contains(btn.mapFrom(self.title_bar, pos_tb)):
                        in_btn = True
                        break
                self.setCursor(Qt.SizeAllCursor if not in_btn else Qt.ArrowCursor)
            else:
                self.setCursor(Qt.ArrowCursor)
        else:
            if not self.is_edit_mode:
                self.setCursor(Qt.ArrowCursor)
                return
            direction = self._get_resize_direction(pos)
            if direction in self._CURSOR_MAP:
                self.setCursor(self._CURSOR_MAP[direction])
            else:
                self.setCursor(Qt.SizeAllCursor if self.rect().contains(pos) else Qt.ArrowCursor)

    # ── 鼠标事件 ──

    def mousePressEvent(self, event: QMouseEvent):
        if not self.is_edit_mode:
            return

        if self.main_win and event.button() == Qt.LeftButton:
            direction = self._get_resize_direction(event.pos())
            if direction:
                self.is_resizing = True
                self.resize_direction = direction
                self.drag_start_pos = event.globalPos()
                self.drag_geometry = self.geometry()
                event.accept()
                return
            if hasattr(self, 'title_bar'):
                pos_tb = self.title_bar.mapFrom(self, event.pos())
                if self.title_bar.rect().contains(pos_tb):
                    in_btn = False
                    for btn_name in ['minimize_btn', 'maxsize_btn', 'close_btn', 'tray_btn']:
                        btn = getattr(self, btn_name, None)
                        if btn and btn.rect().contains(btn.mapFrom(self.title_bar, pos_tb)):
                            in_btn = True
                            break
                    if not in_btn:
                        self.is_moving = True
                        self.drag_start_pos = event.globalPos()
                        self.drag_geometry = self.geometry()
                        event.accept()
                        return

        if event.button() == Qt.LeftButton and self.is_edit_mode and not self.main_win:
            self.drag_start_pos = event.globalPos()
            self.drag_geometry = self.geometry()
            direction = self._get_resize_direction(event.pos())
            if direction:
                self.is_resizing = True
                self.resize_direction = direction
            else:
                self.is_moving = True
            event.accept()
            return

        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent):
        if self.main_win:
            self.update_cursor(event.pos())
            if self.is_resizing and event.buttons() & Qt.LeftButton:
                self._handle_resize(event.globalPos())
                event.accept()
                return
            if self.is_moving and event.buttons() & Qt.LeftButton:
                self._handle_move(event.globalPos())
                event.accept()
                return
        else:
            if self.is_edit_mode:
                self.update_cursor(event.pos())
                if self.is_resizing and event.buttons() & Qt.LeftButton:
                    self._handle_resize(event.globalPos())
                    event.accept()
                    return
                if self.is_moving and event.buttons() & Qt.LeftButton:
                    self._handle_move(event.globalPos())
                    event.accept()
                    return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.LeftButton:
            self.is_resizing = False
            self.is_moving = False
            self.resize_direction = None
            event.accept()
            return
        super().mouseReleaseEvent(event)

    # ── resize / move 逻辑 ──

    def _handle_resize(self, global_pos):
        delta = global_pos - self.drag_start_pos
        geo = QRect(self.drag_geometry)

        if self.resize_direction == "top_left":
            geo.setTopLeft(geo.topLeft() + delta)
        elif self.resize_direction == "top_right":
            geo.setTopRight(geo.topRight() + delta)
        elif self.resize_direction == "bottom_left":
            geo.setBottomLeft(geo.bottomLeft() + delta)
        elif self.resize_direction == "bottom_right":
            geo.setBottomRight(geo.bottomRight() + delta)
        elif self.resize_direction == "left":
            geo.setLeft(geo.left() + delta.x())
        elif self.resize_direction == "right":
            geo.setRight(geo.right() + delta.x())
        elif self.resize_direction == "top":
            geo.setTop(geo.top() + delta.y())
        elif self.resize_direction == "bottom":
            geo.setBottom(geo.bottom() + delta.y())

        if geo.width() < self.min_width:
            if self.resize_direction in ("left", "top_left", "bottom_left"):
                geo.setLeft(geo.right() - self.min_width)
            else:
                geo.setRight(geo.left() + self.min_width)

        if geo.height() < self.min_height:
            if self.resize_direction in ("top", "top_left", "top_right"):
                geo.setTop(geo.bottom() - self.min_height)
            else:
                geo.setBottom(geo.top() + self.min_height)

        if self.keep_aspect_ratio and self.resize_direction:
            self._maintain_aspect(geo)

        self.setGeometry(geo)

    def _maintain_aspect(self, geo):
        # 简化为只处理 corner resize
        if self.resize_direction in ("top_left", "top_right", "bottom_left", "bottom_right"):
            target_h = int(geo.width() / self.aspect_ratio)
            if self.resize_direction in ("top_left", "top_right"):
                geo.setTop(geo.bottom() - target_h)
            else:
                geo.setBottom(geo.top() + target_h)

    def _handle_move(self, global_pos):
        delta = global_pos - self.drag_start_pos
        self.setGeometry(self.drag_geometry.translated(delta))

    def _apply_resize(self):
        pass

    def resizeEvent(self, *args, **kwargs):
        super().resizeEvent(*args, **kwargs)
        if self._edit_overlay:
            self._edit_overlay.setGeometry(self.rect())

    def showEvent(self, event):
        self._load_config()
        super().showEvent(event)
