from __future__ import annotations
"""通知横幅，继承 TopBoxWindow，屏幕上方居中，自动隐藏，多屏支持。"""

from typing import Callable

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QFontMetrics
from PySide6.QtWidgets import QApplication

from xiaoe_ui.core.top_win import TopBoxWindow, ColorCB

# screen_cb 返回值类型: (left, top, width, height)
ScreenCB = Callable[[], tuple[int, int, int, int]]


def _measure_text(text: str, font_size: int) -> int:
    """用 QFontMetrics 精确测量文本像素宽度。

    Args:
        text: 待测文本（可含 \\n）
        font_size: 字号（像素）

    Returns:
        最大行宽（像素）
    """
    font = QFont()
    font.setPixelSize(font_size)
    fm = QFontMetrics(font)
    return max((fm.horizontalAdvance(line) for line in text.split("\n")), default=0)


class NotifyOverlay(TopBoxWindow):
    """屏幕上方居中通知横幅，多行居中，多屏支持。

    screen_cb() → (left, top, width, height) 目标屏幕几何
    y_cb(sh)    → Y 坐标（相对屏幕 top）

    用法:
        NotifyOverlay.default_screen_cb = lambda: (...)
        NotifyOverlay.default_y_cb = lambda sh: int(sh * config.get("tz_y", 0.06))
        notify = NotifyOverlay()
        notify.show("操作成功")
    """

    # 类级默认
    default_screen_cb: ScreenCB = staticmethod(
        lambda: (QApplication.primaryScreen().geometry().left(),
                 QApplication.primaryScreen().geometry().top(),
                 QApplication.primaryScreen().geometry().width(),
                 QApplication.primaryScreen().geometry().height()))
    default_y_cb: Callable[[int], int] = lambda sh: int(sh * 0.06)

    def __init__(self, parent=None, hide_after: float = 3,
                 screen_cb: ScreenCB | None = None,
                 y_cb: Callable[[int], int] | None = None,
                 text_color_cb: ColorCB | None = None,
                 text_bg_cb: ColorCB | None = None,
                 text_font_size: int = 16):
        """
        Args:
            parent: 父窗口
            hide_after: 默认自动隐藏秒数
            screen_cb: 返回 (left, top, width, height) 的回调，用于多屏
            y_cb: 接收屏幕高度，返回通知 Y 坐标
            text_color_cb: 文字颜色回调
            text_bg_cb: 文字背景色回调
            text_font_size: 字号
        """
        super().__init__(
            parent=parent,
            text_color_cb=text_color_cb,
            text_bg_cb=text_bg_cb,
            text_font_size=text_font_size,
        )
        cls = self.__class__
        self._screen_cb = screen_cb if screen_cb is not None else cls.default_screen_cb
        self._y_cb = y_cb if y_cb is not None else cls.default_y_cb
        self._default_hide_after = hide_after

    def show(self, text: str, hide_after: float = None, font_size: int = None):
        """显示通知。

        Args:
            text: 通知文字
            hide_after: 自动隐藏秒数，默认 3
            font_size: 字号，默认 16
        """
        d = hide_after if hide_after is not None else self._default_hide_after
        fs = font_size if font_size is not None else self._text_fs

        # 同 small_map: 字号 = box 高度，adjustSize 自适应
        text_w = _measure_text(text, fs)
        lines = text.count("\n") + 1
        h = fs * lines

        sl, st, sw, sh = self._screen_cb()

        x1 = sl + (sw - text_w) // 2
        y1 = st + self._y_cb(sh)

        self._text_label.setAlignment(Qt.AlignCenter)
        self.show_text(text, box=(x1, y1, x1 + text_w, y1 + h), hide_after=d)
