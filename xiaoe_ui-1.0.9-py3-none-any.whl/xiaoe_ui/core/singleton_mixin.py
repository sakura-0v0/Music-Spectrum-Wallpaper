from __future__ import annotations
"""SingletonMixin — 单例窗口混入，同 dcjl_plus AppBaseUi 的 global_open_wins 模式。

可混入任意 QWidget 子类（Dialog、QWidget 等）。

用法:
    class MyPopup(Dialog, SingletonMixin):
        def __init__(self):
            Dialog.__init__(self, ..., modal=False)
            SingletonMixin._singleton_init(self, "my_popup", only_one=True)

        def closeEvent(self, event):
            SingletonMixin._singleton_close(self)
            super().closeEvent(event)

    # 外部：弹出前检查
    existing = MyPopup.get_singleton("my_popup")
    if existing is not None:
        existing.activateWindow()
        return
    MyPopup().show()

    # 装饰器模式（同 dcjl）:
    @SingletonMixin.open_too_many_except(lambda e: print(e))
    def open_my_popup():
        popup = MyPopup()
        popup.show()
"""

import weakref
from typing import Callable


class OpenTooManyWin(Exception):
    """only_one=True 时，同 key 已有实例则抛出，阻止重复创建。"""

    def __init__(self,
                 key: str,
                 ):
        self.key = key

    def __str__(self):
        return f"单例 '{self.key}' 已有实例，不再创建"


class SingletonMixin:
    """单例窗口混入，同 dcjl AppBaseUi 的 global_open_wins 模式。

    类属性:
        _global_instances: {key: {child_id: instance}}  按 key 分组管理
        _instance_counter: 自增 child_id 计数器

    实例方法:
        _singleton_init(key, only_one=False) → 在 __init__ 末尾调用
        _singleton_close()                  → 在 closeEvent 中调用
    """

    _global_instances: dict[str, dict[int, object]] = {}
    _instance_counter: int = 0

    # ── 类方法 ──

    @classmethod
    def _get_or_create_group(cls,
                             key: str,
                             ) -> dict[int, object]:
        """获取或创建指定 key 的实例组。"""
        group = cls._global_instances.get(key)
        if group is None:
            group = {}
            cls._global_instances[key] = group
        return group

    @classmethod
    def _next_child_id(cls) -> int:
        """自增 child_id。"""
        cid = cls._instance_counter
        cls._instance_counter += 1
        return cid

    @classmethod
    def get_singleton(cls,
                      key: str,
                      ) -> object | None:
        """获取指定 key 的任一实例（优先返回最新的）。

        Args:
            key: 单例标识

        Returns:
            实例或 None
        """
        group = cls._global_instances.get(key)
        if group:
            # 返回最新的（最大 child_id）
            return group[max(group.keys())]
        return None

    @classmethod
    def close_all(cls,
                  key: str | None = None,
                  ):
        """关闭实例。

        Args:
            key: 指定 key 则只关闭该组，None 则关闭全部
        """
        if key is not None:
            group = cls._global_instances.pop(key, {})
            for inst in group.values():
                try:
                    inst.close()
                except Exception:
                    pass
        else:
            for gkey in list(cls._global_instances.keys()):
                cls.close_all(gkey)

    @classmethod
    def open_too_many_except(cls,
                             except_func: Callable[[OpenTooManyWin], None] = lambda e: None,
                             ):
        """装饰器工厂，捕获 OpenTooManyWin 异常。同 dcjl init_open_too_many_win_except_factory。

        Args:
            except_func: 异常处理回调 (OpenTooManyWin) -> None

        Returns:
            装饰器

        用法:
            @SingletonMixin.open_too_many_except(lambda e: print(e))
            def open_popup():
                popup = MyPopup()
                popup.show()
        """
        def decorator(func: Callable):
            def wrapper(*args, **kwargs):
                try:
                    return func(*args, **kwargs)
                except OpenTooManyWin as e:
                    except_func(e)
            return wrapper
        return decorator

    # ── 实例方法 ──

    def _singleton_init(self,
                        key: str,
                        only_one: bool = False,
                        ):
        """初始化单例注册（在 __init__ 末尾调用）。

        Args:
            key: 单例标识
            only_one: True 则同 key 只允许一个实例，再次创建抛出 OpenTooManyWin
        """
        group = self.__class__._get_or_create_group(key)
        if only_one and group:
            for win in group.values():
                try:
                    win.activateWindow()
                except Exception:
                    pass
            raise OpenTooManyWin(key)

        self._singleton_key: str = key
        self._singleton_child_id: int = self.__class__._next_child_id()
        group[self._singleton_child_id] = self

    def _singleton_close(self,
                         ):
        """释放单例注册（在 closeEvent 中调用）。"""
        key: str | None = getattr(self, '_singleton_key', None)
        cid: int | None = getattr(self, '_singleton_child_id', None)
        if key is not None and cid is not None:
            group = self.__class__._global_instances.get(key)
            if group is not None and group.get(cid) is self:
                del group[cid]
                if not group:
                    del self.__class__._global_instances[key]
