from __future__ import annotations
"""对话框基类。样式/背景/图标通过 WinManager 统一注入。"""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QDialog, QVBoxLayout, QWidget

from xiaoe_ui.core.win_manager import WinManager


class Dialog(WinManager, QDialog):
    """对话框基类。

    通过 WinManager 继承样式/背景/图标/实例管理，同 MainWin 共享全局设置。

    Args:
        parent: 父窗口
        win_title: 窗口标题
        always_on_top: 始终置顶
        width / height: 窗口宽高
        set_fixed_size: True 则固定大小

    用法:
        dlg = Dialog(parent, win_title="设置", width=400, height=300)
        dlg.root_layout.addWidget(...)
        dlg.exec()
    """

    def __init__(self,
                 parent=None,
                 win_title: str = "",
                 always_on_top: bool = False,
                 width: int = None,
                 height: int = None,
                 set_fixed_size: bool = True,
                 modal: bool = True,
                 ):
        self.is_setup = True
        super().__init__(parent)

        if WinManager.is_top or always_on_top:
            self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

        self.setWindowTitle(win_title)
        self.setModal(modal)

        if width and height:
            if set_fixed_size:
                self.setFixedSize(width, height)
            else:
                self.setMinimumSize(width, height)

        # 根布局
        main_layout = QVBoxLayout(self)
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # 内容区（带 block 样式）
        self.root = QWidget()
        self.root.setAttribute(Qt.WA_StyledBackground, True)
        self.root.setProperty("class", "block")
        main_layout.addWidget(self.root)

        # 注入样式
        self._register()
        self.add_bg()
        self.apply_all()

        # 子类往这里加控件
        self.root_layout = QVBoxLayout(self.root)
        self.root_layout.setContentsMargins(10, 10, 10, 10)
