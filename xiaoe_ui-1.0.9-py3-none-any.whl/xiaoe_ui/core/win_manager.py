from __future__ import annotations

import traceback

"""WinManager — 窗口状态管理器，所有框架窗口的基类。

将样式、背景、图标拆为三个独立模块，各自有：
  - 类方法 set_xxx_source   → 设置全局来源
  - 类方法 apply_xxx_all    → 应用到所有已注册窗口
  - 实例方法 apply_xxx      → 应用到当前实例

另有 apply_all / apply_all_wins 作为三者合一的便捷入口，通常仅在初始化时使用。
主题切换、改背景、改图标均可单独调用对应方法，互不干扰。
"""

import os
import weakref
from typing import Callable, TYPE_CHECKING

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap, QIcon
from PySide6.QtWidgets import QLabel, QWidget

from xiaoe_ui.widgets.click_frame import ClickFrame



class WinManager:
    """窗口状态管理器，继承即可共享全局样式、背景、图标、实例管理。

    用法::

        # 设置全局来源（仅需一次）
        WinManager.set_style_source(lambda: engine.make_style(config))
        WinManager.set_bg_source(lambda: config.get("bg_image"))
        WinManager.set_icon_source("icon.ico")

        # 初始化时一起应用
        win.apply_all()

        # 主题切换 → 仅刷新样式
        WinManager.apply_style_all()

        # 仅改背景
        WinManager.apply_bg_all()

        # 全局操作
        WinManager.close_all_wins()
        WinManager.on_top_all_win(True)
    """

    if TYPE_CHECKING:
        self: 'QWidget | WinManager'
        cls: 'QWidget | WinManager'

    # ── 类级全局状态 ──

    _style_source: Callable[[], str] | None = None
    _bg_source: Callable[[], str] | None = None
    _icon_source: str = ""
    is_top: bool = False
    _instances: weakref.WeakSet['WinManager | QWidget'] = weakref.WeakSet()

    # ═══════════════════════════════════════════════════════════════
    # 样式 (QSS)
    # ═══════════════════════════════════════════════════════════════

    @classmethod
    def set_style_source(cls,
                         fn: Callable[[], str],
                         ):
        """设置全局 QSS 生成函数。

        Args:
            fn: () → QSS 字符串
        """
        cls._style_source = fn

    @classmethod
    def apply_style_all(cls):
        """对所有已注册窗口应用当前 QSS。"""
        for inst in cls._instances:
            inst.apply_style()

    def apply_style(self: 'QWidget | WinManager'):
        """对当前实例应用 QSS。"""
        fn = self._get_cls_attr("_style_source")
        if fn is None:
            return
        qss = fn()
        if qss is None:
            return
        saved = ClickFrame.suspend_highlights()
        self.setStyleSheet(qss)
        ClickFrame.restore_highlights(saved)

    # ═══════════════════════════════════════════════════════════════
    # 背景
    # ═══════════════════════════════════════════════════════════════

    @classmethod
    def set_bg_source(cls,
                      fn: Callable[[], str],
                      ):
        """设置全局背景图路径获取函数。

        Args:
            fn: () → 背景图片路径
        """
        cls._bg_source = fn

    @classmethod
    def apply_bg_all(cls):
        """对所有已注册窗口应用当前背景图。"""
        for inst in cls._instances:
            inst.apply_bg()

    def apply_bg(self: 'QWidget | WinManager'):
        """对当前实例应用背景图。"""
        fn = self._get_cls_attr("_bg_source")
        bg_path = fn() if fn else None
        if self._bg_label is not None and bg_path and os.path.exists(bg_path):
            self._bg_pixmap = QPixmap(bg_path)
            self._bg_label.setPixmap(self._bg_pixmap)
            self._reset_bg_size()

    # ═══════════════════════════════════════════════════════════════
    # 图标
    # ═══════════════════════════════════════════════════════════════

    @classmethod
    def set_icon_source(cls,
                        path: str,
                        ):
        """设置全局图标路径。

        Args:
            path: 图标文件路径
        """
        cls._icon_source = path

    @classmethod
    def apply_icon_all(cls):
        """对所有已注册窗口应用当前图标。"""
        for inst in cls._instances:
            inst.apply_icon()

    def apply_icon(self: 'QWidget | WinManager'):
        """对当前实例应用图标。"""
        icon = self._get_cls_attr("_icon_source")
        if icon:
            self.setWindowIcon(QIcon(icon))

    # ═══════════════════════════════════════════════════════════════
    # 三者合一（初始化便利入口）
    # ═══════════════════════════════════════════════════════════════

    def apply_all(self):
        """对当前实例应用样式 + 背景 + 图标。通常仅在初始化时调用。"""
        self.apply_style()
        self.apply_bg()
        self.apply_icon()

    @classmethod
    def apply_all_wins(cls):
        """对所有已注册窗口应用样式 + 背景 + 图标。"""
        for inst in cls._instances:
            inst.apply_all()

    # ═══════════════════════════════════════════════════════════════
    # 实例管理
    # ═══════════════════════════════════════════════════════════════

    @classmethod
    def close_all_wins(cls):
        """关闭所有窗口。"""
        for inst in list(cls._instances):
            try:
                inst.close()
            except Exception:
                traceback.print_exc()

    @classmethod
    def on_top_all_win(cls,
                       top: bool,
                       ):
        """全局置顶 / 取消置顶所有窗口。

        Args:
            top: True 置顶
        """
        cls.is_top = top
        for inst in list(cls._instances):
            try:
                inst.on_top(top, is_global=True)
            except Exception:
                pass

    # ── 实例方法 ──

    def __init__(self, *args, on_top_with_global=True, **kwargs):
        self.on_top_with_global = on_top_with_global
        self._bg_pixmap = None
        self._bg_label = None
        super().__init__(*args, **kwargs)

    def on_top(self: 'WinManager | QWidget', top, is_global=False):
        """置顶窗口。"""
        if not self.on_top_with_global and is_global:
            return
        last_status = not self.isHidden()
        if top:
            self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
        else:
            self.setWindowFlags(self.windowFlags() & ~Qt.WindowStaysOnTopHint)
        if last_status:
            self.show()

    def _register(self):
        """注册到全局实例列表。"""
        WinManager._instances.add(self)

    def add_bg(self: 'QWidget | WinManager', bg_alpha_class="root"):
        """创建背景 QLabel 并置于最底层。

        Args:
            bg_alpha_class: 指定背景透明度使用的 class
        """
        self.bg_color_root = QWidget(self)
        self.bg_color_root.setProperty("class", bg_alpha_class)
        self.bg_color_root.lower()

        self._bg_label = QLabel(self)
        self._bg_label.setProperty("class", "background")
        self._bg_label.setAlignment(Qt.AlignCenter)
        self._bg_label.lower()
        self._bg_pixmap = None

    def _get_cls_attr(self: 'QWidget | WinManager',
                      name: str,
                      ):
        """沿 MRO 查找第一个非 None 的类属性。"""
        for cls in self.__class__.__mro__:
            val = cls.__dict__.get(name)
            if val is not None:
                return val
        return None

    def resizeEvent(self: 'QWidget | WinManager', *args, **kwargs):
        super().resizeEvent(*args, **kwargs)
        self._reset_bg_size()

    def _reset_bg_size(self: 'WinManager | QWidget'):
        """按窗口大小缩放背景图，保持宽高比裁剪。"""
        if not hasattr(self, '_bg_label') or not hasattr(self, '_bg_pixmap'):
            return
        if self._bg_pixmap is None:
            return
        size = self.size()
        geometry_args = (0, 0, size.width(), size.height())
        self._bg_label.setGeometry(*geometry_args)
        scaled = self._bg_pixmap.scaled(
            size.width(), size.height(),
            Qt.AspectRatioMode.KeepAspectRatioByExpanding,
            Qt.TransformationMode.SmoothTransformation,
        )
        self._bg_label.setPixmap(scaled)
        self.bg_color_root.setGeometry(*geometry_args)
