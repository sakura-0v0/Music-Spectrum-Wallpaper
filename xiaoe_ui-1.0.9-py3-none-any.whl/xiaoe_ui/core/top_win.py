"""透明悬浮窗基类。从 small_map TopBoxWindow 移植，模块化拆分绘制/显示/文字。

颜色全部通过 callback 获取，每次 show 时调用，保证主题切换后即时生效。
"""

from __future__ import annotations

from typing import Callable, Tuple

from PySide6.QtCore import Qt, QRect, QTimer
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget


# ── 类型别名 ──

RGBA = Tuple[int, int, int] | Tuple[int, int, int, int]
"""callback 返回颜色: (r,g,b) 或 (r,g,b,a)"""

ColorCB = Callable[[], RGBA]
"""颜色回调: () → (r,g,b) 或 (r,g,b,a)"""


def _ensure_rgba(c: RGBA) -> Tuple[int, int, int, int]:
    """确保颜色为 4 元组 RGBA。"""
    return (c[0], c[1], c[2], c[3] if len(c) >= 4 else 255)


class TopBoxWindow(QWidget):
    """透明置顶悬浮窗，QPainter 绘制 + 文字标签。

    类属性 = 全局默认 callback，实例参数 = 单个覆盖。每次 show 时调 callback。

    color_cb()       → 线框颜色 (r,g,b) 或 (r,g,b,a)
    text_color_cb()  → 文字颜色
    text_bg_cb()     → 文字背景色

    用法:
        TopBoxWindow.default_color_cb = lambda: config.get("top_win_default_main_color")
        TopBoxWindow.default_text_bg_cb = lambda: config.get("config_background")

        win = TopBoxWindow()
        win.show_box(box=(x1,y1,x2,y2))                     # 画矩形框
        win.show_box(box=(x1,y1,x2,y2), diagonal="lr")      # 画对角线
        win.show_text("hello", box=(x1,y1,x2,y2))           # 显示文字
    """

    # 类级默认
    default_color_cb: ColorCB = lambda: (255, 255, 0)
    default_text_color_cb: ColorCB = lambda: (255, 255, 255)
    default_text_bg_cb: ColorCB = lambda: (255, 255, 255, 40)
    default_line_width: int = 2
    default_text_font_size: int = 16
    default_hide_after: float = 2.0

    def __init__(self,
                 parent=None,
                 color_cb: ColorCB | None = None,
                 line_width: int | None = None,
                 text_color_cb: ColorCB | None = None,
                 text_bg_cb: ColorCB | None = None,
                 text_font_size: int | None = None,
                 custom_draw: Callable[[QPainter, QRect], None] | None = None,
                 ):
        """
        Args:
            parent: 父窗口
            color_cb: 线框/绘制颜色回调
            line_width: 线宽
            text_color_cb: 文字颜色回调
            text_bg_cb: 文字背景色回调
            text_font_size: 字号
            custom_draw: 自定义绘制 (painter, rect)
        """
        super().__init__(parent)
        cls = self.__class__
        self._color_cb = color_cb if color_cb is not None else cls.default_color_cb
        self._line_w = line_width if line_width is not None else cls.default_line_width
        self._text_c_cb = text_color_cb if text_color_cb is not None else cls.default_text_color_cb
        self._text_bg_cb = text_bg_cb if text_bg_cb is not None else cls.default_text_bg_cb
        self._text_fs = text_font_size if text_font_size is not None else cls.default_text_font_size
        self._custom_draw = custom_draw

        self._hide_timer = QTimer(self)
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self.hide)

        self._setup_window()
        self._setup_label()
        self.hide()

    # ── 窗口属性 ──

    def _setup_window(self):
        """设置透明置顶无边框穿透窗口。"""
        self.setWindowFlags(
            Qt.WindowStaysOnTopHint | Qt.FramelessWindowHint |
            Qt.Tool | Qt.X11BypassWindowManagerHint |
            Qt.WindowTransparentForInput
        )
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)

    # ── 文字标签 ──

    def _setup_label(self):
        """创建居中文字标签。"""
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._text_label = QLabel(self)
        self._text_label.setAlignment(Qt.AlignCenter)
        self._layout.addWidget(self._text_label)

    def _apply_label_style(self, font_size: int = None):
        """应用当前回调颜色到 QLabel。

        Args:
            font_size: 字号，None 则用实例默认
        """
        fs = font_size if font_size is not None else self._text_fs
        c = _ensure_rgba(self._text_c_cb())
        bg = _ensure_rgba(self._text_bg_cb())
        self._text_label.setStyleSheet(
            f"background-color: rgba{bg};"
            f"color: rgba{c};"
            f"font-size: {fs}px;"
            f"font-weight: bold;"
        )

    # ── 绘制 ──

    def paintEvent(self,
                    event,
                    ):
        """QPainter 绘制矩形框 / 对角线 / 自定义图形。"""
        if not hasattr(self, '_box_rect'):
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        c = _ensure_rgba(self._color_cb())
        painter.setPen(QPen(QColor(*c), self._line_w))

        rect = self._box_rect
        if getattr(self, '_show_box_line', True):
            if rect.width() <= 1:
                mid = rect.left() + rect.width() // 2
                painter.drawLine(mid, rect.top(), mid, rect.bottom())
            elif rect.height() <= 1:
                mid = rect.top() + rect.height() // 2
                painter.drawLine(rect.left(), mid, rect.right(), mid)
            else:
                painter.drawRect(rect)

        if self._custom_draw:
            self._custom_draw(painter, rect)

        diag = getattr(self, '_diagonal', None)
        if diag:
            if "l" in diag:
                painter.drawLine(rect.topLeft(), rect.bottomRight())
            if "r" in diag:
                painter.drawLine(rect.topRight(), rect.bottomLeft())

    # ── 显示方法 ──

    def show_box(self,
                 box: tuple[int, int, int, int],
                 diagonal: str = None,
                 move: bool = True,
                 hide_after: float = None,
                 show_box_line: bool = True,
                 ):
        """显示矩形框 / 对角线。

        Args:
            box: (x1, y1, x2, y2)
            diagonal: "l" 左上→右下, "r" 右上→左下, "lr" 双线
            move: 是否移动窗口到 box 位置
            hide_after: 秒后自动隐藏，None 用类默认
            show_box_line: 是否画矩形边框
        """
        if box is None:
            self.hide()
            return
        x1, y1, x2, y2 = box
        w, h = x2 - x1, y2 - y1
        self._show_box_line = show_box_line
        self._diagonal = diagonal
        self.setFixedSize(w, h)
        if move:
            self.move(x1, y1)
        self._box_rect = QRect(1, 1, w - 2, h - 2)
        self.update()
        super().show()
        self._start_hide(hide_after)

    def show_text(self,
                  text: str,
                  box: tuple[int, int, int, int] = None,
                  font_size: int = None,
                  hide_after: float = None,
                  show_box: bool = False,
                  ):
        """显示文字。字号默认 = box 高度，adjustSize 自适应（同 small_map）。

        Args:
            text: 文字内容
            box: (x1, y1, x2, y2)
            font_size: 字号，None 则取 box 高度
            hide_after: 秒后隐藏
            show_box: 是否显示文字周围的矩形边框
        """
        if box is None:
            self.hide()
            return
        x1, y1, x2, y2 = box
        w, h = x2 - x1, y2 - y1
        self._show_box_line = show_box
        self._diagonal = None

        fs = font_size if font_size is not None else self._text_fs
        self._apply_label_style(fs)
        self._text_label.setText(text)
        self._text_label.adjustSize()
        self.adjustSize()
        self.resize(w, h)
        self.move(x1, y1)
        offset = 1 if show_box else 0
        self._box_rect = QRect(offset, offset,
                               self.width() - offset * 2, self.height() - offset * 2)
        self.update()
        super().show()
        self._start_hide(hide_after)

    def _start_hide(self,
                    hide_after: float = None,
                    ):
        """启动自动隐藏计时器。"""
        d = hide_after if hide_after is not None else self.__class__.default_hide_after
        if d:
            self._hide_timer.start(int(1000 * d))
        else:
            self._hide_timer.stop()

    def hide(self):
        """隐藏窗口，停止自动隐藏计时器。"""
        if self._hide_timer.isActive():
            self._hide_timer.stop()
        super().hide()
