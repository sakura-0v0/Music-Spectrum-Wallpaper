"""xiaoe_ui demo 项目配置实例 — JSON 文件持久化 + ConfigBridge + 主题引擎。

配置文件存放于 ~/.xiaoe_ui/demo_configs/*.json（首次运行自动生成）。
"""

import os

from xiaoe_ui import ConfigBridge, StyleEngine
from xiaoe_config_manager import Config

_CFG_DIR = os.path.join(os.getcwd(), "config_files")
os.makedirs(_CFG_DIR, exist_ok=True)


def _path(name: str) -> str:
    return os.path.join(_CFG_DIR, name)


# ═══════════════════════════════════════════════════════════════
# 1. demo 业务配置
# ═══════════════════════════════════════════════════════════════

_DEFAULTS = {
    "demo_bool": False, "demo_combo": "选项A", "demo_slider": 50, "demo_float": 0.5,
    "demo_color": (255, 154, 162), "demo_color_rgba": (255, 100, 100, 150),
    "demo_text": "hello", "demo_int": 3,
    "sync_value": 50,
    "tz_y": 0.06,
    "sync_check": False,
    "sync_combo": "选项A",
    "sync_color": (255, 154, 162),
    "sync_text": "hello",
    "sync_int": 50,
    "sync_float": 0.5,
    "sync_multi": "多行文本\n第二行",
    "sync_date": "2025-01-01",
    "sync_image": None,
    "on_demo": 0,
    "demo_gradient": [
        {"pos": 0.0, "color": (255, 100, 100, 255)},
        {"pos": 1.0, "color": (100, 100, 255, 255)},
    ],
    "demo_gradient_bg": (255, 255, 255, 0),
}

config = ConfigBridge(instance=Config(file_name=_path("app"), default_config=_DEFAULTS))

# ═══════════════════════════════════════════════════════════════
# 2. 主题引擎 + 主题配置
# ═══════════════════════════════════════════════════════════════

engine = StyleEngine()

# 可选: 在此处定制主题 — 覆盖默认值 / 追加或替换变量、主题、QSS
#
# ── 默认值 ──
#    engine.set_defaults(config_background=(255, 255, 255))    # 覆盖指定变量的默认值
#
# ── 变量: add_var 追加 / set_vars 替换 ──
#    engine.add_var("颜色", "my_color",                       # 追加 QSS 变量, 对应 {{my_color}}
#                   ThemeVar(label="我的颜色", desc="..."))
#    engine.set_vars({...})                                   # 替换全部变量注册表
#
# ── 主题: add_theme 追加 / set_themes 替换 ──
#    engine.add_theme("自定义", "我的主题", {"my_color": ...}) # 追加预设主题, ThemePage 自动显示
#    engine.set_themes({"自定义": {"我的": {...}, ...}})       # 替换全部预设主题
#
# ── QSS: add 追加 / set 替换 ──
#    engine.add_qss("QPushButton.my { color: rgb({{my_color}}); }")  # 追加到默认 QSS 末尾
#    engine.set_qss("...")                                            # 替换全部 QSS (清空默认)
_theme_defaults = engine.get_defaults()
theme_cfg = ConfigBridge(instance=Config(file_name=_path("theme"), default_config=_theme_defaults))

# ═══════════════════════════════════════════════════════════════
# 3. 按键绑定配置
# ═══════════════════════════════════════════════════════════════

_KEY_DEFAULTS = {
    "demo_key_down": ["Q"], "demo_key_up": ["W"],
    "demo_key_down_up": ["E"], "demo_long_1s": ["R"],
    "demo_long_2s": ["T"], "demo_long_or_short": ["Y"],
    "demo_key_combo": ["ctrl_l", "U"],
    "sync_key": [],
}

key_cfg = ConfigBridge(instance=Config(file_name=_path("keys"), default_config=_KEY_DEFAULTS))

# ═══════════════════════════════════════════════════════════════
# 4. 表单配置
# ═══════════════════════════════════════════════════════════════

_FORM_DEFAULTS = {
    "f_name": "张三", "f_age": 25, "f_height": 1.75,
    "f_birthday": "2000-01-01", "f_intro": "大家好，我是张三。",
    "f_avatar": None,
    "f_gender": "未选择",
}

form_cfg = ConfigBridge(instance=Config(file_name=_path("form"), default_config=_FORM_DEFAULTS))

# ═══════════════════════════════════════════════════════════════
# 5. 穿透窗口配置 — 持久化窗口位置大小
# ═══════════════════════════════════════════════════════════════

_CT_DEFAULTS = {"ct_win_geo": None}

ct_config = ConfigBridge(instance=Config(file_name=_path("ct_win"), default_config=_CT_DEFAULTS))
